# NexCode AI Android Client

The Flutter app provides a single chat plus a persistent project workspace.

## V6 UI
- Auto / Code / Reasoning / Writer modes
- Web Auto / Web / Deep Research / Web Off
- Project selector
- Autonomous pipeline display
- Developer Console: intelligence, quality, Git, memory, terminal
- Visual debugger upload

## Build

```bash
flutter pub get
flutter run --dart-define=NEXCODE_API_URL=https://YOUR-DOMAIN/api
```

Do not put provider API keys into the app.
