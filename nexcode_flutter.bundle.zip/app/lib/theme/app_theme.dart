import 'package:flutter/material.dart';

class NexColors {
  static const background = Color(0xFF07070B);
  static const surface = Color(0xFF101017);
  static const surface2 = Color(0xFF171721);
  static const purple = Color(0xFF8B5CF6);
  static const violet = Color(0xFFB06CFF);
  static const cyan = Color(0xFF35D7FF);
  static const text = Color(0xFFF7F7FB);
  static const muted = Color(0xFF9999AC);
  static const border = Color(0xFF262631);
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: NexColors.purple,
    brightness: Brightness.dark,
    surface: NexColors.surface,
  );

  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: NexColors.background,
    colorScheme: scheme.copyWith(
      primary: NexColors.purple,
      secondary: NexColors.cyan,
      surface: NexColors.surface,
      onSurface: NexColors.text,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: NexColors.background,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
    ),
    cardTheme: CardThemeData(
      color: NexColors.surface,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
    dividerTheme: const DividerThemeData(color: NexColors.border, space: 1),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: NexColors.surface2,
      hintStyle: const TextStyle(color: NexColors.muted),
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(20),
        borderSide: const BorderSide(color: NexColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(20),
        borderSide: const BorderSide(color: NexColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(20),
        borderSide: const BorderSide(color: NexColors.purple, width: 1.3),
      ),
    ),
  );
}
