class AppConfig {
  static const apiBaseUrl = String.fromEnvironment(
    'NEXCODE_API_URL',
    defaultValue: 'https://YOUR-BACKEND-DOMAIN.example/api',
  );
  static const oauthCallbackScheme = String.fromEnvironment(
    'NEXCODE_OAUTH_SCHEME',
    defaultValue: 'nexcode',
  );
  static const oauthCallbackUrl = String.fromEnvironment(
    'NEXCODE_OAUTH_CALLBACK',
    defaultValue: 'nexcode://oauth/callback',
  );
}
