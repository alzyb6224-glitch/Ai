import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';

import '../models/models.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class HomeScreen extends StatefulWidget {
  final ApiService api;
  const HomeScreen({super.key, required this.api});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  int? conversationId;
  int? activeProjectId;
  bool loading = false;
  String mode = 'auto';
  String webMode = 'auto';
  Map<String, dynamic>? v7Status;
  Map<String, dynamic>? v8Status;
  Map<String, dynamic>? v9Status;
  Map<String, dynamic>? v11Status;
  Map<String, dynamic>? v11Obs;

  final input = TextEditingController();
  final scroll = ScrollController();
  final List<ChatMessage> messages = [];
  List<ConversationModel> convs = [];
  List<ProjectModel> projects = [];

  ProjectModel? get activeProject {
    for (final p in projects) {
      if (p.id == activeProjectId) return p;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try { v7Status = await widget.api.v7Status(); } catch (_) {}
    try { v8Status = await widget.api.v8Status(); } catch (_) {}
    try { v9Status = await widget.api.v9Status(); } catch (_) {}
    try { v11Status = await widget.api.v11Status(); } catch (_) {}
    try { v11Obs = await widget.api.v11Observability(); } catch (_) {}
    try {
      convs = await widget.api.conversations();
      projects = await widget.api.projects();
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Future<void> send() async {
    final text = input.text.trim();
    if (text.isEmpty || loading) return;

    input.clear();
    setState(() {
      messages.add(ChatMessage(role: 'user', content: text));
      loading = true;
    });

    try {
      final data = activeProjectId != null
          ? await widget.api.v11Run(text, projectId: activeProjectId, mode: mode, webMode: webMode)
          : await widget.api.sendChat(text, conversationId: conversationId, mode: mode, projectId: activeProjectId, webMode: webMode);

      conversationId = data['conversation_id'] as int?;
      final actions = _maps(data['actions']);
      final pipeline = _maps(data['pipeline']);

      String answer = data['answer']?.toString() ?? 'No response.';
      final execution = data['execution'];
      if (execution is Map && execution['summary'] != null) {
        answer += '\n\n**Verification:** ${execution['summary']}';
      }

      final quality = data['quality'];
      if (quality is Map && quality['score'] != null) {
        answer += '\n**Quality:** `${quality['score']}%`';
      }

      final research = data['research'];
      if (research is Map && research['enabled'] == true) {
        final count = (research['queries'] as List? ?? const []).length;
        answer += '\n**Research:** `${research['depth']}` · `$count` search passes';
      }

      answer += '\n**Delivery:** `${data['status'] ?? 'done'}` · `${data['applied'] ?? 0}` files · `${data['repair_cycles'] ?? 0}` repairs';

      if (!mounted) return;
      setState(() {
        messages.add(
          ChatMessage(
            role: 'assistant',
            content: answer,
            route: data['route']?.toString(),
            actions: actions,
            pipeline: pipeline,
            meta: Map<String, dynamic>.from(data),
          ),
        );
      });
      await _load();
      _scrollDown();
    } catch (e) {
      if (mounted) {
        setState(() {
          messages.add(
            ChatMessage(
              role: 'assistant',
              content: '**NexCode error**\n\n${e.toString().replaceFirst('Exception: ', '')}',
            ),
          );
        });
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  List<Map<String, dynamic>> _maps(dynamic value) {
    if (value is! List) return [];
    return value.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(
          scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 240),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void prompt(String value) {
    setState(() {
      input.text = value;
      input.selection = TextSelection.collapsed(offset: value.length);
    });
  }

  void _error(Object e) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> newProject() async {
    final name = TextEditingController();
    final description = TextEditingController();
    final created = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('New workspace'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, autofocus: true, decoration: const InputDecoration(labelText: 'Project name')),
            const SizedBox(height: 12),
            TextField(controller: description, maxLines: 2, decoration: const InputDecoration(labelText: 'Description')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Create')),
        ],
      ),
    );
    if (created == true && name.text.trim().isNotEmpty) {
      await widget.api.createProject(name.text.trim(), description.text.trim());
      await _load();
    }
    name.dispose();
    description.dispose();
  }

  Future<void> importFiles(ProjectModel project) async {
    final pick = await FilePicker.platform.pickFiles(withData: true);
    if (pick == null) return;
    try {
      final count = await widget.api.uploadProjectFile(project.id, pick.files.single);
      await _load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Imported $count file(s).')));
    } catch (e) {
      _error(e);
    }
  }

  Future<void> visualDebug() async {
    final pick = await FilePicker.platform.pickFiles(withData: true, type: FileType.image);
    if (pick == null) return;
    try {
      final result = await widget.api.analyzeScreenshot(pick.files.single);
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Visual debugging'),
          content: SizedBox(width: 760, child: SingleChildScrollView(child: MarkdownBody(data: result['answer']?.toString() ?? 'No result.', selectable: true))),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
        ),
      );
    } catch (e) {
      _error(e);
    }
  }

  Future<void> showProjectConsole(ProjectModel project) async {
    try {
      final intel = await widget.api.analyzeProject(project.id);
      final quality = await widget.api.quality(project.id);
      final git = await widget.api.gitInfo(project.id);
      final memory = await widget.api.memory(project.id);
      if (!mounted) return;

      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: NexColors.surface,
        builder: (_) => DefaultTabController(
          length: 5,
          child: SizedBox(
            height: MediaQuery.sizeOf(context).height * .84,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 12, 8),
                  child: Row(
                    children: [
                      const Icon(Icons.psychology_alt_rounded),
                      const SizedBox(width: 10),
                      Text(project.name, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
                      const Spacer(),
                      IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
                    ],
                  ),
                ),
                const TabBar(tabs: [
                  Tab(text: 'Intelligence'),
                  Tab(text: 'Quality'),
                  Tab(text: 'Git'),
                  Tab(text: 'Memory'),
                  Tab(text: 'Terminal'),
                ]),
                Expanded(
                  child: TabBarView(
                    children: [
                      _jsonView(intel),
                      _qualityView(quality),
                      _gitView(git),
                      _jsonView(memory),
                      _terminalView(project),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    } catch (e) {
      _error(e);
    }
  }

  Widget _jsonView(dynamic value) => SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: SelectableText(const JsonEncoder.withIndent('  ').convert(value)),
      );

  Widget _qualityView(Map<String, dynamic> data) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Overall ${data['score'] ?? '—'}%', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Text('Code ${data['code_quality'] ?? '—'}% · Tests ${data['tests'] ?? '—'}% · Security ${data['security'] ?? '—'}%'),
          const SizedBox(height: 18),
          Text('Build: ${data['build'] ?? 'NOT_RUN'} · Dependencies: ${data['dependencies'] ?? 'N/A'} · Regression: ${data['regression'] ?? 'UNKNOWN'}'),
          const SizedBox(height: 18),
          const Text('Findings', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          ...((data['findings'] as List? ?? const []).map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Text('• ${e is Map ? (e['message'] ?? e.toString()) : e}')))),
        ],
      ),
    );
  }

  Widget _gitView(Map<String, dynamic> data) => SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('History', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          SelectableText((data['history'] as List? ?? const []).join('\n')),
          const SizedBox(height: 18),
          const Text('Latest diff', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          SelectableText(data['diff']?.toString() ?? 'No diff yet.'),
        ]),
      );

  Widget _terminalView(ProjectModel project) {
    final command = TextEditingController(text: 'python -m compileall -q .');
    return Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        children: [
          TextField(controller: command, decoration: const InputDecoration(prefixIcon: Icon(Icons.terminal), hintText: 'Approved command')),
          const SizedBox(height: 10),
          const Text('Commands are allowlisted. In safe_static mode project code is not executed; enable Docker on the server for real test execution.', style: TextStyle(color: NexColors.muted)),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: () => _runTerminal(project, command.text), icon: const Icon(Icons.play_arrow), label: const Text('Run')),
        ],
      ),
    );
  }

  Future<void> _runTerminal(ProjectModel project, String raw) async {
    final command = raw.trim();
    if (command.isEmpty) return;
    try {
      final data = await widget.api.terminal(project.id, command.split(RegExp(r'\s+')));
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text(data['ok'] == true ? 'Execution result' : 'Execution blocked/failed'),
          content: SizedBox(width: 720, child: SingleChildScrollView(child: SelectableText(data['output']?.toString() ?? ''))),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
        ),
      );
    } catch (e) {
      _error(e);
    }
  }

  Widget _message(ChatMessage message) {
    final isUser = message.isUser;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 900),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isUser ? NexColors.surface2 : NexColors.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: NexColors.border),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (!isUser && message.route != null)
              Padding(padding: const EdgeInsets.only(bottom: 8), child: Text('NexCode · ${message.route}', style: const TextStyle(fontSize: 11, color: NexColors.violet, fontWeight: FontWeight.w700))),
            MarkdownBody(data: message.content, selectable: true),
            if (!isUser && message.pipeline.isNotEmpty) ...[
              const SizedBox(height: 12),
              _pipeline(message.pipeline),
            ],
            if (!isUser && message.actions.isNotEmpty)
              Padding(padding: const EdgeInsets.only(top: 8), child: Text('Actions proposed/applied: ${message.actions.length}', style: const TextStyle(fontSize: 12, color: NexColors.muted))),
          ]),
        ),
      ),
    );
  }

  Widget _pipeline(List<Map<String, dynamic>> steps) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: NexColors.background, borderRadius: BorderRadius.circular(14)),
      child: Column(
        children: steps.map((step) {
          final status = step['status']?.toString() ?? 'pending';
          final ok = status == 'done' || status == 'skipped';
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(children: [
              Icon(ok ? Icons.check_circle : status.contains('retry') || status == 'failed' ? Icons.error_outline : Icons.radio_button_unchecked, size: 16),
              const SizedBox(width: 7),
              Expanded(child: Text(step['label']?.toString() ?? '')),
              Text(status, style: const TextStyle(fontSize: 10, color: NexColors.muted)),
            ]),
          );
        }).toList(),
      ),
    );
  }

  Widget _chat() {
    if (messages.isEmpty) {
      return Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 820),
            child: Column(children: [
              Container(width: 82, height: 82, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [NexColors.purple, NexColors.cyan])), child: const Icon(Icons.auto_awesome, color: Colors.white, size: 38)),
              const SizedBox(height: 22),
              const Text('NexCode AI', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900)),
              const SizedBox(height: 9),
              const Text('Autonomous developer workspace: research, code, test, repair and deliver.', textAlign: TextAlign.center, style: TextStyle(color: NexColors.muted, fontSize: 16)),
              const SizedBox(height: 20),
              Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: ['Build a Flutter app', 'Fix the login bug', 'Deep research the latest API', 'Review project security', 'Analyze architecture'].map((x) => ActionChip(label: Text(x), onPressed: () => prompt(x))).toList()),
            ]),
          ),
        ),
      );
    }
    return ListView(controller: scroll, padding: const EdgeInsets.symmetric(vertical: 16), children: messages.map(_message).toList());
  }

  Widget _composer() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
      decoration: const BoxDecoration(color: NexColors.background, border: Border(top: BorderSide(color: NexColors.border))),
      child: Column(children: [
        Row(children: [
          DropdownButton<String>(value: mode, items: const [DropdownMenuItem(value: 'auto', child: Text('Auto')), DropdownMenuItem(value: 'code', child: Text('Code')), DropdownMenuItem(value: 'reasoning', child: Text('Reasoning')), DropdownMenuItem(value: 'writer', child: Text('Writer'))], onChanged: (v) => setState(() => mode = v ?? 'auto')),
          const SizedBox(width: 12),
          DropdownButton<String>(value: webMode, items: const [DropdownMenuItem(value: 'auto', child: Text('Web Auto')), DropdownMenuItem(value: 'off', child: Text('Web Off')), DropdownMenuItem(value: 'fast', child: Text('Web')), DropdownMenuItem(value: 'deep', child: Text('Deep Research'))], onChanged: (v) => setState(() => webMode = v ?? 'auto')),
          const Spacer(),
          if (activeProject != null) _chip(Icons.folder, activeProject!.name),
        ]),
        const SizedBox(height: 8),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(child: TextField(controller: input, minLines: 1, maxLines: 7, onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'Tell NexCode what you want built, fixed or researched...'))),
          const SizedBox(width: 10),
          FloatingActionButton(onPressed: loading ? null : send, child: loading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.arrow_upward)),
        ]),
      ]),
    );
  }

  Widget _chip(IconData icon, String label) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), decoration: BoxDecoration(color: NexColors.surface2, borderRadius: BorderRadius.circular(10), border: Border.all(color: NexColors.border)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 15), const SizedBox(width: 6), Text(label, style: const TextStyle(fontSize: 12))]));

  Widget _projects() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Text('Projects', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)), const Spacer(), FilledButton.icon(onPressed: newProject, icon: const Icon(Icons.add), label: const Text('New project'))]),
        const SizedBox(height: 8),
        const Text('Each project is a persistent agent workspace with files, intelligence, tests, Git, memory and research.', style: TextStyle(color: NexColors.muted)),
        const SizedBox(height: 18),
        Expanded(child: GridView.builder(gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 470, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 1.5), itemCount: projects.length, itemBuilder: (_, index) {
          final project = projects[index];
          final active = activeProjectId == project.id;
          return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const Icon(Icons.folder_copy_outlined), const SizedBox(width: 8), Expanded(child: Text(project.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))), PopupMenuButton<String>(onSelected: (value) { if (value == 'use') setState(() => activeProjectId = project.id); if (value == 'upload') importFiles(project); if (value == 'console') showProjectConsole(project); if (value == 'visual') visualDebug(); }, itemBuilder: (_) => const [PopupMenuItem(value: 'use', child: Text('Use in chat')), PopupMenuItem(value: 'upload', child: Text('Import files')), PopupMenuItem(value: 'console', child: Text('Developer console')), PopupMenuItem(value: 'visual', child: Text('Visual debugger'))])]),
            const SizedBox(height: 10),
            Text(project.description.isEmpty ? 'No description yet.' : project.description, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: NexColors.muted)),
            const Spacer(),
            OutlinedButton.icon(onPressed: () => setState(() => activeProjectId = project.id), icon: const Icon(Icons.workspaces_outlined), label: Text(active ? 'Active in chat' : 'Use project')),
          ])));
        }))
      ]),
    );
  }

  Widget _v7Dashboard() => ListView(padding: const EdgeInsets.all(20), children: [
        const Text('NexCode V9 Engine', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        const Text('20 V9 capabilities: model routing · browser/computer · MCP · multi-agent research · code graph · autonomous loop · SWE harness · security · IDE · artifacts · realtime · memory learning · voice · deploy · code review · dependencies', style: TextStyle(color: NexColors.muted)),
        const SizedBox(height: 18),
        if (v8Status == null) const Card(child: ListTile(title: Text('V8 status unavailable'), subtitle: Text('Backend health endpoint could not be loaded.')))
        else ...[
          Card(child: ListTile(leading: const Icon(Icons.auto_awesome), title: Text('V9: ${v9Status?['status'] ?? 'unknown'}'), subtitle: Text('Live features wired: ${((v9Status?['features'] as Map?)?.length ?? 0)}'))),
          ...((v9Status?['features'] as Map? ?? const <String,dynamic>{}).entries.map((e) => Card(child: ListTile(leading: const Icon(Icons.check_circle_outline), title: Text(e.key.replaceAll('_',' ')), subtitle: Text(e.value.toString()))))),
          const SizedBox(height: 10),
          FilledButton.icon(onPressed: () async { try { final r=await widget.api.v8Benchmark(); if(!mounted)return; showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('V8 Benchmark'),content:SizedBox(width:620,child:SingleChildScrollView(child:SelectableText('Tasks: ${r['tasks']}\nPassed: ${r['passed']}\nFailed: ${r['failed']}\nPass rate: ${r['pass_rate']}%\nMode: ${r['evaluation_mode']}'))),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close'))])); } catch(e){ _error(e); } }, icon: const Icon(Icons.science_outlined), label: const Text('V9 contract benchmark')),
        ],
      ]);

  Widget _v11Dashboard() => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('NexCode Agent Core', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6),
    const Text('V11 central orchestration: intent → context → agent team → tools → verify → repair → deliver.', style: TextStyle(color: NexColors.muted)),
    const SizedBox(height: 18),
    Card(child: ListTile(leading: const Icon(Icons.hub_rounded), title: Text('Core: ${v11Status?['status'] ?? 'loading'}'), subtitle: Text('Architecture: ${v11Status?['architecture'] ?? 'central_agent_core'}'))),
    if (v11Status != null) ...((v11Status!['agents'] as List? ?? const []).map<Widget>((a) => Card(child: ListTile(leading: const Icon(Icons.smart_toy_outlined), title: Text(a['name']?.toString() ?? 'Agent'), subtitle: Text(a['skills']?.toString() ?? ''))))),
    const SizedBox(height: 10),
    if (v11Obs != null) Card(child: ListTile(leading: const Icon(Icons.insights_outlined), title: const Text('Observability'), subtitle: Text('Tasks: ${v11Obs!['tasks'] ?? 0} · Active: ${v11Obs!['active'] ?? 0} · Failed: ${v11Obs!['failed'] ?? 0}'))),
    Row(children: [
      Expanded(child: FilledButton.icon(onPressed: () async { try { final r=await widget.api.v11Benchmark(); if(!mounted)return; showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('V11 Benchmark'),content:SelectableText('Passed: ${r['passed']}/${r['total']}\nScore: ${r['score']}%\n${r['note']}'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close'))])); } catch(e){ _error(e); } }, icon: const Icon(Icons.science_outlined), label: const Text('Run benchmark'))),
      const SizedBox(width: 10),
      Expanded(child: OutlinedButton.icon(onPressed: () async { try { final r=await widget.api.v11Plan('Analyze this project and propose the safest high-confidence implementation plan.', projectId: activeProjectId); if(!mounted)return; showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Lead Agent Plan'),content:SizedBox(width:720,height:500,child:SingleChildScrollView(child:SelectableText(const JsonEncoder.withIndent('  ').convert(r)))),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close'))])); } catch(e){ _error(e); } }, icon: const Icon(Icons.account_tree_outlined), label: const Text('Inspect plan'))),
    ]),
  ]);

  Widget _settings() => ListView(padding: const EdgeInsets.all(24), children: [
        const Text('NexCode AI', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('V9 Autonomous Developer Platform', style: TextStyle(color: NexColors.violet, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        const Text('The mobile app is a client. AI provider keys, sandbox execution and GitHub credentials stay on the backend.', style: TextStyle(color: NexColors.muted)),
        const SizedBox(height: 24),
        Card(child: ListTile(leading: const Icon(Icons.security), title: const Text('Security'), subtitle: const Text('Safe-static by default, with Docker sandbox boundaries for real project execution.'))),
        Card(child: ListTile(leading: const Icon(Icons.psychology_alt), title: const Text('Agent brain'), subtitle: const Text('Plan, search, research, impact analysis, implementation, review, test, repair and delivery.'))),
        Card(child: ListTile(leading: const Icon(Icons.hub_outlined), title: const Text('Parallel analysts'), subtitle: const Text('Architecture, security and testing reviewers can run concurrently on the same task.'))),
        Card(child: ListTile(leading: const Icon(Icons.public), title: const Text('Research'), subtitle: const Text('Fast web search and multi-pass deep research with evidence-oriented synthesis.'))),
      ]);

  Widget _brand() => Row(children: [
        Container(width: 38, height: 38, decoration: BoxDecoration(gradient: const LinearGradient(colors: [NexColors.purple, NexColors.cyan]), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.auto_awesome, color: Colors.white)),
        const SizedBox(width: 10),
        const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('NexCode', style: TextStyle(fontWeight: FontWeight.w900)), Text('Autonomous Dev', style: TextStyle(fontSize: 10, color: NexColors.muted))]),
      ]);

  Widget _nav(IconData icon, String label, int index) => ListTile(selected: tab == index, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), leading: Icon(icon), title: Text(label), onTap: () => setState(() => tab = index));

  Widget _fullSidebar() => Container(
        width: 278,
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 12),
        decoration: const BoxDecoration(color: NexColors.surface, border: Border(right: BorderSide(color: NexColors.border))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          _brand(),
          const SizedBox(height: 22),
          _nav(Icons.chat_bubble_outline, 'New chat', 0),
          _nav(Icons.folder_open, 'Projects', 1),
          _nav(Icons.rocket_launch_outlined, 'V9 Engine', 2),
          _nav(Icons.settings_outlined, 'Settings', 3),
          _nav(Icons.hub_rounded, 'Agent Core V11', 4),
          const SizedBox(height: 14),
          const Text('RECENT', style: TextStyle(fontSize: 10, color: NexColors.muted, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Expanded(
            child: convs.isEmpty
                ? const Center(child: Text('No conversations yet.', style: TextStyle(color: NexColors.muted)))
                : ListView.builder(
                    itemCount: convs.length > 12 ? 12 : convs.length,
                    itemBuilder: (_, i) {
                      final c = convs[i];
                      return ListTile(
                        dense: true,
                        leading: const Icon(Icons.chat_outlined, size: 17),
                        title: Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        onTap: () async {
                          final m = await widget.api.conversation(c.id);
                          if (!mounted) return;
                          setState(() {
                            conversationId = c.id;
                            messages..clear()..addAll(m);
                            tab = 0;
                          });
                        },
                      );
                    },
                  ),
          ),
          FilledButton.icon(onPressed: visualDebug, icon: const Icon(Icons.visibility_outlined), label: const Text('Visual debugger')),
        ]),
      );

  Widget _topbar() => Container(height: 70, padding: const EdgeInsets.symmetric(horizontal: 18), decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: NexColors.border))), child: Row(children: [
        if (MediaQuery.sizeOf(context).width <= 900) _brand(),
        const Spacer(),
        if (activeProject != null) _chip(Icons.folder, activeProject!.name),
        const SizedBox(width: 8),
        _chip(Icons.memory, mode == 'auto' ? 'Auto' : mode),
        const SizedBox(width: 8),
        _chip(Icons.public, webMode == 'deep' ? 'Deep Research' : webMode == 'off' ? 'Web Off' : 'Web'),
      ]));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Row(children: [
          if (MediaQuery.sizeOf(context).width > 900) _fullSidebar(),
          Expanded(child: Column(children: [_topbar(), Expanded(child: tab == 0 ? _chat() : tab == 1 ? _projects() : tab == 2 ? _v7Dashboard() : tab == 4 ? _v11Dashboard() : _settings()), if (tab == 0) _composer()])),
        ]),
      ),
    );
  }
}
