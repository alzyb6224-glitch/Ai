import 'package:flutter/material.dart';
import 'package:flutter_web_auth_2/flutter_web_auth_2.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  final ApiService api;
  const LoginScreen({super.key, required this.api});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final name = TextEditingController();
  bool register = false;
  bool busy = false;
  bool obscure = true;

  @override
  void dispose() { email.dispose(); password.dispose(); name.dispose(); super.dispose(); }

  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> go() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) { _message('اكتب البريد وكلمة المرور أولًا'); return; }
    setState(() => busy = true);
    try {
      if (register) {
        await widget.api.register(email.text.trim(), password.text, name.text.trim().isEmpty ? 'Developer' : name.text.trim());
      }
      await widget.api.login(email.text.trim(), password.text);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomeScreen(api: widget.api)));
    } catch (e) { if (mounted) _message(e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> oauth(String provider) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final url = await widget.api.oauthStart(provider);
      final result = await FlutterWebAuth2.authenticate(url: url, callbackUrlScheme: 'nexcode');
      final uri = Uri.tryParse(result);
      final token = uri?.queryParameters['token'];
      if (token == null || token.isEmpty) throw Exception('لم يتم استلام جلسة تسجيل الدخول');
      await widget.api.finishOAuthToken(token);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomeScreen(api: widget.api)));
    } catch (e) { if (mounted) _message(e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Widget social(String provider, String label, IconData icon) {
    return Expanded(child: OutlinedButton.icon(
      onPressed: busy ? null : () => oauth(provider),
      icon: Icon(icon, size: 20), label: Text(label),
      style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        const Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: RadialGradient(center: Alignment.topCenter, radius: 1.25, colors: [NexColors.surface2, NexColors.background], stops: [0, .72])))),
        SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(22), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 520), child: Column(children: [
          Container(width: 78, height: 78, decoration: BoxDecoration(shape: BoxShape.circle, gradient: const LinearGradient(colors: [NexColors.purple, NexColors.cyan]), boxShadow: [BoxShadow(color: NexColors.purple.withValues(alpha: .25), blurRadius: 36, spreadRadius: 3)]), child: const Icon(Icons.auto_awesome, color: Colors.white, size: 35)),
          const SizedBox(height: 18), const Text('NexCode AI', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, letterSpacing: -.8)),
          const SizedBox(height: 8), const Text('Build. Debug. Review. Deploy. All in one intelligent workspace.', textAlign: TextAlign.center, style: TextStyle(color: NexColors.muted, height: 1.45, fontSize: 15)),
          const SizedBox(height: 28),
          Row(children: [social('google','Google', Icons.g_mobiledata), const SizedBox(width: 10), social('apple','Apple', Icons.apple)]),
          const SizedBox(height: 10),
          Row(children: [social('github','GitHub', Icons.code), const SizedBox(width: 10), social('microsoft','Microsoft', Icons.window)]),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: busy ? null : () => oauth('discord'), icon: const Icon(Icons.chat_bubble_outline), label: const Text('Continue with Discord'), style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)))),
          const SizedBox(height: 24),
          Row(children: [const Expanded(child: Divider()), Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text('or use email', style: TextStyle(color: NexColors.muted))), const Expanded(child: Divider())]),
          const SizedBox(height: 18),
          if (register) ...[TextField(controller: name, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Name', prefixIcon: Icon(Icons.person_outline))), const SizedBox(height: 12)],
          TextField(controller: email, keyboardType: TextInputType.emailAddress, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.mail_outline))),
          const SizedBox(height: 12), TextField(controller: password, obscureText: obscure, onSubmitted: (_) => go(), decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined)))),
          const SizedBox(height: 18),
          SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : go, child: Padding(padding: const EdgeInsets.symmetric(vertical: 15), child: busy ? const SizedBox(width: 20,height:20,child:CircularProgressIndicator(strokeWidth:2)) : Text(register ? 'Create your NexCode account' : 'Sign in to NexCode')))),
          const SizedBox(height: 6), TextButton(onPressed: busy ? null : () => setState(() => register = !register), child: Text(register ? 'Already have an account? Sign in' : 'Create an account')),
          const SizedBox(height: 16), const Text('By continuing, you agree to use NexCode responsibly and keep your account secure.', textAlign: TextAlign.center, style: TextStyle(color: NexColors.muted, fontSize: 12, height: 1.4)),
        ]))))),
      ]),
    );
  }
}
