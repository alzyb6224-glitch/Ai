import 'dart:convert';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config.dart';
import '../models/models.dart';

class ApiService {
  final SharedPreferences prefs;
  ApiService(this.prefs);
  String get base => AppConfig.apiBaseUrl;
  String? get token => prefs.getString('token');
  Map<String,String> headers({bool jsonType=true}) => {
    if (jsonType) 'Content-Type':'application/json',
    if (token != null) 'Authorization':'Bearer $token',
  };
  Future<Map<String,dynamic>> register(String email,String password,String name) async {
    final r=await http.post(Uri.parse('$base/auth/register'),headers:headers(),body:jsonEncode({'email':email,'password':password,'display_name':name})); return _decode(r);
  }
  Future<Map<String,dynamic>> login(String email,String password) async {
    final r=await http.post(Uri.parse('$base/auth/login'),headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'username=${Uri.encodeQueryComponent(email)}&password=${Uri.encodeQueryComponent(password)}');
    final d=_decode(r); await prefs.setString('token',d['access_token']); return d;
  }
  Future<void> logout()=>prefs.remove('token');
  Future<Map<String,dynamic>> sendChat(String message,{int? conversationId,String mode='auto',int? projectId,String webMode='auto'}) async {
    final r=await http.post(Uri.parse('$base/chat'),headers:headers(),body:jsonEncode({'message':message,'conversation_id':conversationId,'mode':mode,'project_id':projectId,'web_mode':webMode})); return _decode(r);
  }
  Future<Map<String,dynamic>> task(int id) async { final r=await http.get(Uri.parse('$base/tasks/$id'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<List<ConversationModel>> conversations() async { final r=await http.get(Uri.parse('$base/conversations'),headers:headers(false)); final d=_decode(r) as List; return d.map((e)=>ConversationModel(id:e['id'],title:e['title'])).toList(); }
  Future<List<ChatMessage>> conversation(int id) async { final r=await http.get(Uri.parse('$base/conversations/$id'),headers:headers(false)); final d=_decode(r); return (d['messages'] as List).map((e)=>ChatMessage(role:e['role'],content:e['content'])).toList(); }
  Future<ProjectModel> createProject(String name,String description) async { final r=await http.post(Uri.parse('$base/projects'),headers:headers(),body:jsonEncode({'name':name,'description':description})); final d=_decode(r); return ProjectModel(id:d['id'],name:d['name'],description:d['description']??''); }
  Future<List<ProjectModel>> projects() async { final r=await http.get(Uri.parse('$base/projects'),headers:headers(false)); final d=_decode(r) as List; return d.map((e)=>ProjectModel(id:e['id'],name:e['name'],description:e['description']??'')).toList(); }
  Future<int> uploadProjectFile(int projectId,PlatformFile file) async { final bytes=file.bytes; if(bytes==null) throw Exception('Could not read file'); final req=http.MultipartRequest('POST',Uri.parse('$base/projects/$projectId/files/upload')); req.headers['Authorization']='Bearer $token'; req.files.add(http.MultipartFile.fromBytes('files',bytes,filename:file.name)); final r=await req.send(); final text=await r.stream.bytesToString(); if(r.statusCode>=400) throw Exception(text); return (jsonDecode(text)['uploaded'] as num).toInt(); }
  Future<List<Map<String,dynamic>>> projectFiles(int id) async { final r=await http.get(Uri.parse('$base/projects/$id/files'),headers:headers(false)); return List<Map<String,dynamic>>.from(_decode(r)); }
  Future<List<Map<String,dynamic>>> searchProject(int id,String q) async { final r=await http.get(Uri.parse('$base/projects/$id/search?q=${Uri.encodeQueryComponent(q)}'),headers:headers(false)); return List<Map<String,dynamic>>.from(_decode(r)); }
  Future<Map<String,dynamic>> analyzeProject(int id) async { final r=await http.get(Uri.parse('$base/projects/$id/intelligence'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> quality(int id,{bool build=false,bool install=false}) async { final r=await http.get(Uri.parse('$base/projects/$id/quality?build=$build&install=$install'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> executeProject(int id,{bool build=false,bool install=false}) async { final r=await http.post(Uri.parse('$base/projects/$id/execute'),headers:headers(),body:jsonEncode({'build':build,'install':install})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> terminal(int id,List<String> command) async { final r=await http.post(Uri.parse('$base/projects/$id/terminal'),headers:headers(),body:jsonEncode({'command':command})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> gitInfo(int id) async { final r=await http.get(Uri.parse('$base/projects/$id/git'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<List<Map<String,dynamic>>> revisions(int id) async { final r=await http.get(Uri.parse('$base/projects/$id/revisions'),headers:headers(false)); return List<Map<String,dynamic>>.from(_decode(r)); }
  Future<Map<String,dynamic>> rollbackRevision(int id,int rev) async { final r=await http.post(Uri.parse('$base/projects/$id/revisions/$rev/rollback'),headers:headers()); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> memory(int id) async { final r=await http.get(Uri.parse('$base/projects/$id/memory'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<void> saveMemory(int id,Map<String,dynamic> data) async { final r=await http.put(Uri.parse('$base/projects/$id/memory'),headers:headers(),body:jsonEncode({'data':data})); _decode(r); }
  Future<void> clearMemory(int id) async { final r=await http.delete(Uri.parse('$base/projects/$id/memory'),headers:headers(false)); _decode(r); }
  Future<Map<String,dynamic>> tools(int id) async { final r=await http.get(Uri.parse('$base/projects/$id/tools'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<String> generateImage(String prompt,{String size='1024x1024'}) async { final r=await http.post(Uri.parse('$base/images/generate'),headers:headers(),body:jsonEncode({'prompt':prompt,'size':size,'quality':'high'})); final d=_decode(r); return d['image_base64']; }
  Future<Map<String,dynamic>> analyzeScreenshot(PlatformFile file,{String prompt=''}) async { final bytes=file.bytes; if(bytes==null) throw Exception('Could not read image'); final req=http.MultipartRequest('POST',Uri.parse('$base/images/analyze')); req.headers['Authorization']='Bearer $token'; req.fields['prompt']=prompt; req.files.add(http.MultipartFile.fromBytes('image',bytes,filename:file.name)); final r=await req.send(); final text=await r.stream.bytesToString(); if(r.statusCode>=400) throw Exception(text); return Map<String,dynamic>.from(jsonDecode(text)); }
  Future<Map<String,dynamic>> v7Status() async { final r=await http.get(Uri.parse('$base/platform/v7'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v7Benchmark() async { final r=await http.get(Uri.parse('$base/v7/benchmark'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> intelligenceV2(int id) async { final r=await http.get(Uri.parse('$base/projects/$id/intelligence/v2'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> githubPush(int id,String ownerRepo,String branch) async { final r=await http.post(Uri.parse('$base/projects/$id/github/push'),headers:headers(),body:jsonEncode({'owner_repo':ownerRepo,'branch':branch})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v8Status() async { final r=await http.get(Uri.parse('$base/platform/v8'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v8Benchmark() async { final r=await http.get(Uri.parse('$base/v8/benchmark'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> computerPlan(String goal) async { final r=await http.post(Uri.parse('$base/v8/computer/plan'),headers:headers(),body:jsonEncode({'goal':goal})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> dataAnalyze(String data,{String format='csv',String x='',String y=''}) async { final r=await http.post(Uri.parse('$base/v8/data/analyze'),headers:headers(),body:jsonEncode({'data':data,'format':format,'x':x,'y':y})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> voiceStatus() async { final r=await http.get(Uri.parse('$base/v8/voice/status'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v8MemorySearch(int id,String query) async { final r=await http.post(Uri.parse('$base/projects/$id/memory/v2/search'),headers:headers(),body:jsonEncode({'query':query,'limit':8})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> createShare(int id,{String role='viewer'}) async { final r=await http.post(Uri.parse('$base/projects/$id/share'),headers:headers(),body:jsonEncode({'role':role,'ttl_seconds':86400})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> githubImport(String name,String url,String description) async { final r=await http.post(Uri.parse('$base/github/import'),headers:headers(),body:jsonEncode({'name':name,'repo_url':url,'description':description})); return Map<String,dynamic>.from(_decode(r)); }

  Future<List<Map<String,dynamic>>> oauthProviders() async {
    final r = await http.get(Uri.parse('$base/auth/oauth/providers'), headers: headers(false));
    final d = _decode(r) as Map<String,dynamic>;
    return List<Map<String,dynamic>>.from(d['providers'] ?? const []);
  }
  Future<String> oauthStart(String provider) async {
    final r = await http.post(Uri.parse('$base/auth/oauth/start'), headers: headers(), body: jsonEncode({'provider': provider}));
    final d = _decode(r) as Map<String,dynamic>;
    return d['authorization_url'] as String;
  }
  Future<void> finishOAuthToken(String tokenValue) async {
    if (tokenValue.isEmpty) throw Exception('OAuth did not return a session');
    await prefs.setString('token', tokenValue);
  }

  Future<Map<String,dynamic>> v11Status() async { final r=await http.get(Uri.parse('$base/platform/v11'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v11Plan(String task,{int? projectId,double budgetUsd=999}) async { final r=await http.post(Uri.parse('$base/v11/agent/plan'),headers:headers(),body:jsonEncode({'task':task,'project_id':projectId,'budget_usd':budgetUsd})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v11Run(String task,{int? projectId,String mode='auto',String webMode='auto',bool approved=false}) async { final path=projectId==null?'$base/v11/agent/run':'$base/v11/projects/$projectId/agent/run'; final r=await http.post(Uri.parse(path),headers:headers(),body:jsonEncode({'task':task,'project_id':projectId,'mode':mode,'web_mode':webMode,'approved':approved})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v11RunAsync(int projectId,String task,{String mode='auto',String webMode='auto',bool approved=false}) async { final r=await http.post(Uri.parse('$base/v11/projects/$projectId/agent/run-async'),headers:headers(),body:jsonEncode({'task':task,'project_id':projectId,'mode':mode,'web_mode':webMode,'approved':approved})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v11Task(int taskId) async { final r=await http.get(Uri.parse('$base/v11/tasks/$taskId'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v11CancelTask(int taskId) async { final r=await http.post(Uri.parse('$base/v11/tasks/$taskId/cancel'),headers:headers()); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v11Preflight(int projectId) async { final r=await http.get(Uri.parse('$base/v11/projects/$projectId/preflight'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v11Observability() async { final r=await http.get(Uri.parse('$base/v11/observability'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v11Benchmark() async { final r=await http.get(Uri.parse('$base/v11/benchmark'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v11Release(int projectId) async { final r=await http.get(Uri.parse('$base/v11/release/$projectId'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v11Feedback(int taskId,String feedback,{bool accepted=true}) async { final r=await http.post(Uri.parse('$base/v11/feedback'),headers:headers(),body:jsonEncode({'task_id':taskId,'feedback':feedback,'accepted':accepted})); return Map<String,dynamic>.from(_decode(r)); }

  Future<Map<String,dynamic>> v9Status() async { final r=await http.get(Uri.parse('$base/platform/v9'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v9Route(String task,{int inputTokens=0,double budgetUsd=999}) async { final r=await http.post(Uri.parse('$base/v9/models/route'),headers:headers(),body:jsonEncode({'task':task,'input_tokens':inputTokens,'budget_usd':budgetUsd})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v9BrowserPlan(String goal,List<String> urls) async { final r=await http.post(Uri.parse('$base/v9/browser/plan'),headers:headers(),body:jsonEncode({'goal':goal,'urls':urls})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v9Review(int id) async { final r=await http.post(Uri.parse('$base/v9/agents/review'),headers:headers(),body:jsonEncode({'project_id':id})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v9SecurityAudit(int id) async { final r=await http.post(Uri.parse('$base/v9/agents/security-audit'),headers:headers(),body:jsonEncode({'project_id':id})); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v9Graph(int id) async { final r=await http.get(Uri.parse('$base/projects/$id/graph/v3'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v9DeployStatus() async { final r=await http.get(Uri.parse('$base/v9/deploy/status'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v9MobileActions() async { final r=await http.get(Uri.parse('$base/v9/mobile/quick-actions'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }
  Future<Map<String,dynamic>> v9ProductionReadiness() async { final r=await http.get(Uri.parse('$base/v9/production-readiness'),headers:headers(false)); return Map<String,dynamic>.from(_decode(r)); }

  dynamic _decode(http.Response r){ final body=r.body.isEmpty?'{}':r.body; final d=jsonDecode(body); if(r.statusCode<200||r.statusCode>=300){ throw Exception(d is Map ? (d['detail']??'Request failed'):'Request failed'); } return d; }
}
