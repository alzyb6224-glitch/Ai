import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'services/api_service.dart';
import 'theme/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final api = ApiService(prefs);
  runApp(NexCodeApp(api: api));
}

class NexCodeApp extends StatelessWidget {
  final ApiService api;
  const NexCodeApp({super.key, required this.api});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NexCode AI',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: api.isLoggedIn ? HomeScreen(api: api) : LoginScreen(api: api),
    );
  }
}
