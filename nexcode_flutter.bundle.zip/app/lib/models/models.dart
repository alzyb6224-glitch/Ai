class ChatMessage {
  final String role;
  final String content;
  final String? route;
  final List<Map<String,dynamic>> actions;
  final List<Map<String,dynamic>> pipeline;
  final Map<String,dynamic> meta;
  const ChatMessage({required this.role,required this.content,this.route,this.actions=const [],this.pipeline=const [],this.meta=const {}});
  bool get isUser=>role=='user';
}
class ProjectModel { final int id; final String name; final String description; const ProjectModel({required this.id,required this.name,required this.description}); }
class ConversationModel { final int id; final String title; const ConversationModel({required this.id,required this.title}); }
