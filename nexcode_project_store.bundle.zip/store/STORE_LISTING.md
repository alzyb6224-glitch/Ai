# NexCode AI — Store Listing Draft

## Short description
AI coding assistant for building, understanding, debugging, and improving software projects.

## Full description
NexCode AI is an AI workspace made for developers. Chat naturally, ask for architecture advice, write and explain code, debug errors, work with project files, and create images from prompts.

### Developer features
- Project-aware conversations
- Codebase and ZIP upload
- Coding, reasoning and writing modes
- Debugging and refactoring assistance
- Persistent conversations
- Image generation
- Secure backend architecture for AI credentials

## Privacy summary
The app should clearly explain what information is sent to the backend and AI provider, how long it is stored, and how users can delete it. Publish an actual privacy policy before store submission.
