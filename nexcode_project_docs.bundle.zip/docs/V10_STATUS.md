# NexCode V10 Status

V10 keeps the full V9 engineering-agent stack and adds a configurable production-oriented authentication layer.

## Verified locally
- Python compileall: passed
- Regression/unit tests: 42 passed
- V9 contract benchmark: 20/20 (100%) in deterministic fixture mode
- Flutter Dart lexical balance scan: passed
- OAuth state signing/tamper rejection tests: passed
- Provider registry: Google, Apple, GitHub, Microsoft, Discord

## Authentication
- Email/password remains available.
- OAuth provider registry and `/api/auth/oauth/*` routes added.
- Signed, expiring OAuth state.
- Account creation/linking by normalized email.
- NexCode session issued after successful provider authentication.
- Apple ID-token signature verification uses Apple's JWKS when the production `python-jose` dependency is installed.
- Flutter uses `flutter_web_auth_2` for provider consent and `nexcode://oauth/callback` session handoff.

## Important runtime boundary
External provider login itself was not executed in this environment because it requires real Google/Apple/GitHub/Microsoft/Discord credentials and registered redirect URIs. Provider buttons only advertise as enabled when credentials are configured. Production deployment must also register the mobile deep-link URL scheme on Android/iOS.

## Evaluation boundary
The 20-task V9 benchmark is a deterministic internal contract suite; it is not an official SWE-bench score. The SWE harness is capable of cloning allowed public GitHub repositories and running task commands when network access is available.
