# NexCode AI V6 Architecture

```text
Flutter Android Client
        |
        | HTTPS/JWT
        v
FastAPI API
  |        |        |
  |        |        +--> Images / Vision
  |        +-----------> Web / Deep Research
  +--------------------> Autonomous Orchestrator
                           |
       +-------------------+-------------------+
       |          |          |        |        |
    Project    Code       Parallel   Quality   Git
    Search     Intel       Analysts   Engine   /GitHub
       |          |          |        |        |
       +----------+----------+--------+--------+
                           |
                       AI Provider
                           |
                +----------+----------+
                |                     |
          File Actions            Repair Loop
                |                     |
                +-------- Sandbox ---+
```

The orchestrator is the product's control plane. The model proposes reasoning/actions; deterministic services validate paths, run approved checks, calculate impact, save revisions and record task state.
