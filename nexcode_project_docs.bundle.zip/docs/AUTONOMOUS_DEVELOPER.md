# NexCode AI V6 — Autonomous Developer Platform

V6 combines the requested stages into one controlled execution system:

**Understand → Plan → Project Search → Web/Deep Research → Impact Analysis → Implement → Review → Test → Repair → Retest → Deliver**

## V6 capabilities

### Agent brain
- One chat experience with internal routing (build/debug/review/analyze/write/general).
- Bounded repair loop; the agent must stop after the configured retry count.
- Project context, memory and targeted search are supplied before implementation.
- Optional parallel analysts: architecture, security and testing.

### Terminal and sandbox
- Safe command allowlist for Python, Node, Flutter, Go, Rust and read-only Git helpers.
- `safe_static` is the default and does not execute arbitrary project code.
- `docker` mode runs project commands inside a disposable container with no network by default, capped CPU/RAM/processes/time, dropped Linux capabilities and a temporary filesystem.
- Dependency installation and builds are disabled by default and must be explicitly enabled server-side.

### Code intelligence
- Filename/token search.
- Symbol extraction for common languages.
- Import relationship approximation.
- Reverse dependency graph and impact analysis.
- Potential duplicate/dead-symbol hints.

### Research engine
- Query planner.
- Fast multi-query search.
- Deep research mode with additional query passes.
- Parallel web searches.
- Evidence-oriented synthesis with source URLs when the provider exposes them.
- Explicit uncertainty/gap reporting.

### Git/GitHub
- Local Git snapshots, branches, commit, diff and rollback.
- Public GitHub repository import (HTTPS only).
- Server-side GitHub token support for pull-request creation; tokens never belong in the Flutter app.

### Visual debugging
- Screenshot upload to the vision-capable model.
- The result distinguishes visible facts from hypotheses.

### Quality engine
- JSON syntax checks.
- Ecosystem-aware tests/build checks.
- Lightweight code-security findings.
- Dependency declaration checks.
- Regression signal based on actual verification.
- Quality score is an aggregate heuristic, not a guarantee.

### Project memory
Memory stores structured project information such as summary, languages, recent runs and findings. It is user-accessible through the API and can be cleared.

### Tool registry / MCP-ready extensibility
All capabilities are represented in a server-side tool registry. The registry is the extension boundary for adding MCP/HTTP/function tool adapters later without changing the chat UX.

## API additions

- `GET /api/platform/capabilities`
- `GET /api/projects/{id}/intelligence`
- `GET /api/projects/{id}/quality`
- `POST /api/projects/{id}/terminal`
- `GET/PUT/DELETE /api/projects/{id}/memory`
- `GET /api/projects/{id}/tools`
- `POST /api/github/import`
- `POST /api/projects/{id}/github/prepare`
- `POST /api/projects/{id}/github/pull-request`
- `GET /api/tasks/{id}`

## Trust model
NexCode must never claim that a build, test, web search, deployment or code change happened unless the backend performed it and recorded the result.
