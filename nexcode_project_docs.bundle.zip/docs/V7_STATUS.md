# NexCode AI V7 status

V7 upgrades the V6 autonomous developer foundation into a measurable, safety-gated workflow.

## Seven pillars

1. **Real-world Agent**: the existing end-to-end orchestrator now injects Project Intelligence 2.0 context and exposes bounded healing metadata.
2. **Real Sandbox**: hardened Docker execution is supported; `safe_static` remains the default fallback when Docker is unavailable. The policy enforces network policy, read-only root, dropped capabilities, no-new-privileges, resource limits and a process limit.
3. **100–500 Benchmark**: V7 ships with **120 deterministic tasks** spanning bug fixes, features, security, sandbox safety, project intelligence and tool policy. The runner produces a machine-readable report.
4. **Self-Healing**: repair cycles are bounded and repeated failures trigger a strategy replan instead of infinite retries.
5. **Project Intelligence 2.0**: entrypoints, tests, symbols, imports, reverse dependencies and hotspots are computed locally and included in the agent context.
6. **GitHub full workflow foundation**: public import, branch preparation, token-safe push via `GIT_ASKPASS`, and PR creation are available server-side. Live GitHub operations still require a configured token and a network-connected deployment.
7. **UX polish**: a V7 Engine dashboard is exposed in the Flutter client with sandbox health, pillar status and a one-tap benchmark run.

## Verification in this package

- V6 regression suite: **6/6 passed**.
- V7 benchmark: **120/120 fixture checks passed (100%)**.
- Backend `compileall`: passed.
- Flutter delimiter/static syntax scan: passed.
- Docker runtime was not executed because Docker is not installed in the current build environment.
- Live OpenAI/GitHub network actions were not executed because credentials/network are not available in this build environment.
- Flutter APK/AAB was not built because the Flutter SDK is not installed in the current build environment.

These limitations are intentionally reported rather than hidden.
