# NexCode AI — market-grade roadmap

The current build is a strong product foundation, not a claim of parity with every frontier AI product.

## Tier 1 — already represented in this build
- One intelligent chat experience
- Repository-aware context
- Build/debug/review/analyze/write routing
- Structured change proposals
- Explicit change application API
- Project analysis endpoint
- Image generation endpoint
- Android APK/AAB CI path

## Tier 2 — next high-value engineering
- Streaming token-by-token chat
- Diff viewer + accept/reject per file
- Semantic code search / embeddings
- GitHub import/export and branches
- Real test execution in isolated containers
- Terminal with strict sandboxing
- Web retrieval with citations
- Vision/file understanding
- Voice input/output

## Tier 3 — scale and reliability
- PostgreSQL + migrations
- Redis queues/cache
- S3-compatible object storage
- Per-user quotas and billing
- model routing by task/cost
- observability, tracing, evaluations
- secure release signing and Play Store compliance
