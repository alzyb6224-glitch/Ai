# NexCode V10 Authentication

NexCode keeps email/password login and adds a production-oriented OAuth layer for Google, Apple, GitHub, Microsoft and Discord.

## Backend environment

Set these in `backend/.env` (never commit them):

```env
SECRET_KEY=replace-with-a-long-random-secret
OAUTH_CALLBACK_BASE=https://api.example.com
OAUTH_MOBILE_REDIRECT_URI=nexcode://oauth/callback

GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
APPLE_CLIENT_ID=...
APPLE_CLIENT_SECRET=...
GITHUB_OAUTH_CLIENT_ID=...
GITHUB_OAUTH_CLIENT_SECRET=...
MICROSOFT_CLIENT_ID=...
MICROSOFT_CLIENT_SECRET=...
DISCORD_CLIENT_ID=...
DISCORD_CLIENT_SECRET=...
```

Providers are only advertised by `/api/auth/oauth/providers` when both client ID and client secret are configured. The authorization state is signed and expires after 10 minutes. Apple ID tokens are verified against Apple's published signing keys when `python-jose` is installed (it is already pinned in `requirements.txt`).

## OAuth callback

The provider redirect URI is:

`https://<API-DOMAIN>/api/auth/oauth/callback/<provider>`

The callback creates or links the NexCode user by normalized email and returns a NexCode session through the configured `nexcode://oauth/callback` deep link for the Flutter client.

## Flutter

The mobile client uses `flutter_web_auth_2` to open the provider consent page and receive the deep-link callback. The Android/iOS host application must register the `nexcode` URL scheme before release. The current repository intentionally does not contain generated Android/iOS folders, so those platform registration files are not fabricated.

## Provider setup references

Supabase's current auth documentation is also compatible with Google and Apple if you prefer Supabase Auth as the identity provider instead of NexCode's direct OAuth layer. Google supports web and native apps; Apple supports web and native Apple platforms. See the official references in the project notes.
