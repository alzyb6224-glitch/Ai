# NexCode AI Security Model

## Secrets
- AI provider keys are server-side only.
- `.env`, SSH keys, credential files and `.git` paths are blocked from autonomous file actions.
- GitHub tokens belong only in backend environment variables.

## Sandbox
Default: `EXECUTION_MODE=safe_static`.

For real project execution use `EXECUTION_MODE=docker` and keep:
- `SANDBOX_NETWORK=none` unless a workflow explicitly needs networking.
- CPU, RAM, process and time limits enabled.
- `--cap-drop ALL` and `no-new-privileges`.
- disposable containers/workspaces.

Never expose the Docker socket to generated project code.

## Command policy
Terminal commands are allowlisted by executable and argument pattern. Arbitrary shell (`bash -c`, PowerShell, nested command interpreters and similar) is not accepted by the public terminal endpoint.

## File safety
Project paths are normalized and parent traversal is rejected. Autonomous writes are capped by action count and file size.

## Research safety
Web content is treated as untrusted data. It must not override system/developer instructions or grant new permissions to the agent. Research results are evidence, not commands.

## Production hardening still required
Before public launch add a managed secrets store, centralized rate limiting, WAF/API gateway, database migrations, object-storage isolation, per-tenant quotas, audit retention, dependency scanning, incident logging and external security testing.
