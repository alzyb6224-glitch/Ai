# NexCode AI Agent Engine

NexCode now treats the assistant as one intelligent system with internal routing. It can route a request into build, debug, review, analysis, writing, image, or general work while preserving one conversation experience.

## End-to-end request flow

1. Mobile app sends one user request.
2. Backend authenticates the user and loads recent conversation history.
3. If a project is selected, backend builds a repository tree and a prioritized context pack.
4. Agent routing selects the best internal role.
5. The model produces a human result plus optional structured file actions.
6. Actions are returned as a preview proposal; the product can explicitly apply them through the `/projects/{id}/apply` endpoint.
7. Project analysis is available through `/projects/{id}/analyze`.

## Why this is stronger

The product is no longer only a chat UI. It has repository-aware context, explicit task routing, actionable file operations, project analysis, and a clear separation between planning and applying changes.

## Important production work still required

For a serious public launch, add a hardened isolated code runner, streaming responses, object storage for large projects, PostgreSQL, background jobs, rate limits, observability, abuse controls, migrations, automated tests, and signed Android release configuration.
