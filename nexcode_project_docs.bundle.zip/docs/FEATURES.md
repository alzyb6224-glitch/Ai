# NexCode AI feature set

## Unified intelligence
NexCode is presented as one assistant. Internal routing selects the most suitable approach without forcing users to pick a separate bot.

## Developer workspace
Project upload, project tree, file context, project analysis, conversation memory, and explicit file-action proposals.

## Engineering tasks
Architecture, implementation, debugging, refactoring, code review, testing guidance, API/backend/frontend/mobile work, documentation, and general technical questions.

## Creative tasks
Image generation from natural-language prompts.

## Change safety
Generated file changes are proposed as structured actions and should be shown to the user as a diff before application in a production UI.

## End-to-end implementation + research (current)
- Unified execution loop: understand → plan → project search → web research → implement → verify → repair → re-verify → deliver.
- Targeted repository search ranks files by query relevance before building the model context.
- Project search API: `GET /api/projects/{project_id}/search?q=...`.
- Web modes: off, automatic, focused, deep multi-query research.
- Revision snapshots are created before automated project changes.
- Safe verification checks are automatic; failed checks can trigger limited repair cycles.
- Final responses report execution status, changed files, repair cycles, checks and research depth.
