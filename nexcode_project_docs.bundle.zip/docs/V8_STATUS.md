# NexCode AI V8 Status

V8 is built on the V7 codebase and adds ten operational pillars:

1. Computer Agent: policy-gated action planning, approval gates for high-risk actions, and optional Playwright driver detection.
2. MCP + Connectors: stdio JSON-RPC MCP client with explicit command/tool allowlists.
3. Developer Memory 2.0: scoped memory with confidence, source, recency and retrieval scoring, stored inside project memory.
4. Interactive Workspace 2.0: versioned artifacts, SHA-256 hashes and unified diffs.
5. Deep Research 2.0: multi-question orchestration over the existing research provider with source de-duplication.
6. Data Analysis: safe CSV/JSON profiling and chart-spec generation without arbitrary user code execution.
7. Voice Developer: server-side STT/TTS provider interface plus developer-command intent extraction.
8. Background Agents: asynchronous in-process job management with status/result/error tracking.
9. Collaboration: expiring project viewer/editor share links.
10. Multimodal + Observability: asset intelligence and trace objects for developer execution telemetry.

## Verification

`backend/tests/test_v8_engine.py` covers all ten pillars plus the release gate and budget guard (23 passing tests including the V6/V7 regression suite). The V8 deterministic benchmark contains 200 tasks (20 per pillar) and is used to validate the evaluation harness itself.

Live external execution is intentionally not faked. In this environment, Docker/Flutter SDK and external provider credentials may be unavailable. V8 therefore reports those environment capabilities instead of claiming a live run.
