# NexCode AI V11 status

V11 turns the existing V10/V9 platform into a central Agent Core architecture.

## Implemented in code

- Central Lead Agent orchestration and intent classification.
- Minimal-context retrieval from project files, manifests and intelligence.
- Specialist team: Architect, Coder, Debugger, Researcher, Reviewer, Security, Tester, Dependency, Mobile and DevOps.
- Delegation brief passed into the implementation engine.
- Existing end-to-end implementation/review/verify/repair pipeline reused as the execution substrate.
- Long-running task wrapper with DB TaskRun records plus in-process background JobManager.
- Event tracing and observability summaries.
- Production security policy with explicit approval gates and secret redaction.
- Multi-model selection through the existing capability/context/budget router.
- Feedback stored into project memory for later context recall.
- Release checklist with quality/security/test/dependency gates and artifact hashing policy.
- V11 contract benchmark.
- Android CI workflow that generates Android platform files and builds APK/AAB, including OAuth deep-link configuration.
- V11 Flutter dashboard and project chat routing through Agent Core when a project is active.

## Verification

At the time of this release:

- Existing V1-V10 backend tests: 46 passing.
- Python compileall: passing.
- V11 contract benchmark: 8/8 (100%) on deterministic contracts.

## Honest environment limits

The local execution environment used for packaging does not contain the Flutter SDK, Android SDK, Docker daemon, real OAuth credentials, or cloud provider credentials. Therefore a real Android APK build and live third-party OAuth flow are delegated to the included GitHub Actions workflow/deployment environment rather than falsely marked as locally executed.

The V11 benchmark is an internal deterministic contract benchmark, not an official SWE-bench score.
