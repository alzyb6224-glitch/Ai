# Android / Google Play path

## Build on a computer
```bash
cd app
flutter create --platforms=android --org com.nexcodeai .
flutter pub get
flutter build apk --release --dart-define=NEXCODE_API_URL=https://YOUR-DOMAIN/api
flutter build appbundle --release --dart-define=NEXCODE_API_URL=https://YOUR-DOMAIN/api
```

## Build from a phone
Use the included GitHub Actions workflow. The phone is then only used to manage the repository, start the workflow, and download the build artifact.

## Before publishing
- Choose a permanent Android application ID.
- Create a signing key and protect it.
- Prepare a privacy policy URL.
- Prepare app icon, screenshots, store description, category and contact details.
- Complete Google's developer-account and testing requirements.
- Upload the AAB to Play Console.

Do not publish the same app with a changing application ID. Keep the signing key backed up securely.
