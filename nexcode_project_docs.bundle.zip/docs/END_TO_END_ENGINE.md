# NexCode AI — End-to-End Engineering Engine

NexCode now uses a single-agent execution pipeline instead of stopping at suggestions:

**Understand → Plan → Project Search → Web Research → Implement → Review → Verify → Repair → Re-verify → Deliver**

## What happens

1. The agent classifies the request and reads the project tree/context.
2. Web research is enabled automatically when the request needs current/online information, or explicitly via `web_mode=fast|deep`.
3. The model proposes structured file actions.
4. Actions are validated for path traversal and file-size limits, then applied automatically when `AUTO_APPLY_ACTIONS=true`.
5. A revision snapshot is stored before changes.
6. Safe static verification runs. Python uses `compileall`; JSON is parsed; JavaScript is checked with `node --check` when Node exists.
7. On failure, the repair agent receives the exact failure output and current project context, creates minimal corrective edits, and the engine re-runs verification up to `MAX_REPAIR_CYCLES`.
8. The final response reports status, changed file count, repair cycles, checks, and research depth.

## Web research

The backend can use the OpenAI Responses API web-search tool. Deep research first generates multiple focused queries, executes each search, then synthesizes the findings. The web layer is intentionally provider-neutral at the UI level: the user sees `Web`, `Deep web`, or `Web off` rather than a separate assistant.

## Safety

The default executor does not run arbitrary project scripts. This avoids silently executing package lifecycle hooks or untrusted tests. A future production runner should execute user code only inside a hardened, resource-limited container sandbox with network isolation and explicit approvals.
