# Build NexCode AI Android APK without a PC

NexCode's Flutter source can be built by GitHub Actions, so Android Studio is not required on the user's phone.

## 1. Put the project in a GitHub repository
Upload the project folder to a GitHub repository using the GitHub website/app.

## 2. Add the backend URL as a repository secret
Open **Settings → Secrets and variables → Actions** and create:

`NEXCODE_API_URL`

Set it to the public HTTPS URL of the NexCode backend, for example:

`https://your-api.example.com/api`

Do not put provider keys in the mobile app. Keep OpenAI/Anthropic/GitHub/OAuth secrets on the backend.

## 3. Run the Android workflow
Open **Actions → Android Build → Run workflow**.

The workflow generates the Android platform folder, configures the NexCode OAuth deep link, fetches Flutter packages, and creates:

- `app-release.apk` for direct Android installation/testing.
- `app-release.aab` for Play Console distribution.

## 4. Important backend requirement
The APK is the client. The Agent Core, model providers, sandbox, Git integrations and long-running workers live on the backend/server.

For real project execution, configure a deployment environment with the required Docker/Flutter/Node/Python tooling and enable the desired execution mode. Safe-static mode intentionally avoids running user project code.
