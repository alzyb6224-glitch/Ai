# V11 capability matrix

| Capability | V11 state | Runtime boundary |
|---|---|---|
| Central Agent Core | Implemented | Python backend |
| Lead Agent delegation | Implemented | Python backend |
| Specialist team | Implemented | Deterministic/static specialists + model implementation engine |
| Minimal context retrieval | Implemented | Project DB / code intelligence |
| Real project edits | Implemented | Existing orchestrator + guarded actions |
| Verification / repair loop | Implemented | Existing executor + repair engine |
| Long-running tasks | Implemented | DB TaskRun + async JobManager |
| Live activity | Implemented | Event trace + pipeline snapshots |
| Observability | Implemented | TaskRun events + dashboard endpoint |
| Security gates | Implemented | Approval policy + redaction + existing RBAC |
| Multi-model routing | Implemented | capability/context/budget/latency router |
| Learning | Implemented | feedback stored into project memory |
| MCP/tools/connectors | Implemented | existing V9/V8 ecosystem |
| Build/release gates | Implemented | quality/security/tests/approval/artifact policy |
| Android client | Prepared | GitHub Actions generates Android platform and builds APK/AAB |
| OAuth mobile deep link | Prepared | `nexcode://oauth/callback` Android manifest patch in CI |
| Official SWE-bench score | Not claimed | V11 uses internal contract benchmark; V9 has real harness plumbing |

The word “Implemented” means code and tests for the capability exist in this repository. It does not mean every external provider/device/cloud service has been live-tested from this packaging environment.
