# Production & Business Readiness

## Product surfaces
- Free developer workspace with limited runs.
- Pro tier for larger context, deep research, more agent runs and larger projects.
- Team tier for shared projects, permissions and audit history.
- Usage limits should be enforced by server-side quotas, never by hidden client-only checks.

## Required production services
- PostgreSQL for multi-tenant data.
- Object storage for project archives/screenshots.
- Redis/queue workers for long agent runs.
- Background execution service for sandbox jobs.
- Observability: request IDs, task traces, latency, errors, token usage and sandbox metrics.
- Billing provider integration.

## Reliability targets
Track task success, verification pass rate, regression rate, median task duration, repair cycles, user acceptance and cost per successful task.

## Evaluation
The repository includes a seed task set and an offline evaluation harness. A public benchmark should be built from 500+ curated tasks across bug fixing, features, refactors, analysis and research, with reproducible tests and human acceptance labels.
