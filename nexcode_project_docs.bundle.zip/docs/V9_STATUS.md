# NexCode AI V9 Status

V9 is the production-oriented expansion over V8. It adds model routing, browser/computer execution boundaries, MCP ecosystem registration, multi-agent research orchestration, Codebase Graph V3, bounded autonomous loops, a real SWE harness interface, enterprise security primitives, IDE/artifact primitives, realtime collaboration, memory learning, mobile/voice adapters, background jobs, code review, dependency analysis, security auditing and approval-gated deployment.

## Verified in this environment
- Python compileall: PASS
- Regression + V9 tests: 38/38 PASS
- V9 contract benchmark: 20/20 PASS
- Local HTTP Computer Use round-trip: PASS
- Local approved/blocked deployment execution guard: PASS
- ZIP integrity: validated after packaging
- Secret pattern scan: no committed credential-shaped literals found

## External dependencies not falsely claimed as live
- OpenAI/Anthropic live model calls require configured credentials.
- Live Playwright computer/browser interaction requires the optional Playwright runtime and browser binaries. Playwright 1.62.0 is listed in `backend/requirements-v9-optional.txt`.
- Official SWE-bench scoring requires the benchmark datasets/evaluation environment; the included V9 harness is capable of preparing a real worktree and running real test commands but does not fabricate an official leaderboard score.
- Provider deployments (Vercel/Render/Railway/etc.) require provider credentials and network access.
- Flutter SDK and Docker are environment-dependent and were not claimed as built/run when unavailable.
