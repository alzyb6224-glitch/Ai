from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.db.models import Base
from app.db.session import engine
from app.core.config import settings
from app.routers import auth, auth_social, chat, projects, images, health, platform, v7, v8, v9, v11

@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    Path("uploads").mkdir(exist_ok=True)
    yield
    await engine.dispose()

app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)
origins = [x.strip() for x in settings.cors_origins.split(",")]
app.add_middleware(CORSMiddleware, allow_origins=origins if origins != ["*"] else ["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(health.router, prefix="/api")
app.include_router(auth.router, prefix="/api/auth")
app.include_router(auth_social.router, prefix="/api/auth")
app.include_router(chat.router, prefix="/api")
app.include_router(projects.router, prefix="/api")
app.include_router(images.router, prefix="/api")
app.include_router(platform.router, prefix="/api")
app.include_router(v7.router, prefix="/api")
app.include_router(v8.router, prefix="/api")
app.include_router(v9.router, prefix="/api")
app.include_router(v11.router, prefix="/api")
