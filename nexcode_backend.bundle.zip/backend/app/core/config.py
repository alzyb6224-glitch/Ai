from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "NexCode AI"
    secret_key: str = "change-me-in-production"
    database_url: str = "sqlite+aiosqlite:///./nexcode.db"
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    openai_text_model: str = "gpt-5.6"
    openai_reasoning_model: str = "gpt-5.6"
    openai_coding_model: str = "gpt-5.6"
    openai_fast_model: str = "gpt-5.6-mini"
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-latest"
    google_client_id: str = ""
    google_client_secret: str = ""
    apple_client_id: str = ""
    apple_client_secret: str = ""
    github_oauth_client_id: str = ""
    github_oauth_client_secret: str = ""
    microsoft_client_id: str = ""
    microsoft_client_secret: str = ""
    discord_client_id: str = ""
    discord_client_secret: str = ""
    oauth_callback_base: str = "http://localhost:8000"
    oauth_mobile_redirect_uri: str = "nexcode://oauth/callback"
    openai_image_model: str = "gpt-image-2"
    cors_origins: str = "*"
    max_upload_mb: int = 25
    max_project_files: int = 1000
    max_file_chars: int = 2_000_000
    auto_apply_actions: bool = True
    max_repair_cycles: int = 2
    execution_mode: str = "safe_static"  # safe_static | docker
    sandbox_python_image: str = "python:3.13-slim"
    sandbox_node_image: str = "node:22-bookworm-slim"
    sandbox_flutter_image: str = "ghcr.io/cirruslabs/flutter:stable"
    sandbox_go_image: str = "golang:1.25-bookworm"
    sandbox_rust_image: str = "rust:1.90-slim"
    sandbox_timeout_seconds: int = 60
    sandbox_memory: str = "768m"
    sandbox_cpus: str = "1.0"
    sandbox_network: str = "none"  # none by default
    auto_dependency_install: bool = False
    auto_run_builds: bool = False
    git_enabled: bool = True
    git_root: str = "./data/git"
    max_pipeline_steps: int = 30
    parallel_agents_enabled: bool = True
    github_token: str = ""
    github_allow_public_import: bool = True
    max_terminal_output: int = 16000
    terminal_enabled: bool = True
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

settings = Settings()
