from __future__ import annotations
import asyncio, json
from dataclasses import asdict
from typing import Any
from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field
from app.core.security import current_user
from app.db.session import get_db
from app.db.models import Project, ProjectFile
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

router=APIRouter()

@router.get('/platform/v9')
async def v9_status(user=Depends(current_user)):
    from app.services.model_router_v9 import status as model_status
    from app.services.browser_agent_v9 import driver_status
    return {
        'version':'V9','status':'operational','market_readiness':'production_architecture',
        'features':{
            'model_router':'implemented','computer_use':'policy+driver','browser_agent':'implemented',
            'mcp_ecosystem':'stdio+http','deep_research':'multi_agent','codebase_graph':'v3',
            'autonomous_loop':'bounded_verify_repair','swe_benchmark':'real_harness','enterprise_security':'rbac_audit_redaction',
            'ide':'editor_workspace','artifacts':'interactive_html','realtime_collaboration':'room_protocol',
            'memory_learning':'feedback_loop','mobile_dx':'quick_actions','voice_agent':'provider_adapter',
            'background_agent':'job_manager','code_review':'agent','one_click_deploy':'approval_gated',
            'package_dependency':'manifest_analyzer','security_auditor':'static_rules'
        },
        'model_router':model_status(),'browser_driver':driver_status(),
        'benchmark': __import__('app.services.benchmark_v9',fromlist=['run_benchmark_v9']).run_benchmark_v9(),
        'external_execution_note':'Live cloud providers, Playwright browser control, voice providers and third-party deployment require their credentials/dependencies.'
    }

class RouteIn(BaseModel): task:str=Field(min_length=1,max_length=20000); input_tokens:int=Field(default=0,ge=0); budget_usd:float=Field(default=999,ge=0)
@router.post('/v9/models/route')
async def model_route(data:RouteIn,user=Depends(current_user)):
    from app.services.model_router_v9 import route
    return route(data.task,data.input_tokens,data.budget_usd)

class BrowserIn(BaseModel): goal:str=Field(min_length=1,max_length=20000); urls:list[str]=Field(default_factory=list); allowed_domains:list[str]=Field(default_factory=list)
@router.post('/v9/browser/plan')
async def browser_plan(data:BrowserIn,user=Depends(current_user)):
    from app.services.browser_agent_v9 import plan
    return plan(data.goal,data.urls,set(data.allowed_domains) or None)

class MCPRegisterIn(BaseModel): name:str; transport:str; endpoint:str; allowed_tools:list[str]=Field(default_factory=list)
@router.post('/v9/mcp/register')
async def mcp_register(data:MCPRegisterIn,user=Depends(current_user)):
    from app.services.mcp_ecosystem_v9 import MCPEcosystem,MCPServer
    if not hasattr(mcp_register,'ecosystem'): mcp_register.ecosystem=MCPEcosystem()
    mcp_register.ecosystem.register(MCPServer(data.name,data.transport,data.endpoint,True,tuple(data.allowed_tools)))
    return mcp_register.ecosystem.catalog()
@router.get('/v9/mcp/catalog')
async def mcp_catalog(user=Depends(current_user)):
    from app.services.mcp_ecosystem_v9 import MCPEcosystem
    if not hasattr(mcp_register,'ecosystem'): mcp_register.ecosystem=MCPEcosystem()
    return mcp_register.ecosystem.catalog()

class ResearchIn(BaseModel): question:str=Field(min_length=1,max_length=20000); questions:list[str]=Field(default_factory=list)
@router.post('/v9/research/multi-agent')
async def multi_research(data:ResearchIn,user=Depends(current_user)):
    from app.services.deep_research_v3 import multi_agent_research
    try:
        r=await multi_agent_research(data.question,questions=data.questions or None); return {'question':r.question,'agents':[asdict(a) for a in r.agents],'synthesis':r.synthesis,'gaps':r.gaps}
    except Exception as e: raise HTTPException(502,str(e))

@router.get('/projects/{project_id}/graph/v3')
async def graph_v3(project_id:int,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    from app.services.code_graph_v3 import build_graph
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all())
    return build_graph(files)

class LoopDemoIn(BaseModel): max_iterations:int=Field(default=5,ge=1,le=20); failures_before_success:int=Field(default=2,ge=0,le=20)
@router.post('/v9/loop/demo')
async def loop_demo(data:LoopDemoIn,user=Depends(current_user)):
    from app.services.autonomous_loop_v9 import AutonomousLoopV9
    state={'attempt':0}
    def plan(): return {'goal':'verify change'}
    def execute(s): state['attempt']+=1; return {'attempt':state['attempt']}
    def verify(out): return out['attempt']>data.failures_before_success
    def repair(out): return {'retry_after':out['attempt']}
    return AutonomousLoopV9(data.max_iterations).run(plan,execute,verify,repair)

class SWETaskIn(BaseModel): id:str; repo:str; issue:str; base_commit:str=''
@router.post('/v9/swe/validate-task')
async def swe_validate(data:SWETaskIn,user=Depends(current_user)):
    from app.services.swe_bench_v9 import SWEBenchHarness
    return SWEBenchHarness().validate_task(data.model_dump())

@router.get('/v9/security/status')
async def security_status(user=Depends(current_user)):
    from app.services.enterprise_security_v9 import SecurityEngine
    return SecurityEngine().policy_report()

class SecurityIn(BaseModel): text:str=Field(max_length=200000)
@router.post('/v9/security/redact')
async def security_redact(data:SecurityIn,user=Depends(current_user)):
    from app.services.enterprise_security_v9 import SecurityEngine
    s=SecurityEngine(); return {'redacted':s.redact(data.text)}

@router.get('/projects/{project_id}/ide/tree')
async def ide_tree(project_id:int,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all())
    return {'project_id':project_id,'files':[{'path':f.path,'size':len(f.content),'language':f.language} for f in files]}

class ArtifactIn(BaseModel): title:str; kind:str='html'; content:str=Field(min_length=1,max_length=2_000_000)
@router.post('/v9/artifacts')
async def artifact_create(data:ArtifactIn,user=Depends(current_user)):
    from app.services.artifacts_v9 import ArtifactEngine
    if not hasattr(artifact_create,'engine'): artifact_create.engine=ArtifactEngine()
    a=artifact_create.engine.create(data.title,data.kind,data.content)
    return asdict(a)

class ShareOp(BaseModel): user_id:int; operation:dict[str,Any]
rooms={}
@router.post('/v9/collab/{room_id}/join')
async def collab_join(room_id:str,user=Depends(current_user)):
    from app.services.collaboration_v9 import RealtimeRoom
    room=rooms.setdefault(room_id,RealtimeRoom(room_id)); return room.join(user.id,getattr(user,'display_name',str(user.id)))
@router.post('/v9/collab/{room_id}/op')
async def collab_op(room_id:str,data:ShareOp,user=Depends(current_user)):
    room=rooms.get(room_id)
    if not room: raise HTTPException(404,'Room not found')
    return {'event_count':room.op(user.id,data.operation),'snapshot':room.snapshot()}
@router.websocket('/v9/collab/ws/{room_id}')
async def collab_ws(websocket:WebSocket,room_id:str):
    await websocket.accept()
    from app.services.collaboration_v9 import RealtimeRoom
    room=rooms.setdefault(room_id,RealtimeRoom(room_id))
    try:
        while True:
            msg=await websocket.receive_json(); room.events.append({'type':'ws','payload':msg}); await websocket.send_json(room.snapshot())
    except WebSocketDisconnect: return

class MemoryLearnIn(BaseModel): key:str; value:str; feedback:str=''; confidence:float=.5
@router.post('/v9/memory/learn')
async def memory_learn(data:MemoryLearnIn,user=Depends(current_user)):
    from app.services.memory_learning_v9 import MemoryLearningLoop
    if not hasattr(memory_learn,'engine'): memory_learn.engine=MemoryLearningLoop()
    memory_learn.engine.observe(data.key,data.value,data.feedback,data.confidence)
    return memory_learn.engine.learn()

@router.get('/v9/mobile/quick-actions')
async def mobile_quick_actions(user=Depends(current_user)):
    from app.services.dev_agents_v9 import MobileAgent
    return {'actions':MobileAgent().quick_actions()}

@router.get('/v9/voice/status')
async def voice_v9_status(user=Depends(current_user)):
    from app.services.voice_agent_v9 import VoiceAgentV9
    return VoiceAgentV9().status()

class VoiceIn(BaseModel): transcript:str=Field(default='',max_length=10000)
@router.post('/v9/voice/intent')
async def voice_v9_intent(data:VoiceIn,user=Depends(current_user)):
    from app.services.voice_agent_v9 import VoiceAgentV9
    return VoiceAgentV9().intent(data.transcript)

class ReviewIn(BaseModel): project_id:int
@router.post('/v9/agents/review')
async def code_review(data:ReviewIn,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,data.project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    from app.services.dev_agents_v9 import CodeReviewAgent
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==data.project_id))).scalars().all())
    return {'findings':CodeReviewAgent().review(files)}

class SecurityAuditIn(BaseModel): project_id:int
@router.post('/v9/agents/security-audit')
async def security_audit(data:SecurityAuditIn,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,data.project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    from app.services.dev_agents_v9 import SecurityAuditorAgent
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==data.project_id))).scalars().all())
    return {'findings':SecurityAuditorAgent().audit(files)}

class DeployIn(BaseModel): project_id:int; target:str
@router.post('/v9/deploy/plan')
async def deploy_plan(data:DeployIn,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,data.project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    from app.services.dev_agents_v9 import DeployAgent
    return DeployAgent().plan(data.target,data.project_id)

class DependencyIn(BaseModel): files:dict[str,str]
@router.post('/v9/agents/dependencies')
async def dependencies(data:DependencyIn,user=Depends(current_user)):
    from app.services.package_dependency_agent_v9 import PackageDependencyAgentV9
    return PackageDependencyAgentV9().analyze(data.files)

class ComputerExecIn(BaseModel): kind:str; target:str=''; value:str=''; approved:bool=False
@router.post('/v9/computer/execute')
async def computer_execute(data:ComputerExecIn,user=Depends(current_user)):
    from app.services.computer_use_v9 import ComputerUseV9
    action=data.model_dump()
    if data.kind != 'open_url' and not data.approved: return {'ok':False,'status':'approval_required','action':action}
    try: return ComputerUseV9().execute(action)
    except Exception as e: raise HTTPException(400,str(e))

@router.get('/v9/deploy/status')
async def deploy_status(user=Depends(current_user)):
    from app.services.deployment_v9 import DeploymentEngineV9
    return DeploymentEngineV9().status()

class LocalDeployIn(BaseModel): command:list[str]=Field(min_length=1,max_length=20); cwd:str; approved:bool=False
@router.post('/v9/deploy/local-execute')
async def deploy_local(data:LocalDeployIn,user=Depends(current_user)):
    from app.services.deployment_v9 import DeploymentEngineV9
    if not data.cwd or '..' in data.cwd.split('/'): raise HTTPException(400,'Unsafe working directory')
    return DeploymentEngineV9().run_local(data.command,data.cwd,data.approved)

@router.get('/v9/production-readiness')
async def production_readiness(user=Depends(current_user)):
    from app.services.production_readiness_v9 import status
    return status()
