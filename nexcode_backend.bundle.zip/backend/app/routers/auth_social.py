from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.db.session import get_db

router = APIRouter()

class OAuthStartIn(BaseModel):
    provider: str
    redirect_uri: str | None = None

@router.get('/oauth/providers')
async def oauth_providers():
    from app.services.oauth_v10 import enabled_providers
    return {"providers": enabled_providers(), "supported": ["google", "apple", "github", "microsoft", "discord"]}

@router.post('/oauth/start')
async def oauth_start(data: OAuthStartIn):
    from app.services.oauth_v10 import authorize_url
    redirect = data.redirect_uri or f"{settings.oauth_callback_base.rstrip('/')}/api/auth/oauth/callback/{data.provider}"
    # For web callbacks the caller should use the server callback. Mobile apps use the nexcode:// scheme after exchanging the code.
    try:
        return {"provider": data.provider, "authorization_url": authorize_url(data.provider, redirect), "redirect_uri": redirect}
    except ValueError as e:
        raise HTTPException(400, str(e))

@router.get('/oauth/callback/{provider}', response_class=HTMLResponse)
async def oauth_callback(provider: str, request: Request, db: AsyncSession = Depends(get_db), code: str | None = None, state: str | None = None, error: str | None = None):
    if error:
        return HTMLResponse(f"<html><body><h2>NexCode sign-in cancelled</h2><p>{error}</p></body></html>", status_code=400)
    if not code or not state:
        raise HTTPException(400, 'Missing OAuth callback parameters')
    try:
        from app.services.oauth_v10 import complete
        result = await complete(db, provider, state, code)
    except Exception as e:
        raise HTTPException(400, f'OAuth sign-in failed: {e}')
    target = settings.oauth_mobile_redirect_uri
    token = result['access_token']
    if target.startswith('nexcode://'):
        return RedirectResponse(f"{target}?token={token}")
    return HTMLResponse(f"<html><body style='font-family:system-ui;background:#07070b;color:#f7f7fb;text-align:center;padding:40px'><h1>Signed in to NexCode</h1><p>You can close this window.</p><script>window.location.hash='token='+encodeURIComponent({token!r});</script></body></html>")
