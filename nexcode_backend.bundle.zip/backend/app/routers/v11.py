from __future__ import annotations
import asyncio, json
from typing import Any
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import current_user
from app.core.config import settings
from app.db.models import Project, ProjectFile, ProjectMemory, TaskRun
from app.db.session import get_db, SessionLocal
from app.services.agent_core_v11 import NexCodeAgentCoreV11, scrub_secrets, AGENTS
from app.services.jobs_v2 import jobs_v2
from app.services.observability_v11 import dashboard

router = APIRouter()


def _load_files(db: AsyncSession, project_id: int):
    return db.execute(select(ProjectFile).where(ProjectFile.project_id == project_id).order_by(ProjectFile.path))


class PlanIn(BaseModel):
    task: str = Field(min_length=1, max_length=20000)
    project_id: int | None = None
    budget_usd: float = Field(default=999.0, ge=0)


class RunIn(PlanIn):
    mode: str = "auto"
    web_mode: str = "auto"
    approved: bool = False


class FeedbackIn(BaseModel):
    task_id: int
    feedback: str = Field(min_length=1, max_length=4000)
    accepted: bool = True


class ReleaseIn(BaseModel):
    project_id: int
    target: str = Field(min_length=1, max_length=80)
    approved: bool = False


@router.get('/platform/v11')
async def platform_v11(user=Depends(current_user)):
    from app.services.production_readiness_v9 import status as production_status
    return {
        "version": "V11",
        "status": "operational",
        "architecture": "central_agent_core",
        "features": {
            "central_agent_core": "implemented",
            "agent_team": "lead+specialists",
            "real_project_execution": "integrated_with_sandbox",
            "verification_repair": "integrated",
            "minimal_context_engine": "implemented",
            "long_running_tasks": "job_manager+database",
            "live_activity": "task_pipeline+event_trace",
            "observability": "implemented",
            "production_security": "policy+approval+existing_rbac",
            "multi_model_routing": "implemented",
            "learning": "feedback_to_project_memory",
            "tool_ecosystem": "mcp+tool_registry+connectors",
            "build_release": "approval_gated",
            "benchmark": "contract_real_harness",
            "artifacts": "hashable",
            "collaboration": "realtime",
            "voice": "provider_adapter",
            "oauth": "google+apple+github+microsoft+discord",
        },
        "agents": [{"id": a, "name": n, "skills": s} for a, n, s in AGENTS],
        "execution": {
            "mode": settings.execution_mode,
            "docker_available": __import__('shutil').which('docker') is not None,
            "auto_dependency_install": settings.auto_dependency_install,
            "auto_run_builds": settings.auto_run_builds,
        },
        "production_readiness": production_status(),
        "important_note": "Real third-party providers and Docker/Flutter execution depend on the deployment environment and credentials.",
    }


@router.post('/v11/agent/plan')
async def agent_plan(data: PlanIn, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    files: list[ProjectFile] = []
    if data.project_id is not None:
        p = await db.get(Project, data.project_id)
        if not p or p.user_id != user.id:
            raise HTTPException(404, 'Project not found')
        files = list((await _load_files(db, data.project_id))).scalars().all()
    core = NexCodeAgentCoreV11()
    plan = core.plan(data.task, files, data.budget_usd)
    ctx = core.context(data.task, files)
    reports = [core.specialist_report(role, data.task, files, ctx) for role in plan.selected_agents if role != 'lead']
    return {"plan": plan.as_dict(), "context": ctx, "specialists": reports}


async def _run_v11_sync(data: RunIn, user_id: int, db: AsyncSession) -> dict[str, Any]:
    files: list[ProjectFile] = []
    if data.project_id is not None:
        p = await db.get(Project, data.project_id)
        if not p or p.user_id != user_id:
            raise HTTPException(404, 'Project not found')
        files = list((await _load_files(db, data.project_id))).scalars().all()
    core = NexCodeAgentCoreV11()
    task_token = f"v11-{user_id}-{data.project_id or 0}-{__import__('uuid').uuid4().hex[:8]}"
    events = __import__('app.services.agent_core_v11', fromlist=['AgentEventLog']).AgentEventLog(task_token)
    plan = core.plan(data.task, files, data.budget_usd)
    events.done(events.emit('lead', 'planning', 'running', 'Understanding intent and creating delegation plan'))
    ctx = core.context(data.task, files)
    events.done(events.emit('lead', 'context', 'running', 'Selecting minimal project context'))
    specialist_reports = []
    for role in plan.selected_agents:
        started = events.emit(role, 'agent', 'running', f'{role} specialist started')
        specialist_reports.append(core.specialist_report(role, data.task, files, ctx))
        events.done(started, 'done', f'{role} specialist completed')
    if plan.approvals_required and not data.approved:
        events.emit('lead', 'approval', 'blocked', 'Human approval required before risky external/state-changing work')
        return {
            "status": "approval_required",
            "task_token": task_token,
            "plan": plan.as_dict(),
            "context": ctx,
            "specialists": specialist_reports,
            "events": events.snapshot(),
        }

    # Delegate implementation to the already-tested end-to-end engine, which performs
    # research, context enrichment, code generation, safe action application, review,
    # verification, repair and memory persistence.
    from app.services.orchestrator import run_end_to_end
    lead_brief = {
        "intent": plan.intent,
        "agents": plan.selected_agents,
        "risks": plan.risks,
        "context_selection": ctx.get("selection", {}).get("paths", []),
        "specialists": specialist_reports,
    }
    message = [
        {"role": "system", "content": "LEAD AGENT BRIEF (authoritative orchestration context):\n" + json.dumps(lead_brief, ensure_ascii=False)[:30000]},
        {"role": "user", "content": data.task},
    ]
    started = events.emit('coder', 'implementation', 'running', 'Handing off to the implementation engine')
    result = await run_end_to_end(db, user_id, data.project_id, message, data.mode, data.web_mode)
    events.done(started, 'done', 'Implementation engine completed')
    if result.execution:
        events.done(events.emit('tester', 'verification', 'running', 'Verification completed'), 'done', result.execution.summary)
    quality = result.quality or {}
    exec_payload = None
    if result.execution:
        exec_payload = {
            "ok": result.execution.ok,
            "summary": result.execution.summary,
            "mode": result.execution.mode,
            "checks": [c.__dict__ for c in result.execution.checks],
        }
    return {
        "status": "completed" if result.status == 'completed' else result.status,
        "task_token": task_token,
        "task_id": result.task_id,
        "answer": scrub_secrets(result.answer),
        "plan": plan.as_dict(),
        "context": ctx,
        "specialists": specialist_reports,
        "actions": result.actions,
        "applied": result.applied,
        "repair_cycles": result.repair_cycles,
        "pipeline": result.pipeline,
        "quality": quality,
        "execution": exec_payload,
        "events": events.snapshot(),
        "checkpoints": [
            {"name": "planned", "status": "done"},
            {"name": "implemented", "status": "done", "changed": result.applied},
            {"name": "verified", "status": "done" if not result.execution or result.execution.ok else "failed"},
            {"name": "delivered", "status": "done"},
        ],
    }


@router.post('/v11/projects/{project_id}/agent/run')
async def agent_run(project_id: int, data: RunIn, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    if data.project_id not in (None, project_id):
        raise HTTPException(400, 'project_id conflicts with path')
    data.project_id = project_id
    return await _run_v11_sync(data, user.id, db)


@router.post('/v11/agent/run')
async def agent_run_general(data: RunIn, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    return await _run_v11_sync(data, user.id, db)


@router.post('/v11/projects/{project_id}/agent/run-async')
async def agent_run_async(project_id: int, data: RunIn, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    p = await db.get(Project, project_id)
    if not p or p.user_id != user.id:
        raise HTTPException(404, 'Project not found')
    data.project_id = project_id
    # Persist a durable task shell first; the JobManager executes the workflow and
    # stores its final JSON in the same TaskRun row.
    row = TaskRun(user_id=user.id, project_id=project_id, request=data.task, status='queued', pipeline_json='[]', result_json='{}')
    db.add(row)
    await db.commit(); await db.refresh(row)
    task_id = row.id

    async def worker():
        async with SessionLocal() as bg:
            dbrow = await bg.get(TaskRun, task_id)
            if not dbrow:
                return
            dbrow.status = 'running'; await bg.commit()
            try:
                result = await _run_v11_sync(data, user.id, bg)
                dbrow.status = 'done' if result.get('status') == 'completed' else result.get('status', 'failed')
                dbrow.result_json = json.dumps(result, ensure_ascii=False, default=str)
                dbrow.pipeline_json = json.dumps(result.get('pipeline', result.get('events', [])), ensure_ascii=False, default=str)
            except Exception as exc:
                dbrow.status = 'failed'; dbrow.result_json = json.dumps({'error': str(exc)})
            await bg.commit()

    job = jobs_v2.submit(f'nexcode-v11-task-{task_id}', worker)
    return {"task_id": task_id, "job_id": job.id, "status": job.status}



@router.get('/v11/projects/{project_id}/preflight')
async def preflight(project_id: int, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    p = await db.get(Project, project_id)
    if not p or p.user_id != user.id:
        raise HTTPException(404, 'Project not found')
    files = list((await _load_files(db, project_id))).scalars().all()
    from app.services.preflight_v11 import project_preflight
    return {"project_id": project_id, **project_preflight(files)}


@router.post('/v11/tasks/{task_id}/cancel')
async def cancel_task(task_id: int, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    row = await db.get(TaskRun, task_id)
    if not row or row.user_id != user.id:
        raise HTTPException(404, 'Task not found')
    if row.status in {'done', 'failed', 'cancelled', 'approval_required'}:
        return {"task_id": task_id, "status": row.status, "cancelled": row.status == 'cancelled'}
    job = next((j for j in jobs_v2.jobs.values() if j.name == f'nexcode-v11-task-{task_id}'), None)
    if job is None:
        row.status = 'cancelled'; await db.commit()
        return {"task_id": task_id, "status": "cancelled", "cancelled": True, "job_found": False}
    result = jobs_v2.cancel(job.id)
    row.status = 'cancelled'
    row.result_json = json.dumps({"status": "cancelled", "job": result})
    await db.commit()
    return {"task_id": task_id, "status": "cancelled", "cancelled": True, "job": result}

@router.get('/v11/tasks/{task_id}')
async def task_status(task_id: int, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    row = await db.get(TaskRun, task_id)
    if not row or row.user_id != user.id:
        raise HTTPException(404, 'Task not found')
    try: result = json.loads(row.result_json or '{}')
    except Exception: result = {}
    try: pipeline = json.loads(row.pipeline_json or '[]')
    except Exception: pipeline = []
    return {"task_id": row.id, "status": row.status, "request": row.request, "pipeline": pipeline, "result": result, "created_at": row.created_at, "updated_at": row.updated_at}


@router.get('/v11/observability')
async def observability(limit: int = 25, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    rows = list((await db.execute(select(TaskRun).where(TaskRun.user_id == user.id).order_by(TaskRun.id.desc()).limit(min(limit, 100)))).scalars().all())
    task_rows = []
    for r in rows:
        try: payload = json.loads(r.result_json or '{}')
        except Exception: payload = {}
        task_rows.append({"id": r.id, "status": r.status, "events": payload.get('events', []), "pipeline": payload.get('pipeline', [])})
    return dashboard(task_rows)


@router.post('/v11/feedback')
async def feedback(data: FeedbackIn, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    row = await db.get(TaskRun, data.task_id)
    if not row or row.user_id != user.id:
        raise HTTPException(404, 'Task not found')
    if row.project_id is None:
        return {"stored": False, "reason": "feedback has no project scope"}
    mem = (await db.execute(select(ProjectMemory).where(ProjectMemory.project_id == row.project_id))).scalar_one_or_none()
    payload = {}
    if mem:
        try: payload = json.loads(mem.memory_json or '{}')
        except Exception: payload = {}
    learned = payload.setdefault('v11_feedback', [])
    learned.append({"task_id": data.task_id, "accepted": data.accepted, "feedback": scrub_secrets(data.feedback)[:1000]})
    payload['v11_feedback'] = learned[-50:]
    payload['updated_at'] = __import__('datetime').datetime.utcnow().isoformat()
    if mem: mem.memory_json = json.dumps(payload, ensure_ascii=False); await db.commit()
    else:
        db.add(ProjectMemory(project_id=row.project_id, memory_json=json.dumps(payload, ensure_ascii=False))); await db.commit()
    return {"stored": True, "count": len(learned[-50:])}


@router.get('/v11/benchmark')
async def v11_benchmark(user=Depends(current_user)):
    from app.services.benchmark_v11 import run_contracts
    sample = NexCodeAgentCoreV11().plan('build a Flutter app and fix tests', [])
    return run_contracts({"plan": sample.as_dict(), "context": {"selection": {}}, "events": [{"status":"done"}], "checkpoints": [{"name":"planned"}], "quality": {}, "status": "completed"})


@router.post('/v11/security/policy')
async def security_policy(tool: str, approved: bool = False, network: bool = False, user=Depends(current_user)):
    from app.services.sandbox_policy_v11 import tool_policy
    return tool_policy(tool, approved=approved, network=network)


@router.get('/v11/release/{project_id}')
async def release_checklist(project_id: int, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    p = await db.get(Project, project_id)
    if not p or p.user_id != user.id: raise HTTPException(404, 'Project not found')
    files = list((await _load_files(db, project_id))).scalars().all()
    from app.services.production_readiness_v9 import status as prod
    from app.services.quality import generate_quality_report
    q = generate_quality_report(files, run_build=False, install=False)
    return {
        "project_id": project_id,
        "target_options": ["android_apk", "android_aab", "web", "backend"],
        "gates": {
            "quality": q.score >= 70,
            "security": q.security >= 70,
            "tests": q.tests >= 70,
            "dependencies": q.dependencies in {"PASS", "DECLARED", "N/A"},
            "production_readiness": prod(),
            "approval_required": True,
        },
        "artifact_policy": "Every produced release artifact should carry SHA-256 and build metadata.",
    }
