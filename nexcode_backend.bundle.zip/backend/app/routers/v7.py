from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.core.config import settings
from app.core.security import current_user
from app.db.models import Project, ProjectFile
from app.db.session import get_db
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

router = APIRouter()

@router.get('/platform/v7')
async def v7_status(user=Depends(current_user)):
    from app.services.sandbox_v7 import health, validate_policy
    sandbox = health(); policy = validate_policy()
    return {
        'version':'V7',
        'pillars': [
            {'key':'real_world_agent','status':'implemented','detail':'Autonomous plan/search/implement/verify/repair/deliver pipeline.'},
            {'key':'sandbox','status':'implemented','detail':f"{sandbox['configured_mode']} with hardened limits."},
            {'key':'benchmark','status':'implemented','detail':'120 deterministic evaluation tasks.'},
            {'key':'self_healing','status':'implemented','detail':'Bounded repair + strategy change on repeated failures.'},
            {'key':'project_intelligence_2','status':'implemented','detail':'Architecture, symbols, imports, reverse dependencies and hotspots.'},
            {'key':'github_full','status':'implemented','detail':'Import, branch preparation, push and pull-request APIs; credentials server-side.'},
            {'key':'ux','status':'implemented','detail':'Single chat plus developer workspace and V7 health dashboard.'},
        ],
        'sandbox':sandbox,
        'sandbox_policy':policy,
        'limits': {'max_repair_cycles':settings.max_repair_cycles,'max_project_files':settings.max_project_files,'max_pipeline_steps':settings.max_pipeline_steps},
    }

@router.get('/v7/benchmark')
async def run_v7_benchmark(user=Depends(current_user)):
    from app.services.benchmark_v7 import run_benchmark
    return run_benchmark()

@router.get('/projects/{project_id}/intelligence/v2')
async def project_intelligence_v2(project_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id).order_by(ProjectFile.path))).scalars().all())
    from app.services.intelligence_v2 import analyze_project_v2
    return analyze_project_v2(files)

class PushIn(BaseModel):
    owner_repo:str
    branch:str

@router.post('/projects/{project_id}/github/push')
async def github_push(project_id:int, data:PushIn, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    if not settings.github_token: raise HTTPException(503,'GitHub push is not configured on the server.')
    from app.services.github_intel import push_branch
    try: return push_branch(project_id,data.owner_repo,data.branch)
    except Exception as exc: raise HTTPException(400,str(exc))


class PublishIn(BaseModel):
    owner_repo:str
    branch:str
    title:str
    base:str='main'
    body:str=''

@router.post('/projects/{project_id}/github/publish')
async def github_publish(project_id:int, data:PublishIn, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    if not settings.github_token: raise HTTPException(503,'GitHub publish is not configured on the server.')
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id).order_by(ProjectFile.path))).scalars().all())
    from app.services.git_intel import sync_project
    from app.services.github_intel import push_branch, create_pull_request
    try:
        prepared=sync_project(project_id,files,'NexCode V7 publish',branch=data.branch)
        pushed=push_branch(project_id,data.owner_repo,data.branch)
        if not pushed.get('ok'):
            return {'ok':False,'stage':'push','prepared':prepared,'push':pushed}
        pr=create_pull_request(data.owner_repo,data.title,data.branch,data.base,data.body)
        return {'ok':True,'prepared':prepared,'push':pushed,'pull_request':pr}
    except Exception as exc: raise HTTPException(400,str(exc))
