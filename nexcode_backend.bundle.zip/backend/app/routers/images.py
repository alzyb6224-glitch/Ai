import base64
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import Response
from pydantic import BaseModel
from app.routers.auth import current_user
from app.services.ai import generate_image

router = APIRouter()
class ImageIn(BaseModel):
    prompt: str
    size: str = "1024x1024"
    quality: str = "high"

@router.post("/images/generate")
async def image(data: ImageIn, user=Depends(current_user)):
    if not data.prompt.strip(): raise HTTPException(400, "Prompt is empty")
    b64 = await generate_image(data.prompt.strip(), data.size, data.quality)
    return {"image_base64": b64, "mime_type": "image/png"}


@router.post("/images/analyze")
async def analyze_image(image: UploadFile = File(...), prompt: str = Form(""), user=Depends(current_user)):
    from app.services.visual import analyze_screenshot
    data=await image.read()
    mime=image.content_type or "image/png"
    if not mime.startswith("image/"): raise HTTPException(400,"Only image files are supported")
    try:
        answer=await analyze_screenshot(data,mime,prompt.strip() or "Diagnose this screenshot for a developer. Explain visible errors, likely causes, and the exact next debugging steps.")
        return {"answer":answer}
    except Exception as exc:
        raise HTTPException(502,str(exc))
