from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.db.models import User
from app.core.security import hash_password, verify_password, create_token, oauth2_scheme, get_user_id

router = APIRouter()
class RegisterIn(BaseModel):
    email: EmailStr
    password: str
    display_name: str = "Developer"

@router.post("/register")
async def register(data: RegisterIn, db: AsyncSession = Depends(get_db)):
    existing = (await db.execute(select(User).where(User.email == data.email.lower()))).scalar_one_or_none()
    if existing:
        raise HTTPException(409, "Email already registered")
    if len(data.password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")
    user = User(email=data.email.lower(), password_hash=hash_password(data.password), display_name=data.display_name[:120])
    db.add(user); await db.commit(); await db.refresh(user)
    return {"access_token": create_token(user.id), "token_type": "bearer", "user": {"id": user.id, "email": user.email, "display_name": user.display_name}}

@router.post("/login")
async def login(form: OAuth2PasswordRequestForm = Depends(), db: AsyncSession = Depends(get_db)):
    user = (await db.execute(select(User).where(User.email == form.username.lower()))).scalar_one_or_none()
    if not user or not verify_password(form.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return {"access_token": create_token(user.id), "token_type": "bearer", "user": {"id": user.id, "email": user.email, "display_name": user.display_name}}

async def current_user(token: str = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)) -> User:
    user_id = get_user_id(token)
    user = await db.get(User, user_id)
    if not user: raise HTTPException(401, "User not found")
    return user
