from __future__ import annotations
import asyncio, json, uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.security import current_user
from app.db.session import get_db
from app.db.models import Project, ProjectFile, ProjectMemory

router=APIRouter()

@router.get('/platform/v8')
async def v8_status(user=Depends(current_user)):
    from app.services.computer_agent import driver_status
    from app.services.sandbox_v7 import health, validate_policy
    from app.services.voice_v2 import provider_status
    sb=health()
    return {
      'version':'V8',
      'status':'operational',
      'pillars':[
        {'key':'computer_agent','status':'implemented','detail':'Policy-gated computer action planner with optional Playwright driver.'},
        {'key':'mcp_connectors','status':'implemented','detail':'MCP stdio client with tool allowlisting.'},
        {'key':'memory_2','status':'implemented','detail':'Scoped, confidence-aware, source-aware persistent memory model.'},
        {'key':'workspace_2','status':'implemented','detail':'Versioned artifacts, hashes and unified diffs.'},
        {'key':'research_2','status':'implemented','detail':'Multi-question research orchestration over NexCode web research.'},
        {'key':'data_analysis','status':'implemented','detail':'CSV/JSON profiling and chart-spec generation without arbitrary code execution.'},
        {'key':'voice_developer','status':'implemented','detail':'Provider-neutral STT/TTS interfaces with intent extraction.'},
        {'key':'background_agents','status':'implemented','detail':'In-process async job manager with task state and result/error tracking.'},
        {'key':'collaboration','status':'implemented','detail':'Expiring viewer/editor project share links.'},
        {'key':'multimodal_observability','status':'implemented','detail':'Asset intelligence plus traceable execution telemetry.'},
      ],
      'computer_driver':driver_status(), 'voice':provider_status(), 'sandbox':sb, 'sandbox_policy':validate_policy(),
      'benchmark':{'file':'evaluation/tasks_v8.json','target_tasks':200},
    }

class ComputerIn(BaseModel):
    goal:str=Field(min_length=1,max_length=5000)
    actions:list[dict]=Field(default_factory=list)
@router.post('/v8/computer/plan')
async def computer_plan(data:ComputerIn,user=Depends(current_user)):
    from app.services.computer_agent import dry_run
    return dry_run(data.goal, data.actions or None)

class MCPIn(BaseModel):
    command:list[str]=Field(min_length=1,max_length=8)
    allowed_tools:list[str]=Field(default_factory=list)
@router.post('/v8/mcp/inspect')
async def mcp_inspect(data:MCPIn,user=Depends(current_user)):
    # Explicit command allowlist prevents arbitrary process execution through the public API.
    allowed_prefixes=('python','python3','node','bun','deno')
    if data.command[0].split('/')[-1] not in allowed_prefixes: raise HTTPException(400,'MCP server command is not allowed.')
    from app.services.mcp_client import MCPStdioClient
    c=MCPStdioClient(data.command,set(data.allowed_tools));
    try:
        init=c.initialize(); tools=[x.__dict__ for x in c.list_tools()]
        return {'ok':True,'initialize':init,'tools':tools}
    except Exception as e: raise HTTPException(400,str(e))
    finally: c.stop()

class MemoryIn(BaseModel):
    key:str; value:str; scope:str='project'; confidence:float=0.7; source:str='agent'
@router.get('/projects/{project_id}/memory/v2')
async def get_memory_v2(project_id:int,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    m=(await db.execute(select(ProjectMemory).where(ProjectMemory.project_id==project_id))).scalar_one_or_none()
    from app.services.memory_v2 import MemoryV2
    return MemoryV2(json.loads(m.memory_json).get('v2',{}).get('items',[]) if m else []).to_dict()
@router.post('/projects/{project_id}/memory/v2')
async def save_memory_v2(project_id:int,data:MemoryIn,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    m=(await db.execute(select(ProjectMemory).where(ProjectMemory.project_id==project_id))).scalar_one_or_none()
    from app.services.memory_v2 import MemoryV2
    obj=MemoryV2(json.loads(m.memory_json).get('v2',{}).get('items',[]) if m else [])
    obj.upsert(data.key,data.value,data.scope,data.confidence,data.source)
    payload=json.loads(m.memory_json) if m else {}; payload['v2']=obj.to_dict()
    if m: m.memory_json=json.dumps(payload,ensure_ascii=False)
    else: db.add(ProjectMemory(project_id=project_id,memory_json=json.dumps(payload,ensure_ascii=False)))
    await db.commit(); return obj.to_dict()

class SearchIn(BaseModel): query:str=Field(min_length=1); limit:int=Field(default=8,ge=1,le=50)
@router.post('/projects/{project_id}/memory/v2/search')
async def search_memory_v2(project_id:int,data:SearchIn,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    m=(await db.execute(select(ProjectMemory).where(ProjectMemory.project_id==project_id))).scalar_one_or_none()
    from app.services.memory_v2 import MemoryV2
    obj=MemoryV2(json.loads(m.memory_json).get('v2',{}).get('items',[]) if m else [])
    return {'results':obj.search(data.query,data.limit)}

class ArtifactIn(BaseModel): path:str; content:str; kind:str='code'
@router.post('/projects/{project_id}/workspace/artifacts')
async def artifact_preview(project_id:int,data:ArtifactIn,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    from app.services.workspace_v2 import WorkspaceV2
    ws=WorkspaceV2(); files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all())
    for f in files: ws.upsert(f.path,f.content,'code')
    diff=ws.diff(data.path,data.content); artifact=ws.upsert(data.path,data.content,data.kind)
    return {'artifact':artifact,'diff':diff}

class ResearchIn(BaseModel): query:str=Field(min_length=1,max_length=10000); mode:str='deep'
@router.post('/v8/research')
async def research_v8(data:ResearchIn,user=Depends(current_user)):
    from app.services.research_v2 import deep_research_v2
    try: r=await deep_research_v2(data.query,data.mode); return r.__dict__
    except Exception as e: raise HTTPException(502,str(e))

class DataIn(BaseModel): data:str=Field(min_length=1,max_length=2_000_000); format:str='csv'; x:str=''; y:str=''
@router.post('/v8/data/analyze')
async def data_v8(data:DataIn,user=Depends(current_user)):
    from app.services.data_analysis_v2 import analyze_text,chart_spec
    try:
        result=analyze_text(data.data,data.format)
        if data.x and data.y: result['chart']=chart_spec(result,data.x,data.y)
        return result
    except Exception as e: raise HTTPException(400,str(e))

@router.get('/v8/voice/status')
async def voice_status(user=Depends(current_user)):
    from app.services.voice_v2 import provider_status
    return provider_status()
class VoiceIn(BaseModel): transcript:str=Field(default='',max_length=10000)
@router.post('/v8/voice/intent')
async def voice_intent(data:VoiceIn,user=Depends(current_user)):
    from app.services.voice_v2 import command_intent
    return command_intent(data.transcript)

class JobIn(BaseModel): name:str=Field(min_length=1,max_length=200)
@router.post('/v8/jobs/demo')
async def demo_job(data:JobIn,user=Depends(current_user)):
    from app.services.jobs_v2 import jobs_v2
    async def work():
        await asyncio.sleep(0); return {'message':'background job completed','name':data.name}
    return jobs_v2.get(jobs_v2.submit(data.name,work).id)
@router.get('/v8/jobs/{job_id}')
async def get_job(job_id:str,user=Depends(current_user)):
    from app.services.jobs_v2 import jobs_v2
    try: return jobs_v2.get(job_id)
    except KeyError: raise HTTPException(404,'Job not found')

class ShareIn(BaseModel): role:str='viewer'; ttl_seconds:int=86400
@router.post('/projects/{project_id}/share')
async def create_share(project_id:int,data:ShareIn,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
    from app.services.collaboration_v2 import collaboration_v2
    return collaboration_v2.create_link(project_id,data.role,data.ttl_seconds)
@router.get('/v8/share/{token}')
async def resolve_share(token:str,user=Depends(current_user)):
    from app.services.collaboration_v2 import collaboration_v2
    try:return collaboration_v2.resolve(token)
    except KeyError: raise HTTPException(404,'Share link expired or missing')

@router.post('/v8/multimodal/inspect')
async def multimodal_inspect(project_id:int|None=None,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    files=[]
    if project_id:
        p=await db.get(Project,project_id)
        if not p or p.user_id!=user.id: raise HTTPException(404,'Project not found')
        files=[{'path':f.path,'size':len(f.content)} for f in (await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all()]
    from app.services.multimodal_v2 import inspect_assets
    return inspect_assets(files)

@router.get('/v8/trace/{trace_id}')
async def trace_example(trace_id:str,user=Depends(current_user)):
    from app.services.observability_v2 import Trace
    t=Trace(trace_id); t.add('request','done'); t.add('policy','done'); t.add('execution','done'); return t.finish()

@router.get('/v8/benchmark')
async def benchmark_v8(user=Depends(current_user)):
    from app.services.benchmark_v8 import run_benchmark_v8
    return run_benchmark_v8()


class ReleaseIn(BaseModel):
    tests_ok: bool
    quality_score: float|None = None
    security_ok: bool = True
    unresolved_repairs: int = 0
    git_ready: bool = True
    external_credentials_ok: bool = True
@router.post('/v8/release/gate')
async def release_gate(data:ReleaseIn,user=Depends(current_user)):
    from app.services.release_gate import evaluate
    return evaluate(**data.model_dump())

class BudgetIn(BaseModel):
    input_tokens:int=Field(ge=0,le=100_000_000)
    output_tokens:int=Field(ge=0,le=100_000_000)
    budget_usd:float=Field(ge=0)
    spent_usd:float=Field(default=0,ge=0)
    price_per_million_tokens:float=Field(default=10,ge=0)
@router.post('/v8/policy/budget')
async def budget_guard(data:BudgetIn,user=Depends(current_user)):
    from app.services.cost_guard import decide
    return decide(data.input_tokens,data.output_tokens,data.budget_usd,data.price_per_million_tokens,data.spent_usd).__dict__
