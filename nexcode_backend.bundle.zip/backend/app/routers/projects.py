from datetime import datetime
from pathlib import PurePosixPath
import io
import zipfile
import json
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.db.models import Project, ProjectFile, ProjectRevision, ProjectMemory
from app.routers.auth import current_user
from app.services.project import summarize, search_files
from app.services.executor import validate_project, available_profiles
from app.services.git_intel import diff as git_diff, history as git_history, sync_project
from app.core.config import settings

router = APIRouter()
class ProjectIn(BaseModel):
    name: str
    description: str = ""

EXT_LANG = {"py":"python","js":"javascript","ts":"typescript","tsx":"typescript","jsx":"javascript","dart":"dart","kt":"kotlin","java":"java","go":"go","rs":"rust","php":"php","html":"html","css":"css","sql":"sql","json":"json","md":"markdown"}

def language(path: str):
    return EXT_LANG.get(path.rsplit('.',1)[-1].lower(), "text") if '.' in path else "text"

@router.post("/projects")
async def create_project(data: ProjectIn, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    p = Project(user_id=user.id, name=data.name[:200], description=data.description)
    db.add(p); await db.commit(); await db.refresh(p)
    return {"id": p.id, "name": p.name, "description": p.description}

@router.get("/projects")
async def list_projects(db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    rows = (await db.execute(select(Project).where(Project.user_id == user.id).order_by(Project.created_at.desc()))).scalars().all()
    return [{"id": p.id, "name": p.name, "description": p.description} for p in rows]

@router.get("/projects/{project_id}/files")
async def list_files(project_id: int, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    p = await db.get(Project, project_id)
    if not p or p.user_id != user.id: raise HTTPException(404, "Project not found")
    rows = (await db.execute(select(ProjectFile).where(ProjectFile.project_id == p.id).order_by(ProjectFile.path))).scalars().all()
    return [{"id": f.id, "path": f.path, "language": f.language, "content": f.content} for f in rows]

@router.post("/projects/{project_id}/files/upload")
async def upload_files(project_id: int, files: list[UploadFile] = File(...), db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    p = await db.get(Project, project_id)
    if not p or p.user_id != user.id: raise HTTPException(404, "Project not found")
    count = 0
    async def save(path: str, content: str):
        nonlocal count
        path = str(PurePosixPath(path)).lstrip("/")
        if not path or path.startswith("../") or "/../" in path: return
        existing = (await db.execute(select(ProjectFile).where(ProjectFile.project_id==p.id, ProjectFile.path==path))).scalar_one_or_none()
        if existing:
            existing.content=content; existing.language=language(path); existing.updated_at=datetime.utcnow()
        else:
            db.add(ProjectFile(project_id=p.id, path=path, content=content, language=language(path)))
        count += 1

    for upload in files:
        data = await upload.read()
        if len(data) > 30_000_000: continue
        filename = upload.filename or "file.txt"
        if filename.lower().endswith(".zip"):
            try:
                with zipfile.ZipFile(io.BytesIO(data)) as z:
                    members=[i for i in z.infolist() if not i.is_dir()][:500]
                    if sum(i.file_size for i in members) > 40_000_000: continue
                    for item in members:
                        path=str(PurePosixPath(item.filename)).lstrip("/")
                        if path.startswith("../") or "/../" in path or len(path)>1000: continue
                        raw=z.read(item)
                        if len(raw)>2_000_000: continue
                        try: content=raw.decode("utf-8")
                        except UnicodeDecodeError: continue
                        await save(path, content)
            except zipfile.BadZipFile:
                continue
        else:
            if len(data)>2_000_000: continue
            try: content=data.decode("utf-8")
            except UnicodeDecodeError: continue
            await save(filename, content)
    await db.commit()
    return {"uploaded": count}

@router.put("/projects/{project_id}/files/{file_id}")
async def update_file(project_id: int, file_id: int, content: str = Form(...), db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project, project_id)
    f=await db.get(ProjectFile, file_id)
    if not p or p.user_id != user.id or not f or f.project_id != p.id: raise HTTPException(404, "File not found")
    if len(content)>2_000_000: raise HTTPException(413, "File too large")
    f.content=content; f.updated_at=datetime.utcnow(); await db.commit()
    return {"ok": True}


class ApplyAction(BaseModel):
    op: str
    path: str
    content: str | None = None

class ApplyIn(BaseModel):
    actions: list[ApplyAction]

@router.get("/projects/{project_id}/analyze")
async def analyze_project(project_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id).order_by(ProjectFile.path))).scalars().all())
    return summarize(files)

@router.post("/projects/{project_id}/apply")
async def apply_project(project_id:int, data:ApplyIn, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    if len(data.actions)>50: raise HTTPException(400,"Too many actions")
    changed=0
    for action in data.actions:
        path=str(PurePosixPath(action.path)).lstrip("/")
        if not path or path.startswith("../") or "/../" in path or len(path)>1000: continue
        f=(await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id,ProjectFile.path==path))).scalar_one_or_none()
        if action.op=="delete":
            if f: await db.delete(f); changed+=1
        elif action.op=="write":
            if action.content is None or len(action.content)>2_000_000: continue
            if f:
                f.content=action.content; f.language=language(path); f.updated_at=datetime.utcnow()
            else:
                db.add(ProjectFile(project_id=project_id,path=path,content=action.content,language=language(path)))
            changed+=1
        else:
            raise HTTPException(400,f"Unknown operation: {action.op}")
    await db.commit()
    return {"changed":changed}


@router.get("/projects/{project_id}/search")
async def search_project(project_id:int, q:str, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    if not q.strip(): raise HTTPException(400,"Query is empty")
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id).order_by(ProjectFile.path))).scalars().all())
    return search_files(files, q, limit=20)


@router.get("/projects/{project_id}/revisions")
async def revisions(project_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    rows=(await db.execute(select(ProjectRevision).where(ProjectRevision.project_id==project_id).order_by(ProjectRevision.id.desc()).limit(50))).scalars().all()
    return [{"id":r.id,"summary":r.summary,"created_at":r.created_at.isoformat()} for r in rows]

@router.get("/projects/{project_id}/revisions/{revision_id}/diff")
async def revision_diff(project_id:int, revision_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id); r=await db.get(ProjectRevision,revision_id)
    if not p or p.user_id!=user.id or not r or r.project_id!=p.id: raise HTTPException(404,"Revision not found")
    before=json.loads(r.snapshot)
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all())
    after={f.path:f.content for f in files}
    paths=sorted(set(before)|set(after))
    import difflib
    lines=[]
    for path in paths:
        if before.get(path)==after.get(path): continue
        lines.append(f"--- a/{path}\n+++ b/{path}")
        lines.extend(difflib.unified_diff((before.get(path,'')).splitlines(),(after.get(path,'')).splitlines(),lineterm=""))
    return {"revision_id":revision_id,"diff":"\n".join(lines)}

@router.post("/projects/{project_id}/revisions/{revision_id}/rollback")
async def rollback(project_id:int, revision_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id); r=await db.get(ProjectRevision,revision_id)
    if not p or p.user_id!=user.id or not r or r.project_id!=p.id: raise HTTPException(404,"Revision not found")
    snapshot=json.loads(r.snapshot)
    current=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all())
    # snapshot is the exact pre-change project state for that revision.
    for f in current: await db.delete(f)
    for path,content in snapshot.items(): db.add(ProjectFile(project_id=project_id,path=path,content=content,language=language(path)))
    await db.commit()
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all())
    git=sync_project(project_id, files, f"NexCode rollback revision {revision_id}")
    return {"ok":True,"restored_files":len(snapshot),"git":git}

@router.get("/projects/{project_id}/git")
async def git_info(project_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    return {"history":git_history(project_id),"diff":git_diff(project_id)}

@router.get("/projects/{project_id}/execution/profiles")
async def execution_profiles(project_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all())
    return available_profiles(files)

class ExecuteIn(BaseModel):
    build: bool = False
    install: bool = False

@router.post("/projects/{project_id}/execute")
async def execute_project(project_id:int, data:ExecuteIn, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    if data.install and not settings.auto_dependency_install: raise HTTPException(403,"Dependency installation is disabled by server policy")
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id))).scalars().all())
    result=validate_project(files, include_build=data.build, include_install=data.install)
    return {"ok":result.ok,"mode":result.mode,"summary":result.summary,"checks":[{"name":c.name,"ok":c.ok,"output":c.output,"duration_ms":c.duration_ms,"mode":c.mode} for c in result.checks]}

@router.get("/projects/{project_id}/memory")
async def project_memory(project_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    row=(await db.execute(select(ProjectMemory).where(ProjectMemory.project_id==project_id))).scalar_one_or_none()
    return json.loads(row.memory_json) if row else {}

# --- V6: Autonomous developer controls ---
class TerminalIn(BaseModel):
    command: list[str]

@router.post("/projects/{project_id}/terminal")
async def terminal_project(project_id:int, data:TerminalIn, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    if not settings.terminal_enabled: raise HTTPException(403,"Terminal is disabled by server policy")
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id).order_by(ProjectFile.path))).scalars().all())
    from app.services.terminal import run_command
    try: result=run_command(files,data.command)
    except ValueError as exc: raise HTTPException(400,str(exc))
    return {"ok":result.ok,"name":result.name,"output":result.output[:settings.max_terminal_output],"duration_ms":result.duration_ms,"mode":result.mode}

@router.get("/projects/{project_id}/intelligence")
async def project_intelligence(project_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id).order_by(ProjectFile.path))).scalars().all())
    from app.services.code_intelligence import analyze_project
    return analyze_project(files)

@router.get("/projects/{project_id}/quality")
async def project_quality(project_id:int, build:bool=False, install:bool=False, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id).order_by(ProjectFile.path))).scalars().all())
    from app.services.quality import generate_quality_report
    r=generate_quality_report(files,run_build=build,install=install)
    return {"score":r.score,"code_quality":r.code_quality,"tests":r.tests,"build":r.build,"security":r.security,"dependencies":r.dependencies,"regression":r.regression,"findings":r.findings,"execution":{"ok":r.execution.ok,"summary":r.execution.summary,"checks":[c.__dict__ for c in r.execution.checks]}}

class MemoryIn(BaseModel):
    data: dict

@router.put("/projects/{project_id}/memory")
async def update_project_memory(project_id:int, data:MemoryIn, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    row=(await db.execute(select(ProjectMemory).where(ProjectMemory.project_id==project_id))).scalar_one_or_none()
    payload=json.dumps(data.data,ensure_ascii=False)
    if row: row.memory_json=payload; row.updated_at=datetime.utcnow()
    else: db.add(ProjectMemory(project_id=project_id,memory_json=payload))
    await db.commit()
    return {"ok":True}

@router.delete("/projects/{project_id}/memory")
async def delete_project_memory(project_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    from sqlalchemy import delete
    await db.execute(delete(ProjectMemory).where(ProjectMemory.project_id==project_id)); await db.commit()
    return {"ok":True}

class GitHubPRIn(BaseModel):
    owner_repo: str
    title: str
    head: str
    base: str = "main"
    body: str = ""

@router.post("/projects/{project_id}/github/prepare")
async def github_prepare(project_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    files=list((await db.execute(select(ProjectFile).where(ProjectFile.project_id==project_id).order_by(ProjectFile.path))).scalars().all())
    from app.services.git_intel import sync_project
    return sync_project(project_id,files,"NexCode GitHub preparation",branch=f"nexcode/github-{project_id}")

@router.post("/projects/{project_id}/github/pull-request")
async def github_pull_request(project_id:int,data:GitHubPRIn,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    from app.services.github_intel import create_pull_request
    try: return create_pull_request(data.owner_repo,data.title,data.head,data.base,data.body)
    except Exception as exc: raise HTTPException(400,str(exc))

@router.get("/projects/{project_id}/tools")
async def project_tools(project_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    p=await db.get(Project,project_id)
    if not p or p.user_id!=user.id: raise HTTPException(404,"Project not found")
    from app.services.tool_registry import registry
    return {"tools":registry.list()}

class ImportRepoIn(BaseModel):
    name: str
    repo_url: str
    description: str = ""

@router.post("/github/import")
async def github_import(data:ImportRepoIn, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    if not settings.github_allow_public_import: raise HTTPException(403,"Public GitHub import disabled")
    from app.services.github_intel import import_public_repo
    try: imported=import_public_repo(data.repo_url,max_files=settings.max_project_files)
    except Exception as exc: raise HTTPException(400,str(exc))
    p=Project(user_id=user.id,name=data.name[:200],description=data.description[:10000]); db.add(p); await db.flush()
    for item in imported:
        path=item['path']
        if path.startswith('.env') or path.startswith('.git/'): continue
        db.add(ProjectFile(project_id=p.id,path=path,content=item['content'],language=language(path)))
    await db.commit(); await db.refresh(p)
    return {"id":p.id,"name":p.name,"files_imported":len(imported)}
