from fastapi import APIRouter
from app.services.tool_registry import registry
from app.core.config import settings
router=APIRouter()
@router.get('/platform/capabilities')
async def capabilities():
    return {
        'name':settings.app_name,'version':'6.0','tools':registry.list(),
        'execution':{'mode':settings.execution_mode,'terminal':settings.terminal_enabled,'docker':settings.execution_mode=='docker'},
        'agent':{'parallel':settings.parallel_agents_enabled,'max_repairs':settings.max_repair_cycles},
        'research':{'web':True,'deep':True},
        'integrations':{'github':bool(settings.github_allow_public_import)},
    }

@router.get('/usage')
async def usage():
    # Deployment hook: real multi-tenant usage/cost accounting should be persisted per request.
    # This endpoint intentionally reports configuration/capability state, not invented token costs.
    return {
        'reporting_ready': True,
        'token_costs': 'not estimated without provider usage telemetry',
        'limits': {
            'max_repairs': settings.max_repair_cycles,
            'max_file_chars': settings.max_file_chars,
            'max_project_files': settings.max_project_files,
            'sandbox_timeout_seconds': settings.sandbox_timeout_seconds,
        },
    }
