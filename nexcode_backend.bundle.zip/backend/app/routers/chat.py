from datetime import datetime
import json
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.db.models import Conversation, Message, Project, ProjectFile
from app.routers.auth import current_user
from app.services.orchestrator import run_end_to_end
from app.services.project import context_pack, build_tree

router = APIRouter()
class ChatIn(BaseModel):
    conversation_id: int | None = None
    message: str
    mode: str = "auto"
    project_id: int | None = None
    web_mode: str = "auto"

@router.post("/chat")
async def send_chat(data: ChatIn, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    if not data.message.strip(): raise HTTPException(400, "Message is empty")
    conv = await db.get(Conversation, data.conversation_id) if data.conversation_id else None
    if conv and conv.user_id != user.id: raise HTTPException(404, "Conversation not found")
    if conv is None:
        conv = Conversation(user_id=user.id, title=data.message.strip()[:80])
        db.add(conv); await db.flush()
    old = (await db.execute(select(Message).where(Message.conversation_id == conv.id).order_by(Message.id))).scalars().all()
    history = [{"role": m.role, "content": m.content} for m in old[-40:]]
    history.append({"role": "user", "content": data.message.strip()})
    db.add(Message(conversation_id=conv.id, role="user", content=data.message.strip()))
    project_context = ""
    tree = ""
    if data.project_id:
        project = await db.get(Project, data.project_id)
        if not project or project.user_id != user.id: raise HTTPException(404, "Project not found")
        files = list((await db.execute(select(ProjectFile).where(ProjectFile.project_id == project.id).order_by(ProjectFile.path))).scalars().all())
        project_context = context_pack(files)
        tree = build_tree(files)
    result = await run_end_to_end(db, user.id, data.project_id, history, mode=data.mode, web_mode=data.web_mode)
    db.add(Message(conversation_id=conv.id, role="assistant", content=result.answer))
    conv.updated_at = datetime.utcnow()
    await db.commit()
    execution={"ok":result.execution.ok,"summary":result.execution.summary,"checks":[{"name":c.name,"ok":c.ok,"output":c.output} for c in result.execution.checks]} if result.execution else None
    return {"conversation_id": conv.id, "answer": result.answer, "route": result.route, "plan": result.plan, "actions": result.actions, "status":result.status, "applied":result.applied, "repair_cycles":result.repair_cycles, "task_id":result.task_id, "revision_id":result.revision_id, "pipeline":result.pipeline, "impact":result.impact, "git":result.git, "quality":result.quality, "parallel_agents":result.analysts, "execution":execution, "research":{"enabled":result.research.enabled,"depth":result.research.depth,"queries":result.research.queries,"sources":[{"query":x.query,"text":x.text,"urls":x.urls} for x in result.research.sources],"synthesis":result.research.synthesis,"gaps":result.research.gaps}}

@router.get("/conversations")
async def conversations(db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    rows=(await db.execute(select(Conversation).where(Conversation.user_id==user.id).order_by(Conversation.updated_at.desc()))).scalars().all()
    return [{"id":x.id,"title":x.title,"updated_at":x.updated_at.isoformat()} for x in rows]

@router.get("/conversations/{conversation_id}")
async def conversation(conversation_id:int,db:AsyncSession=Depends(get_db),user=Depends(current_user)):
    conv=await db.get(Conversation,conversation_id)
    if not conv or conv.user_id!=user.id: raise HTTPException(404,"Conversation not found")
    msgs=(await db.execute(select(Message).where(Message.conversation_id==conv.id).order_by(Message.id))).scalars().all()
    return {"id":conv.id,"title":conv.title,"messages":[{"role":m.role,"content":m.content} for m in msgs]}


@router.get("/tasks/{task_id}")
async def task(task_id:int, db:AsyncSession=Depends(get_db), user=Depends(current_user)):
    from app.db.models import TaskRun
    t=await db.get(TaskRun,task_id)
    if not t or t.user_id!=user.id: raise HTTPException(404,"Task not found")
    return {"id":t.id,"status":t.status,"request":t.request,"pipeline":json.loads(t.pipeline_json),"result":json.loads(t.result_json),"created_at":t.created_at.isoformat(),"updated_at":t.updated_at.isoformat()}
