from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
from urllib.parse import urlparse

SAFE_ACTIONS = {"open_url", "click", "type", "press", "screenshot", "wait", "scroll"}
HIGH_RISK = {"download", "upload", "submit_payment", "delete", "shell"}

@dataclass
class ComputerAction:
    kind: str
    target: str = ""
    value: str = ""
    approved: bool = False


def validate_action(action: dict[str, Any]) -> dict[str, Any]:
    kind = str(action.get("kind", "")).strip()
    if kind not in SAFE_ACTIONS | HIGH_RISK:
        return {"ok": False, "reason": "unknown_action", "action": action}
    if kind == "open_url":
        u = str(action.get("target", ""))
        p = urlparse(u)
        if p.scheme not in {"https", "http"} or not p.netloc:
            return {"ok": False, "reason": "invalid_url", "action": action}
    approval_required = kind in HIGH_RISK
    if approval_required and not bool(action.get("approved")):
        return {"ok": False, "reason": "approval_required", "action": action}
    return {"ok": True, "approval_required": approval_required, "action": action}


def plan_actions(goal: str) -> list[dict[str, Any]]:
    text = goal.strip()
    lower = text.lower()
    actions: list[dict[str, Any]] = []
    if lower.startswith(("http://", "https://")):
        actions.append(asdict(ComputerAction("open_url", target=text)))
    actions.append(asdict(ComputerAction("screenshot")))
    return actions


def dry_run(goal: str, actions: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    planned = actions if actions is not None else plan_actions(goal)
    checked = [validate_action(a) for a in planned]
    return {
        "mode": "dry_run",
        "goal": goal,
        "planned": planned,
        "validated": checked,
        "requires_human_approval": any((not x["ok"] and x["reason"] == "approval_required") for x in checked),
        "live_driver": "optional_playwright",
    }


def driver_status() -> dict[str, Any]:
    try:
        import playwright  # type: ignore
        return {"available": True, "driver": "playwright", "live": True}
    except Exception:
        return {"available": False, "driver": "none", "live": False, "install": "pip install playwright && playwright install chromium"}
