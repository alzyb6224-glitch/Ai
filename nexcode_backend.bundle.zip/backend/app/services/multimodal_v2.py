from __future__ import annotations
from typing import Any

def inspect_assets(files:list[dict[str,Any]])->dict[str,Any]:
    images=[f for f in files if str(f.get("path","")).lower().endswith((".png",".jpg",".jpeg",".webp",".gif"))]
    docs=[f for f in files if str(f.get("path","")).lower().endswith((".md",".txt",".pdf"))]
    return {"version":2,"asset_count":len(files),"images":len(images),"docs":len(docs),"capabilities":["image-aware-project-map","screenshot-to-task","asset-index"]}
