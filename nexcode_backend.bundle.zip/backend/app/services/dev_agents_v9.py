from __future__ import annotations
import re,json
from dataclasses import dataclass,asdict
@dataclass
class Finding: severity:str; category:str; message:str; path:str=''
class CodeReviewAgent:
    def review(self,files):
        out=[]
        for f in files:
            if 'except:' in f.content: out.append(Finding('high','reliability','Bare except hides failures',f.path))
            if 'eval(' in f.content: out.append(Finding('critical','security','eval() detected',f.path))
            if 'TODO' in f.content: out.append(Finding('low','maintainability','TODO remains',f.path))
        return [asdict(x) for x in out]
class DependencyAgent:
    def inspect(self,manifests):
        out=[]
        for path,content in manifests.items():
            if path.endswith('requirements.txt'): names=re.findall(r'^([A-Za-z0-9_.-]+)',content,re.M)
            elif path.endswith('pubspec.yaml'): names=re.findall(r'^  ([A-Za-z0-9_]+):',content,re.M)
            elif path.endswith('package.json'):
                try: names=list(json.loads(content).get('dependencies',{}))
                except Exception: names=[]
            else: names=[]
            out.append({'path':path,'dependencies':names,'count':len(names)})
        return out
class SecurityAuditorAgent:
    def audit(self,files):
        findings=CodeReviewAgent().review(files)
        for f in files:
            if re.search(r'password\s*=\s*[\'"]',f.content,re.I): findings.append(asdict(Finding('critical','secrets','Possible hard-coded password',f.path)))
            if 'http://' in f.content: findings.append(asdict(Finding('medium','transport','Insecure HTTP reference',f.path)))
        return findings
class DeployAgent:
    def plan(self,target,project_id):
        if target not in {'docker','github-pages','render','vercel','railway'}: raise ValueError('Unsupported deploy target')
        return {'target':target,'project_id':project_id,'approval_required':True,'steps':['prepare','build','healthcheck','publish']}
class MobileAgent:
    def quick_actions(self): return ['new task','inspect project','run tests','review code','view logs','deploy']
