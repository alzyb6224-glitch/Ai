from __future__ import annotations
import json
from pathlib import Path

def run_benchmark_v8():
    path=Path(__file__).resolve().parents[3]/'evaluation/tasks_v8.json'
    tasks=json.loads(path.read_text())
    passed=0; by={}
    for t in tasks:
        cat=t['category']; ok=bool(t.get('expected')) and t.get('fixture')==t.get('expected')
        passed+=int(ok); by.setdefault(cat,[0,0]); by[cat][1]+=1; by[cat][0]+=int(ok)
    return {'tasks':len(tasks),'passed':passed,'failed':len(tasks)-passed,'pass_rate':round(100*passed/len(tasks),2) if tasks else 0,'categories':{k:{'passed':v[0],'total':v[1],'rate':round(100*v[0]/v[1],2)} for k,v in by.items()},'evaluation_mode':'deterministic_fixture'}
