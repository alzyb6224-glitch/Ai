from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass
class RepairDecision:
    action: str
    reason: str
    confidence: float


def decide_repair(*, failed: bool, changed_files: int, cycles: int, max_cycles: int, repeated_failure: bool = False) -> RepairDecision:
    if not failed:
        return RepairDecision('stop', 'Verification passed.', 1.0)
    if cycles >= max_cycles:
        return RepairDecision('stop', 'Repair budget exhausted; prevent infinite loops.', 1.0)
    if repeated_failure:
        return RepairDecision('replan', 'The same failure pattern repeated; change strategy instead of repeating the same patch.', 0.95)
    if changed_files > 0:
        return RepairDecision('repair', 'A bounded corrective patch can be attempted.', 0.90)
    return RepairDecision('diagnose', 'No applied changes are available; gather a stronger diagnosis before modifying code.', 0.82)


def summarize_attempts(attempts: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        'attempts': len(attempts),
        'successful': sum(1 for x in attempts if x.get('ok')),
        'failed': sum(1 for x in attempts if not x.get('ok')),
        'cycles': max((int(x.get('cycle', 0)) for x in attempts), default=0),
        'replanned': sum(1 for x in attempts if x.get('action') == 'replan'),
    }
