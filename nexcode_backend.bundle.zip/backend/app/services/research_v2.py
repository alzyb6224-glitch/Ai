from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from app.services.web_research import research

@dataclass
class ResearchV2Result:
    enabled: bool
    mode: str
    questions: list[str]
    sources: list[dict[str, Any]]
    synthesis: str
    confidence: float

async def deep_research_v2(query: str, mode: str = "deep", max_questions: int = 4) -> ResearchV2Result:
    q = query.strip()
    questions = [q]
    if len(q.split()) > 7:
        questions += [f"What are the constraints and security considerations for: {q}", f"What implementation patterns are recommended for: {q}"]
    questions = questions[:max_questions]
    results=[]; synth=[]
    for question in questions:
        r=await research(question, "deep" if mode=="deep" else "fast")
        synth.append(r.synthesis or "")
        results.extend(r.sources or [])
    seen=set(); unique=[]
    for s in results:
        u=s.get("url") or s.get("title") or str(s)
        if u not in seen: seen.add(u); unique.append(s)
    return ResearchV2Result(bool(q), mode, questions, unique[:40], "\n\n".join(x for x in synth if x), 0.8 if unique else 0.35)
