from __future__ import annotations
import re
from collections import Counter, defaultdict
from pathlib import PurePosixPath
from typing import Iterable, Any
from app.db.models import ProjectFile

ENTRY_NAMES = {'main.py','main.dart','main.js','main.ts','index.js','index.ts','app.py','server.py','manage.py'}
TEST_RE = re.compile(r'(^|/)(test_|tests?/|.*_test\.|.*\.test\.|.*\.spec\.)', re.I)


def _tokens(text: str) -> set[str]:
    return set(re.findall(r'[A-Za-z_][A-Za-z0-9_]{2,}', text))


def analyze_project_v2(files: Iterable[ProjectFile]) -> dict[str, Any]:
    files = list(files)
    paths = {f.path for f in files}
    languages = Counter(f.language for f in files)
    symbols: dict[str, list[str]] = defaultdict(list)
    imports: dict[str, list[str]] = {}
    references: dict[str, list[str]] = defaultdict(list)
    hotspots = []
    entrypoints = [f.path for f in files if PurePosixPath(f.path).name in ENTRY_NAMES]
    tests = [f.path for f in files if TEST_RE.search(f.path)]

    for f in files:
        if f.language == 'python' or f.path.endswith('.py'):
            syms = re.findall(r'^\s*(?:class|def|async def)\s+([A-Za-z_]\w*)', f.content, re.M)
            imps = re.findall(r'^\s*(?:from|import)\s+([A-Za-z_][\w.]*)', f.content, re.M)
        elif f.path.endswith(('.ts','.tsx','.js','.jsx')):
            syms = re.findall(r'\b(?:class|function|interface|type)\s+([A-Za-z_]\w*)', f.content)
            imps = re.findall(r'\bfrom\s+[\'\"]([^\'\"]+)[\'\"]|\brequire\(\s*[\'\"]([^\'\"]+)', f.content)
            imps = [a or b for a,b in imps]
        elif f.path.endswith('.dart'):
            syms = re.findall(r'^\s*(?:class|mixin|enum|extension)\s+([A-Za-z_]\w*)', f.content, re.M)
            imps = re.findall(r'^\s*import\s+[\'\"]package:([^\'\"]+)[\'\"]', f.content, re.M)
        else:
            syms, imps = [], []
        symbols[f.path].extend(syms[:250])
        imports[f.path] = imps[:250]
        size = len(f.content)
        todo = len(re.findall(r'\bTODO\b|\bFIXME\b', f.content, re.I))
        complexity = len(re.findall(r'\b(if|for|while|match|switch|catch|except|try)\b', f.content))
        score = round((size/1000) + todo*4 + complexity*0.3, 2)
        if score >= 20:
            hotspots.append({'path': f.path, 'score': score, 'todo': todo, 'complexity_signals': complexity})

    # Conservative file-to-file resolution for relative/local imports.
    for src, imps in imports.items():
        for imp in imps:
            candidates = {imp, imp.replace('.','/')}
            if imp.startswith('.'):
                base = PurePosixPath(src).parent
                candidates.add(str(base.joinpath(imp).as_posix()).lstrip('./'))
            for target in paths:
                stem = target.rsplit('.',1)[0]
                if any(target == c or stem.endswith(c.lstrip('./')) for c in candidates):
                    if target != src:
                        references[target].append(src)

    components = []
    for p in sorted(paths):
        if p in entrypoints: role = 'entrypoint'
        elif p in tests: role = 'test'
        elif p in references: role = 'dependency'
        else: role = 'module'
        components.append({'path': p, 'role': role, 'symbols': symbols.get(p, [])[:80], 'imports': imports.get(p, [])[:80]})

    return {
        'version': '2',
        'files': len(files),
        'languages': dict(languages),
        'entrypoints': entrypoints,
        'tests': tests,
        'symbols': [{'path': p, 'names': names} for p,names in symbols.items()],
        'imports': imports,
        'reverse_dependencies': {k: sorted(set(v)) for k,v in references.items()},
        'hotspots': sorted(hotspots, key=lambda x: x['score'], reverse=True)[:50],
        'architecture': components,
    }
