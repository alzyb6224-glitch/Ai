from __future__ import annotations
from dataclasses import dataclass, asdict
import difflib, hashlib, time
from typing import Any

@dataclass
class Artifact:
    path: str
    kind: str
    content: str
    version: int = 1
    sha256: str = ""
    created_at: float = 0.0
    updated_at: float = 0.0
    def __post_init__(self):
        now=time.time(); self.created_at=self.created_at or now; self.updated_at=now; self.sha256=hashlib.sha256(self.content.encode()).hexdigest()

class WorkspaceV2:
    def __init__(self): self.artifacts: dict[str, Artifact] = {}
    def upsert(self, path: str, content: str, kind: str = "code") -> dict[str,Any]:
        safe=path.replace('\\','/').lstrip('/')
        if '..' in safe.split('/') or not safe: raise ValueError('Invalid artifact path')
        old=self.artifacts.get(safe)
        if old:
            old.content=content; old.kind=kind; old.version += 1; old.updated_at=time.time(); old.sha256=hashlib.sha256(content.encode()).hexdigest(); return asdict(old)
        obj=Artifact(safe,kind,content); self.artifacts[safe]=obj; return asdict(obj)
    def diff(self,path:str,new_content:str)->str:
        old=self.artifacts.get(path)
        before=old.content.splitlines(True) if old else []
        after=new_content.splitlines(True)
        return ''.join(difflib.unified_diff(before,after,fromfile=path,tofile=path))
    def manifest(self)->list[dict[str,Any]]: return [asdict(x) for x in self.artifacts.values()]
