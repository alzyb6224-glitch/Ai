from __future__ import annotations
from dataclasses import dataclass,asdict
from typing import Any,Callable
@dataclass
class LoopStep: name:str; status:str='pending'; output:Any=None
class AutonomousLoopV9:
    def __init__(self,max_iterations:int=5): self.max_iterations=max(1,min(max_iterations,20)); self.steps=[]
    def run(self,plan_fn:Callable[[],Any],execute_fn:Callable[[Any],Any],verify_fn:Callable[[Any],bool],repair_fn:Callable[[Any],Any]|None=None):
        self.steps=[]; state=plan_fn(); self.steps.append(LoopStep('plan','done',state))
        for i in range(self.max_iterations):
            out=execute_fn(state); self.steps.append(LoopStep(f'execute_{i+1}','done',out))
            if verify_fn(out): self.steps.append(LoopStep('verify','passed')); return {'status':'verified','iterations':i+1,'steps':[asdict(s) for s in self.steps]}
            self.steps.append(LoopStep(f'verify_{i+1}','failed'))
            if repair_fn is None: break
            state=repair_fn(out); self.steps.append(LoopStep(f'repair_{i+1}','done',state))
        return {'status':'needs_review','iterations':len([s for s in self.steps if s.name.startswith('execute_')]),'steps':[asdict(s) for s in self.steps]}
