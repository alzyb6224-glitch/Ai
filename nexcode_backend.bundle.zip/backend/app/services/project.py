from collections import Counter
from pathlib import PurePosixPath
from typing import Iterable
from app.db.models import ProjectFile

IMPORTANT_FILES = {"README.md","package.json","pubspec.yaml","requirements.txt","pyproject.toml","Dockerfile","docker-compose.yml",".env.example","tsconfig.json","vite.config.ts"}

def build_tree(files: Iterable[ProjectFile]) -> str:
    rows = []
    for f in files:
        rows.append(f.path)
    return "\n".join(sorted(rows))

def summarize(files: list[ProjectFile]) -> dict:
    langs = Counter(f.language for f in files)
    total_chars = sum(len(f.content) for f in files)
    top = sorted(files, key=lambda f: len(f.content), reverse=True)[:12]
    important = [f.path for f in files if PurePosixPath(f.path).name in IMPORTANT_FILES]
    return {
        "file_count": len(files),
        "total_chars": total_chars,
        "languages": dict(langs),
        "largest_files": [{"path": f.path, "chars": len(f.content), "language": f.language} for f in top],
        "important_files": important,
        "tree": build_tree(files),
    }

def context_pack(files: list[ProjectFile], max_chars: int = 180_000) -> str:
    # Prioritize important/config/entry files, then largest source files.
    ordered = sorted(files, key=lambda f: (0 if PurePosixPath(f.path).name in IMPORTANT_FILES else 1, -len(f.content), f.path))
    out, used = [], 0
    for f in ordered:
        content = f.content[:20_000]
        block = f"FILE: {f.path} ({f.language})\n```{f.language}\n{content}\n```\n"
        if used + len(block) > max_chars: continue
        out.append(block); used += len(block)
    return "\n".join(out)


def search_files(files: list[ProjectFile], query: str, limit: int = 12) -> list[dict]:
    """Lightweight semantic-ish repository search using filename + token relevance.
    This is deliberately local and dependency-free; it can later be swapped for embeddings.
    """
    tokens = {t.lower() for t in __import__('re').findall(r"[\w.-]{2,}", query) if len(t) >= 2}
    ranked=[]
    for f in files:
        hay=(f.path + "\n" + f.content).lower()
        path_low=f.path.lower()
        score=0
        for t in tokens:
            score += hay.count(t)
            if t in path_low: score += 8
        if score:
            ranked.append((score, len(f.content), f))
    ranked.sort(key=lambda x:(x[0], x[1]), reverse=True)
    out=[]
    for score, _, f in ranked[:limit]:
        snippet=f.content[:5000]
        out.append({"path":f.path,"language":f.language,"score":score,"snippet":snippet})
    return out
