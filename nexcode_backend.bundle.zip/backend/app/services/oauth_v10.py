from __future__ import annotations
import base64
import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.models import User

@dataclass(frozen=True)
class Provider:
    key: str
    label: str
    auth_url: str
    token_url: str
    userinfo_url: str = ""
    scopes: tuple[str, ...] = ()
    client_id: str = ""
    client_secret: str = ""
    issuer: str = ""


def _p(key: str, label: str, auth: str, token: str, userinfo: str, scopes: tuple[str, ...], cid: str, secret: str, issuer: str = "") -> Provider:
    return Provider(key, label, auth, token, userinfo, scopes, cid, secret, issuer)


def providers() -> dict[str, Provider]:
    return {
        "google": _p("google", "Google", "https://accounts.google.com/o/oauth2/v2/auth", "https://oauth2.googleapis.com/token", "https://openidconnect.googleapis.com/v1/userinfo", ("openid", "email", "profile"), settings.google_client_id, settings.google_client_secret, "https://accounts.google.com"),
        "apple": _p("apple", "Apple", "https://appleid.apple.com/auth/authorize", "https://appleid.apple.com/auth/token", "", ("name", "email"), settings.apple_client_id, settings.apple_client_secret, "https://appleid.apple.com"),
        "github": _p("github", "GitHub", "https://github.com/login/oauth/authorize", "https://github.com/login/oauth/access_token", "https://api.github.com/user", ("read:user", "user:email"), settings.github_oauth_client_id, settings.github_oauth_client_secret),
        "microsoft": _p("microsoft", "Microsoft", "https://login.microsoftonline.com/common/oauth2/v2.0/authorize", "https://login.microsoftonline.com/common/oauth2/v2.0/token", "https://graph.microsoft.com/oidc/userinfo", ("openid", "email", "profile", "User.Read"), settings.microsoft_client_id, settings.microsoft_client_secret, "https://login.microsoftonline.com/common/v2.0"),
        "discord": _p("discord", "Discord", "https://discord.com/oauth2/authorize", "https://discord.com/api/oauth2/token", "https://discord.com/api/users/@me", ("identify", "email"), settings.discord_client_id, settings.discord_client_secret),
    }


def enabled_providers() -> list[dict[str, Any]]:
    out = []
    for p in providers().values():
        if p.client_id and p.client_secret:
            out.append({"id": p.key, "label": p.label})
    return out


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")

def _unb64(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))

def _state_sign(raw: bytes) -> str:
    return hmac.new(settings.secret_key.encode(), raw, hashlib.sha256).hexdigest()

def state_token(provider: str, redirect_uri: str) -> str:
    payload = {"provider": provider, "redirect_uri": redirect_uri, "nonce": secrets.token_urlsafe(24), "exp": int(time.time()) + 600}
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    return f"{_b64(raw)}.{_state_sign(raw)}"

def verify_state(state: str) -> dict[str, Any]:
    try:
        encoded, signature = state.split(".", 1)
        raw = _unb64(encoded)
    except Exception as exc:
        raise ValueError("Invalid OAuth state") from exc
    if not hmac.compare_digest(_state_sign(raw), signature):
        raise ValueError("Invalid OAuth state signature")
    payload = json.loads(raw)
    if int(payload.get("exp", 0)) < int(time.time()):
        raise ValueError("OAuth state expired")
    return payload


def authorize_url(provider: str, redirect_uri: str) -> str:
    p = providers().get(provider)
    if not p or not p.client_id or not p.client_secret:
        raise ValueError("OAuth provider is not configured")
    state = state_token(provider, redirect_uri)
    params = {
        "client_id": p.client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": " ".join(p.scopes),
        "state": state,
    }
    if provider == "apple":
        params["response_mode"] = "query"
    if provider == "google":
        params["access_type"] = "offline"
        params["prompt"] = "select_account"
    return p.auth_url + "?" + urlencode(params)


async def _token(p: Provider, code: str, redirect_uri: str) -> dict[str, Any]:
    data = {"client_id": p.client_id, "client_secret": p.client_secret, "code": code, "redirect_uri": redirect_uri, "grant_type": "authorization_code"}
    headers = {"Accept": "application/json"}
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(p.token_url, data=data, headers=headers)
        r.raise_for_status()
        return r.json()


async def identity_from_code(provider: str, code: str, redirect_uri: str) -> dict[str, str]:
    p = providers().get(provider)
    if not p:
        raise ValueError("Unknown OAuth provider")
    tok = await _token(p, code, redirect_uri)
    access = tok.get("access_token", "")
    if not access:
        raise ValueError("OAuth provider did not return an access token")
    headers = {"Authorization": f"Bearer {access}", "Accept": "application/json"}
    if provider == "github":
        async with httpx.AsyncClient(timeout=15) as client:
            me = (await client.get(p.userinfo_url, headers=headers)).json()
            email = me.get("email")
            if not email:
                emails = (await client.get("https://api.github.com/user/emails", headers=headers)).json()
                email = next((x.get("email") for x in emails if x.get("verified")), None)
        if not email:
            raise ValueError("GitHub account has no verified email available")
        return {"email": email.lower(), "display_name": me.get("name") or me.get("login") or "Developer", "provider": provider}
    if provider == "apple":
        raw = tok.get("id_token", "")
        if not raw:
            raise ValueError("Apple did not return an identity token")
        async with httpx.AsyncClient(timeout=15) as client:
            jwks = (await client.get("https://appleid.apple.com/auth/keys")).json()
        header = jwt.get_unverified_header(raw)
        jwk = next((k for k in jwks.get("keys", []) if k.get("kid") == header.get("kid")), None)
        if not jwk:
            raise ValueError("Apple signing key not found")
        from jose import jwt
        claims = jwt.decode(raw, jwk, algorithms=["RS256"], audience=p.client_id, issuer=p.issuer)
        email = claims.get("email")
        if not email:
            raise ValueError("Apple did not provide an email")
        return {"email": email.lower(), "display_name": "Apple Developer", "provider": provider}
    async with httpx.AsyncClient(timeout=15) as client:
        me = (await client.get(p.userinfo_url, headers=headers)).json()
    email = me.get("email") or me.get("preferred_username")
    if not email:
        raise ValueError("OAuth provider did not provide an email")
    display = me.get("name") or me.get("given_name") or me.get("login") or me.get("username") or "Developer"
    return {"email": email.lower(), "display_name": display[:120], "provider": provider}


async def complete(db: AsyncSession, provider: str, state: str, code: str) -> dict[str, Any]:
    st = verify_state(state)
    if st.get("provider") != provider:
        raise ValueError("OAuth state/provider mismatch")
    ident = await identity_from_code(provider, code, st["redirect_uri"])
    user = (await db.execute(select(User).where(User.email == ident["email"]))).scalar_one_or_none()
    if not user:
        # Password login remains disabled until the user explicitly sets one later.
        user = User(email=ident["email"], password_hash=hashlib.sha256(secrets.token_bytes(32)).hexdigest(), display_name=ident["display_name"])
        db.add(user)
        await db.commit()
        await db.refresh(user)
    elif ident.get("display_name") and user.display_name == "Developer":
        user.display_name = ident["display_name"]
        await db.commit()
    from app.core.security import create_token
    return {"access_token": create_token(user.id), "token_type": "bearer", "user": {"id": user.id, "email": user.email, "display_name": user.display_name}, "provider": provider}
