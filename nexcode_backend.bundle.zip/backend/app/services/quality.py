from __future__ import annotations
import json, re
from dataclasses import dataclass
from typing import Iterable
from app.db.models import ProjectFile
from app.services.code_intelligence import analyze_project
from app.services.executor import validate_project, ExecutionResult

@dataclass
class QualityReport:
    score: int
    code_quality: int
    tests: int
    build: str
    security: int
    dependencies: str
    regression: str
    findings: list[dict]
    execution: ExecutionResult

SECRET_RE = re.compile(r'(?i)(api[_-]?key|secret|password|token)\s*[:=]\s*["\'][^"\']{8,}["\']')
RISKY_RE = re.compile(r'(?i)\b(eval|exec|os\.system|subprocess\.run|child_process|innerHTML)\b')

def review_code(files: list[ProjectFile]) -> list[dict]:
    findings=[]
    seen=set()
    for f in files:
        for line_no, line in enumerate(f.content.splitlines(), 1):
            if SECRET_RE.search(line):
                findings.append({'severity':'high','path':f.path,'line':line_no,'message':'Possible hard-coded secret or credential.'})
            if RISKY_RE.search(line):
                findings.append({'severity':'medium','path':f.path,'line':line_no,'message':'Potentially dangerous execution or HTML injection primitive; review before production.'})
            if len(line) > 180:
                key=(f.path,line_no,'long');
                if key not in seen:
                    findings.append({'severity':'low','path':f.path,'line':line_no,'message':'Very long line may reduce maintainability.'}); seen.add(key)
    return findings[:300]

def dependencies(files: list[ProjectFile]) -> str:
    for f in files:
        if f.path == 'package.json':
            try:
                data=json.loads(f.content); return 'PASS' if data.get('dependencies') is not None else 'WARN'
            except Exception: return 'FAIL'
        if f.path == 'pubspec.yaml': return 'DECLARED'
        if f.path in {'requirements.txt','pyproject.toml','go.mod','Cargo.toml'}: return 'DECLARED'
    return 'N/A'

def build_status(execution: ExecutionResult) -> str:
    names=' '.join(c.name for c in execution.checks).lower()
    if 'build' in names:
        return 'PASS' if execution.ok else 'FAIL'
    return 'NOT_RUN'

def generate_quality_report(files: list[ProjectFile], run_build: bool=False, install: bool=False) -> QualityReport:
    execution=validate_project(files, include_build=run_build, include_install=install)
    findings=review_code(files)
    intel=analyze_project(files)
    code_quality=max(0, 100 - min(45, sum(8 if f['severity']=='high' else 4 if f['severity']=='medium' else 1 for f in findings)))
    tests=100 if execution.ok else 50
    build=build_status(execution)
    security=max(0, 100 - min(60, sum(20 if f['severity']=='high' else 8 if f['severity']=='medium' else 1 for f in findings)))
    dep=dependencies(files)
    regression='PASS' if execution.ok else 'UNKNOWN'
    overall=round(code_quality*0.25 + tests*0.25 + security*0.25 + (100 if dep in {'PASS','DECLARED','N/A'} else 50)*0.15 + (100 if regression=='PASS' else 50)*0.10)
    if intel['unresolved_imports']:
        findings.append({'severity':'medium','message':f"{len(intel['unresolved_imports'])} project-local imports could not be resolved."})
    return QualityReport(overall, code_quality, tests, build, security, dep, regression, findings, execution)
