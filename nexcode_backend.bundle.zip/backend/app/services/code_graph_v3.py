from __future__ import annotations
import re
from collections import defaultdict
from pathlib import PurePosixPath
from typing import Iterable,Any
def build_graph(files:Iterable[Any])->dict[str,Any]:
    files=list(files); paths={f.path for f in files}; nodes=[]; edges=[]
    imports={}; symbols={}
    for f in files:
        symbols[f.path]=re.findall(r'^\s*(?:class|def|async def|function|interface|type|enum)\s+([A-Za-z_]\w*)',f.content,re.M)[:300]
        imports[f.path]=re.findall(r'^\s*(?:from|import)\s+([A-Za-z_][\w./-]*)',f.content,re.M)[:300]; nodes.append({'id':f.path,'type':'file','symbols':symbols[f.path][:100]})
    for src,imps in imports.items():
        for imp in imps:
            normalized=imp.replace('.','/').lstrip('./')
            for target in paths:
                stem=target.rsplit('.',1)[0]
                if target==imp or stem.endswith(normalized) or PurePosixPath(target).stem==PurePosixPath(normalized).name:
                    if target!=src: edges.append({'from':src,'to':target,'kind':'imports'})
    reverse=defaultdict(list)
    for e in edges: reverse[e['to']].append(e['from'])
    return {'version':'3','nodes':nodes,'edges':edges,'reverse_dependencies':{k:sorted(set(v)) for k,v in reverse.items()},'stats':{'files':len(paths),'edges':len(edges),'symbols':sum(map(len,symbols.values()))}}
def impact(graph:dict[str,Any],changed:list[str])->dict[str,Any]:
    reverse=graph.get('reverse_dependencies',{}); impacted=set(changed); q=list(changed)
    while q:
        x=q.pop()
        for y in reverse.get(x,[]):
            if y not in impacted: impacted.add(y); q.append(y)
    return {'changed':sorted(set(changed)),'impacted':sorted(impacted-set(changed)),'blast_radius':len(impacted)}
