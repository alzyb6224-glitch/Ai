from __future__ import annotations
from dataclasses import dataclass

@dataclass
class BudgetDecision:
    allowed: bool
    estimated_usd: float
    remaining_usd: float
    reason: str

def decide(estimated_input_tokens:int, estimated_output_tokens:int, budget_usd:float, price_per_million_tokens:float=10.0, spent_usd:float=0.0)->BudgetDecision:
    total=max(0,estimated_input_tokens)+max(0,estimated_output_tokens)
    estimate=total/1_000_000*max(0.0,price_per_million_tokens)
    remaining=budget_usd-spent_usd
    return BudgetDecision(estimate<=remaining,round(estimate,6),round(remaining-estimate,6),'within_budget' if estimate<=remaining else 'budget_exceeded')
