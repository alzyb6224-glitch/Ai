from __future__ import annotations
import os
from pathlib import Path
from typing import Any

ALLOWED_ROOTS = ("/workspace", "/tmp/nexcode")
BLOCKED = {"/etc/passwd", "/etc/shadow", "/proc", "/sys", "/dev"}


def validate_path(path: str) -> bool:
    p = os.path.abspath(path)
    if p in BLOCKED or any(p.startswith(b + os.sep) for b in BLOCKED):
        return False
    return any(p == root or p.startswith(root + os.sep) for root in ALLOWED_ROOTS)


def tool_policy(tool: str, *, approved: bool = False, network: bool = False) -> dict[str, Any]:
    risky = tool in {"shell", "deploy", "publish", "delete_project", "secret_access", "network_write"}
    if risky and not approved:
        return {"allowed": False, "status": "approval_required", "risk": "high"}
    if network and tool not in {"web_search", "browser_read"}:
        return {"allowed": False, "status": "network_denied"}
    return {"allowed": True, "status": "approved" if risky else "safe", "risk": "high" if risky else "low"}
