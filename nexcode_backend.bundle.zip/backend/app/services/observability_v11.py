from __future__ import annotations
from collections import Counter
from typing import Any


def summarize_events(events: list[dict[str, Any]]) -> dict[str, Any]:
    durations = [int(e.get("duration_ms", 0)) for e in events]
    statuses = Counter(e.get("status", "unknown") for e in events)
    agents = Counter(e.get("agent", "unknown") for e in events)
    return {
        "events": len(events),
        "statuses": dict(statuses),
        "agents": dict(agents),
        "total_duration_ms": sum(durations),
        "max_event_ms": max(durations) if durations else 0,
        "failed_events": statuses.get("failed", 0),
    }


def dashboard(task_rows: list[dict[str, Any]]) -> dict[str, Any]:
    events = []
    for row in task_rows:
        events.extend(row.get("events", []))
    summary = summarize_events(events)
    return {
        "version": "V11",
        "tasks": len(task_rows),
        "completed": sum(1 for r in task_rows if r.get("status") == "done"),
        "failed": sum(1 for r in task_rows if r.get("status") == "failed"),
        "active": sum(1 for r in task_rows if r.get("status") in {"queued", "running"}),
        "observability": summary,
    }
