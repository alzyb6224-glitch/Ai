from __future__ import annotations
from dataclasses import dataclass,asdict
from typing import Any
from urllib.parse import urlparse
import re,time
SAFE={'open','click','fill','press','scroll','wait','screenshot','extract'}; RISKY={'download','upload','submit','delete','purchase','login'}
@dataclass
class BrowserStep: action:str; target:str=''; value:str=''; approved:bool=False
def validate_url(url:str,allowed_domains:set[str]|None=None)->bool:
    p=urlparse(url)
    return p.scheme in {'http','https'} and bool(p.hostname) and (not allowed_domains or p.hostname in allowed_domains or any(p.hostname.endswith('.'+d) for d in allowed_domains))
def plan(goal:str,urls:list[str]|None=None,allowed_domains:set[str]|None=None)->dict[str,Any]:
    steps=[BrowserStep('open',u) for u in (urls or [])]
    if re.search(r'fill|type|write',goal,re.I): steps.append(BrowserStep('fill',value=goal))
    steps += [BrowserStep('screenshot'),BrowserStep('extract')]
    checks=[]
    for s in steps:
        ok=s.action in SAFE or s.action in RISKY
        if s.action=='open': ok=validate_url(s.target,allowed_domains)
        risky=s.action in RISKY; checks.append({'ok':ok and (not risky or s.approved),'approval_required':risky,'step':asdict(s)})
    return {'goal':goal,'steps':[asdict(s) for s in steps],'checks':checks,'ready':all(c['ok'] for c in checks),'driver':driver_status()}
def driver_status()->dict[str,Any]:
    try: import playwright; return {'available':True,'driver':'playwright'}
    except Exception: return {'available':False,'driver':'none','install_hint':'Install Playwright plus a browser for live execution.'}
class BrowserSession:
    def __init__(self,allowed_domains:set[str]|None=None): self.allowed_domains=allowed_domains or set(); self.history=[]
    def record(self,action:str,target:str=''): self.history.append({'ts':time.time(),'action':action,'target':target})
    def snapshot(self): return {'steps':len(self.history),'history':list(self.history),'allowed_domains':sorted(self.allowed_domains)}
