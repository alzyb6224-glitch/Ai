from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Callable

@dataclass(frozen=True)
class Contract:
    name: str
    check: Callable[[dict], bool]


def run_contracts(runtime: dict) -> dict:
    contracts = [
        Contract("intent_routing", lambda r: r.get("plan", {}).get("intent") in {"coding","debug","test","research","mobile","backend","architecture","release","general"}),
        Contract("multi_agent", lambda r: len(r.get("plan", {}).get("selected_agents", [])) >= 2),
        Contract("context_selection", lambda r: "selection" in r.get("context", {})),
        Contract("security_gate", lambda r: "approvals_required" in r.get("plan", {})),
        Contract("event_trace", lambda r: isinstance(r.get("events"), list) and bool(r.get("events"))),
        Contract("checkpoint", lambda r: isinstance(r.get("checkpoints"), list) and bool(r.get("checkpoints"))),
        Contract("quality", lambda r: isinstance(r.get("quality"), dict)),
        Contract("final_status", lambda r: r.get("status") in {"planned","completed","completed_with_failures"}),
    ]
    results = [{"name": c.name, "passed": bool(c.check(runtime))} for c in contracts]
    passed = sum(1 for x in results if x["passed"])
    return {"version": "V11", "passed": passed, "total": len(results), "score": round(passed / len(results) * 100, 2), "results": results, "note": "contract benchmark; not an official SWE-bench score"}
