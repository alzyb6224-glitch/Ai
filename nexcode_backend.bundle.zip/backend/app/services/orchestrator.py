from __future__ import annotations
import asyncio, json, re
from dataclasses import dataclass
from typing import Any
from datetime import datetime
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.models import ProjectFile, ProjectRevision, ProjectMemory, TaskRun
from app.services.ai import client
from app.services.agent import execute_request
from app.services.executor import validate_project, ExecutionResult
from app.services.web_research import research, ResearchResult
from app.services.git_intel import sync_project
from app.services.project import context_pack, build_tree, search_files, summarize
from app.services.code_intelligence import analyze_project, impact_analysis
from app.services.parallel_agents import run_parallel_analysts
from app.services.quality import review_code
from app.services.self_healing import decide_repair, summarize_attempts
from app.core.config import settings

PIPELINE = [
    ("understand", "🧠 فهم الطلب والمتطلبات"),
    ("plan", "📋 بناء خطة التنفيذ"),
    ("project_search", "🔎 البحث داخل المشروع"),
    ("web_research", "🌐 بحث الإنترنت / Deep Research"),
    ("impact", "🧩 تحديد الملفات والاعتماديات المتأثرة"),
    ("implement", "✍️ إنشاء/تعديل الكود"),
    ("review", "🔍 Code Review تلقائي"),
    ("test", "🧪 تشغيل الاختبارات والفحوصات"),
    ("repair", "🔧 إصلاح تلقائي"),
    ("retest", "🧪 إعادة الاختبار"),
    ("deliver", "📦 تجهيز النتيجة"),
]

from app.services.action_guard import safe_actions
@dataclass
class OrchestrationResult:
    answer: str
    route: str
    plan: list[dict[str, Any]]
    actions: list[dict[str, Any]]
    research: ResearchResult
    execution: ExecutionResult | None = None
    applied: int = 0
    repair_cycles: int = 0
    status: str = "planned"
    pipeline: list[dict[str, Any]] | None = None
    task_id: int | None = None
    revision_id: int | None = None
    git: dict[str, Any] | None = None
    impact: dict[str, Any] | None = None
    quality: dict[str, Any] | None = None
    analysts: dict[str, Any] | None = None
    healing: dict[str, Any] | None = None
    intelligence_v2: dict[str, Any] | None = None


def _pipeline(statuses: dict[str, str]) -> list[dict[str, Any]]:
    return [{"key": k, "label": label, "status": statuses.get(k, "pending")} for k, label in PIPELINE]


def _safe_actions(actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return safe_actions(actions)


async def _record_memory(db: AsyncSession, project_id: int, files: list[ProjectFile], result: OrchestrationResult, request: str) -> None:
    memory = (await db.execute(select(ProjectMemory).where(ProjectMemory.project_id == project_id))).scalar_one_or_none()
    old: dict[str, Any] = {}
    if memory:
        try:
            old = json.loads(memory.memory_json)
        except Exception:
            old = {}
    history = old.get("recent_runs", [])
    history.append({"request": request[:500], "status": result.status, "route": result.route, "changed": result.applied, "repair_cycles": result.repair_cycles})
    old.update({
        "project_summary": summarize(files),
        "tech_stack": sorted({f.language for f in files}),
        "last_route": result.route,
        "last_status": result.status,
        "last_task": result.task_id,
        "last_change_count": result.applied,
        "last_research_depth": result.research.depth,
        "recent_runs": history[-20:],
        "known_findings": (result.quality or {}).get("findings", [])[:50],
        "updated_at": datetime.utcnow().isoformat(),
    })
    payload = json.dumps(old, ensure_ascii=False)
    if memory:
        memory.memory_json = payload
        memory.updated_at = datetime.utcnow()
    else:
        db.add(ProjectMemory(project_id=project_id, memory_json=payload))
    await db.commit()


async def _apply_actions(db: AsyncSession, project_id: int, user_id: int, actions: list[dict[str, Any]], summary: str) -> tuple[int, int | None]:
    files = list((await db.execute(select(ProjectFile).where(ProjectFile.project_id == project_id).order_by(ProjectFile.path))).scalars().all())
    current = {f.path: f for f in files}
    before = {p: f.content for p, f in current.items()}
    changed = 0
    for a in actions:
        path = a["path"]
        f = current.get(path)
        if a["op"] == "delete":
            if f:
                await db.delete(f); current.pop(path, None); changed += 1
        else:
            if f:
                if f.content != a["content"]:
                    f.content = a["content"]; f.updated_at = datetime.utcnow(); changed += 1
            else:
                db.add(ProjectFile(project_id=project_id, path=path, content=a["content"], language="text")); changed += 1
    revision_id = None
    if changed:
        rev = ProjectRevision(project_id=project_id, user_id=user_id, summary=summary[:300], snapshot=json.dumps(before, ensure_ascii=False), actions_json=json.dumps(actions, ensure_ascii=False))
        db.add(rev)
        await db.flush(); revision_id = rev.id
        await db.commit()
    return changed, revision_id


async def _repair(messages: list[dict[str, str]], failures: str, files: list[ProjectFile], research_text: str) -> list[dict[str, Any]]:
    ctx = context_pack(files, max_chars=180_000)
    prompt = f"""We ran real verification after an implementation and checks failed. Diagnose root cause and return only minimal corrective file edits. Do not rewrite unrelated code.\nFAILURES:\n{failures[:18000]}\nRESEARCH:\n{research_text[:10000]}\nPROJECT:\n{ctx}\nReturn ONLY JSON {{\"actions\":[{{\"op\":\"write\",\"path\":\"...\",\"content\":\"...\"}}],\"reason\":\"...\"}}."""
    r = await client().responses.create(model=settings.openai_text_model, input=messages + [{"role": "user", "content": prompt}], instructions="You are NexCode's repair engineer. Make minimal, correct, testable fixes.")
    text = getattr(r, "output_text", "") or ""
    m = re.search(r"\{[\s\S]*\}", text)
    if not m:
        return []
    try:
        return _safe_actions(json.loads(m.group(0)).get("actions", []))
    except Exception:
        return []


async def run_end_to_end(db: AsyncSession, user_id: int, project_id: int | None, messages: list[dict[str, str]], mode: str, web_mode: str) -> OrchestrationResult:
    message = messages[-1]["content"] if messages else ""
    statuses = {k: "pending" for k, _ in PIPELINE}
    task = TaskRun(user_id=user_id, project_id=project_id, request=message, status="running", pipeline_json=json.dumps(_pipeline(statuses), ensure_ascii=False))
    db.add(task); await db.flush(); await db.commit()

    async def update_task(status: str = "running", result_payload: dict[str, Any] | None = None):
        task.status = status
        task.pipeline_json = json.dumps(_pipeline(statuses), ensure_ascii=False)
        if result_payload is not None:
            task.result_json = json.dumps(result_payload, ensure_ascii=False, default=str)
        task.updated_at = datetime.utcnow()
        await db.commit()

    try:
        statuses["understand"] = "done"; statuses["plan"] = "running"; await update_task()
        if project_id:
            project = (await db.execute(select(__import__('app.db.models', fromlist=['Project']).Project).where(__import__('app.db.models', fromlist=['Project']).Project.id == project_id))).scalar_one_or_none()
            files = list((await db.execute(select(ProjectFile).where(ProjectFile.project_id == project_id).order_by(ProjectFile.path))).scalars().all())
            hits = search_files(files, message, limit=20)
            memory = (await db.execute(select(ProjectMemory).where(ProjectMemory.project_id == project_id))).scalar_one_or_none()
            memory_text = memory.memory_json[:16000] if memory else "{}"
            try:
                from app.services.memory_v2 import MemoryV2
                v2 = MemoryV2(json.loads(memory.memory_json).get("v2",{}).get("items",[]) if memory else [])
                recalled = v2.search(message, 8)
                if recalled: memory_text += "\n\nV8 MEMORY RECALL:\n" + json.dumps(recalled, ensure_ascii=False)
            except Exception:
                pass
            tree = build_tree(files)
            project_search = "\n".join(f"HIT: {h['path']} score={h['score']}\n{h['snippet']}" for h in hits)
            ctx = f"PROJECT MEMORY:\n{memory_text}\n\nTARGETED SEARCH:\n{project_search}\n\nPROJECT:\n{context_pack(files, max_chars=190_000)}"
            statuses["plan"] = "done"; statuses["project_search"] = "done"
        else:
            files = []; hits = []; tree = ""; ctx = ""; statuses["plan"] = "done"; statuses["project_search"] = "skipped"

        statuses["web_research"] = "running"; await update_task()
        web = await research(message, web_mode)
        statuses["web_research"] = "done"; statuses["impact"] = "running"; await update_task()
        if web.synthesis: ctx += f"\n\nWEB RESEARCH:\n{web.synthesis[:30000]}"

        analysts = {}
        if project_id and settings.parallel_agents_enabled:
            analysts = await run_parallel_analysts(message, ctx, web.synthesis)
            ctx += "\n\nPARALLEL ANALYSTS:\n" + json.dumps(analysts, ensure_ascii=False)[:24000]

        intelligence = analyze_project(files) if files else {"files": 0, "reverse_dependencies": {}, "symbols": []}
        from app.services.intelligence_v2 import analyze_project_v2
        intelligence_v2 = analyze_project_v2(files) if files else {"version":"2","files":0}
        ctx += "\n\nPROJECT INTELLIGENCE V2:\n" + json.dumps(intelligence_v2, ensure_ascii=False)[:30000]
        result = await execute_request(messages, mode, project_context=ctx, project_tree=tree)
        actions = _safe_actions(result.actions)
        impact = impact_analysis(files, [a["path"] for a in actions]) if files else {"changed": [a["path"] for a in actions], "impacted": [], "graph": intelligence}
        statuses["impact"] = "done"
        statuses["implement"] = "running" if actions else "skipped"
        await update_task()

        applied = 0; repair_cycles = 0; execution = None; revision_id = None; git = None; quality = None; status = "planned"; healing = {"attempts":0,"successful":0,"failed":0,"cycles":0,"replanned":0}; intelligence_v2 = intelligence_v2 if "intelligence_v2" in locals() else {"version":"2","files":len(files)}
        if project_id and actions and settings.auto_apply_actions:
            applied, revision_id = await _apply_actions(db, project_id, user_id, actions, "NexCode AI implementation")
            statuses["implement"] = "done"; statuses["review"] = "running"; status = "implemented"; await update_task()
            files = list((await db.execute(select(ProjectFile).where(ProjectFile.project_id == project_id).order_by(ProjectFile.path))).scalars().all())
            findings = review_code(files)
            quality = {"findings": findings, "pre_test": True}
            statuses["review"] = "done"; statuses["test"] = "running"; await update_task()
            healing_attempts = []
            last_failure_signature = None
            for cycle in range(settings.max_repair_cycles + 1):
                execution = validate_project(files)
                if execution.ok:
                    healing_attempts.append({"cycle":cycle,"ok":True,"action":"stop"})
                    statuses["test"] = "done"
                    statuses["repair"] = "done" if repair_cycles else "skipped"
                    statuses["retest"] = "done" if repair_cycles else "skipped"
                    status = "verified"
                    break
                failures = "\n".join(f"{c.name}: {c.output}" for c in execution.checks if not c.ok)
                signature = failures[:1000]
                repeated = signature == last_failure_signature
                last_failure_signature = signature
                decision = decide_repair(failed=True, changed_files=applied, cycles=cycle, max_cycles=settings.max_repair_cycles, repeated_failure=repeated)
                healing_attempts.append({"cycle":cycle,"ok":False,"action":decision.action,"reason":decision.reason,"confidence":decision.confidence})
                statuses["test"] = "failed"; statuses["repair"] = "running"; await update_task()
                if decision.action in {"stop", "replan", "diagnose"}:
                    if decision.action != "repair":
                        statuses["repair"] = decision.action; statuses["retest"] = "skipped"; status = "needs_review"; await update_task(); break
                if cycle >= settings.max_repair_cycles:
                    statuses["repair"] = "max_retries"; statuses["retest"] = "skipped"; status = "needs_review"; await update_task(); break
                repair_actions = await _repair(messages, failures, files, web.synthesis)
                if not repair_actions:
                    statuses["repair"] = "no_fix"; statuses["retest"] = "skipped"; status = "needs_review"; await update_task(); break
                more, rid = await _apply_actions(db, project_id, user_id, repair_actions, f"NexCode repair cycle {cycle+1}")
                applied += more; revision_id = rid or revision_id; repair_cycles += 1
                statuses["repair"] = "done"; statuses["retest"] = "running"; await update_task()
                files = list((await db.execute(select(ProjectFile).where(ProjectFile.project_id == project_id).order_by(ProjectFile.path))).scalars().all())
            healing = summarize_attempts(healing_attempts)
            if project_id:
                files = list((await db.execute(select(ProjectFile).where(ProjectFile.project_id == project_id).order_by(ProjectFile.path))).scalars().all())
                git = sync_project(project_id, files, "NexCode AI task", branch=f"nexcode/task-{task.id}")
            statuses["retest"] = statuses.get("retest", "skipped")
        else:
            if project_id and actions and not settings.auto_apply_actions:
                statuses["implement"] = "proposed"
            statuses["review"] = "done" if actions else "skipped"; statuses["test"] = "skipped"; statuses["repair"] = "skipped"; statuses["retest"] = "skipped"
            status = "proposed" if actions else "answered"

        statuses["deliver"] = "done"
        pipeline = _pipeline(statuses)
        out = OrchestrationResult(
            answer=result.answer, route=result.route, plan=result.plan, actions=actions, research=web,
            execution=execution, applied=applied, repair_cycles=repair_cycles, status=status,
            pipeline=pipeline, task_id=task.id, revision_id=revision_id, git=git, impact=impact,
            quality=quality, analysts=analysts, healing=healing, intelligence_v2=intelligence_v2,
        )
        if project_id:
            files = list((await db.execute(select(ProjectFile).where(ProjectFile.project_id == project_id).order_by(ProjectFile.path))).scalars().all())
            await _record_memory(db, project_id, files, out, message)
        await update_task(status, {
            "answer": result.answer, "route": result.route, "plan": result.plan, "actions": actions,
            "applied": applied, "repair_cycles": repair_cycles, "status": status, "pipeline": pipeline,
            "impact": impact, "git": git, "quality": quality, "parallel_agents": analysts,
            "healing": healing, "intelligence_v2": intelligence_v2,
            "execution": ({"ok": execution.ok, "summary": execution.summary, "checks": [c.__dict__ for c in execution.checks]} if execution else None),
            "research": {"depth": web.depth, "queries": web.queries, "sources": [s.__dict__ for s in web.sources]},
        })
        return out
    except Exception as exc:
        statuses["deliver"] = "failed"
        await update_task("failed", {"error": str(exc), "pipeline": _pipeline(statuses)})
        raise
