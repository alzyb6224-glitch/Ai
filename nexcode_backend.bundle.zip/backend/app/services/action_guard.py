from __future__ import annotations
from typing import Any
from app.core.config import settings

PROTECTED = {'.env','.git','id_rsa','id_ed25519','credentials.json','secrets.json'}

def safe_actions(actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out=[]
    for a in actions[:50]:
        if a.get('op') not in {'write','delete'}: continue
        path=str(a.get('path','')).strip().replace('\\','/')
        parts=[x for x in path.split('/') if x]
        if not path or path.startswith('/') or '..' in parts or len(path)>1000: continue
        if parts and (parts[0] in PROTECTED or path.startswith('.git/') or path.startswith('.env')): continue
        if a['op']=='write':
            if not isinstance(a.get('content'),str) or len(a['content'])>settings.max_file_chars: continue
            out.append({'op':'write','path':path,'content':a['content']})
        else: out.append({'op':'delete','path':path})
    return out
