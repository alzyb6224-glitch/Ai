from __future__ import annotations
import json, subprocess, tempfile, shutil
from pathlib import Path, PurePosixPath
from urllib.request import Request, urlopen
from urllib.parse import urlparse
from app.core.config import settings


def _github_url(url: str) -> str:
    p=urlparse(url)
    if p.scheme not in {'https'} or p.hostname not in {'github.com','www.github.com'}:
        raise ValueError('Only https://github.com repositories are supported.')
    return url.rstrip('/')

def import_public_repo(repo_url: str, max_files: int=800) -> list[dict]:
    repo_url=_github_url(repo_url)
    with tempfile.TemporaryDirectory(prefix='nexcode-github-') as td:
        root=Path(td)
        r=subprocess.run(['git','clone','--depth','1',repo_url,str(root/'repo')],capture_output=True,text=True,timeout=90)
        if r.returncode != 0: raise RuntimeError((r.stdout+r.stderr).strip()[-4000:])
        repo=root/'repo'
        out=[]
        for p in repo.rglob('*'):
            if len(out)>=max_files: break
            if not p.is_file() or p.is_symlink() or '.git' in p.parts: continue
            rel=PurePosixPath(p.relative_to(repo).as_posix())
            if '..' in rel.parts or len(str(rel))>1000: continue
            if p.stat().st_size>2_000_000: continue
            try: text=p.read_text(encoding='utf-8')
            except Exception: continue
            out.append({'path':str(rel),'content':text})
        return out

def create_pull_request(owner_repo: str, title: str, head: str, base: str, body: str='') -> dict:
    token=settings.github_token
    if not token: raise RuntimeError('GITHUB_TOKEN is not configured on the server.')
    p=urlparse('https://api.github.com/repos/'+owner_repo+'/pulls')
    if p.hostname!='api.github.com': raise ValueError('Invalid GitHub API endpoint')
    payload=json.dumps({'title':title,'head':head,'base':base,'body':body}).encode()
    req=Request(p.geturl(),data=payload,headers={'Authorization':f'Bearer {token}','Accept':'application/vnd.github+json','Content-Type':'application/json'},method='POST')
    with urlopen(req,timeout=30) as r:
        return json.loads(r.read().decode())


def _repo_https(owner_repo: str) -> str:
    if not owner_repo or owner_repo.count('/') != 1:
        raise ValueError('owner_repo must be in owner/repository format.')
    owner, repo = owner_repo.split('/')
    if not owner or not repo or any(c.isspace() for c in owner_repo):
        raise ValueError('Invalid GitHub repository identifier.')
    return f'https://github.com/{owner}/{repo}.git'


def push_branch(project_id: int, owner_repo: str, branch: str) -> dict:
    """Push a local NexCode project branch without exposing the token in git arguments."""
    token = settings.github_token
    if not token:
        raise RuntimeError('GITHUB_TOKEN is not configured on the server.')
    from app.services.git_intel import _repo, _git
    repo = _repo(project_id)
    if not (repo/'.git').exists():
        raise RuntimeError('Project Git repository is not initialized. Prepare GitHub first.')
    remote = _repo_https(owner_repo)
    askpass = repo / '.nexcode-askpass'
    askpass.write_text('#!/bin/sh\ncase "$1" in\n  *Username*) printf "%s\n" x-access-token ;;\n  *) printf "%s\n" "$NEXCODE_GITHUB_TOKEN" ;;\nesac\n', encoding='utf-8')
    askpass.chmod(0o700)
    import os
    env = dict(os.environ)
    env['GIT_ASKPASS'] = str(askpass)
    env['GIT_TERMINAL_PROMPT'] = '0'
    env['NEXCODE_GITHUB_TOKEN'] = token
    try:
        # Token is supplied via GIT_ASKPASS, not a command-line argument.
        add = subprocess.run(['git','-C',str(repo),'remote','get-url','origin'],capture_output=True,text=True)
        if add.returncode != 0:
            subprocess.run(['git','-C',str(repo),'remote','add','origin',remote],capture_output=True,text=True,check=True)
        else:
            subprocess.run(['git','-C',str(repo),'remote','set-url','origin',remote],capture_output=True,text=True,check=True)
        r = subprocess.run(['git','-C',str(repo),'push','-u','origin',branch],capture_output=True,text=True,timeout=90,env=env)
        return {'ok':r.returncode==0,'branch':branch,'owner_repo':owner_repo,'output':(r.stdout+'\n'+r.stderr).strip()[-8000:]}
    finally:
        try: askpass.unlink()
        except OSError: pass
