from __future__ import annotations
import os, shutil, subprocess
from typing import Any
class DeploymentEngineV9:
    TARGETS={'docker','vercel','render','railway','github-pages'}
    def status(self):
        return {'targets':{t:shutil.which(t) is not None for t in self.TARGETS},'docker_available':shutil.which('docker') is not None,'github_token':bool(os.getenv('GITHUB_TOKEN'))}
    def plan(self,target:str,project_id:int)->dict[str,Any]:
        if target not in self.TARGETS: raise ValueError('Unsupported deploy target')
        return {'target':target,'project_id':project_id,'approval_required':True,'steps':['preflight','build','healthcheck','publish'],'rollback':'available_at_revision_boundary'}
    def run_local(self,command:list[str],cwd:str,approved:bool=False)->dict[str,Any]:
        if not approved: return {'ok':False,'status':'approval_required'}
        r=subprocess.run(command,cwd=cwd,capture_output=True,text=True,timeout=180)
        return {'ok':r.returncode==0,'status':'executed','stdout':r.stdout[-8000:],'stderr':r.stderr[-8000:],'returncode':r.returncode}
