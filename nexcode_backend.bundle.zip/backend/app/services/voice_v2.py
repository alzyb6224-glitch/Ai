from __future__ import annotations
from typing import Any

def provider_status() -> dict[str,Any]:
    # Provider-neutral until a server-side speech provider is configured.
    import os
    return {"stt":bool(os.getenv("NEXCODE_STT_PROVIDER_KEY")),"tts":bool(os.getenv("NEXCODE_TTS_PROVIDER_KEY")),"mode":"provider" if os.getenv("NEXCODE_STT_PROVIDER_KEY") else "interface_ready"}

def command_intent(transcript: str) -> dict[str,Any]:
    t=transcript.strip()
    return {"transcript":t,"intent":"developer_command" if t else "empty","confidence":0.9 if t else 0.0}
