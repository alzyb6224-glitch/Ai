from __future__ import annotations
import base64
from app.services.ai import client
from app.core.config import settings

async def analyze_screenshot(image_bytes: bytes, mime_type: str, prompt: str = "Diagnose this software screenshot and connect visible errors to likely code causes. Give concrete next debugging steps.") -> str:
    if len(image_bytes) > 12_000_000:
        raise ValueError("Image is too large")
    encoded=base64.b64encode(image_bytes).decode("ascii")
    data_url=f"data:{mime_type};base64,{encoded}"
    response=await client().responses.create(
        model=settings.openai_text_model,
        input=[{"role":"user","content":[{"type":"input_text","text":prompt},{"type":"input_image","image_url":data_url}]}],
        instructions="You are NexCode Visual Debugger. Analyze UI/error screenshots carefully. Distinguish visible facts from hypotheses. Do not claim to have seen project code unless it is supplied separately.",
    )
    return getattr(response, "output_text", "") or "Could not analyze the screenshot."
