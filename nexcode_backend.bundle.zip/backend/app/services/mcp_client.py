from __future__ import annotations
import json, subprocess, threading
from dataclasses import dataclass
from typing import Any

@dataclass
class MCPTool:
    name: str
    description: str = ""
    input_schema: dict[str, Any] | None = None

class MCPError(RuntimeError):
    pass

class MCPStdioClient:
    """Minimal MCP JSON-RPC bridge with a strict local allowlist.
    It is intentionally provider-neutral; the app controls which server command may run.
    """
    def __init__(self, command: list[str], allowed_tools: set[str] | None = None, cwd: str | None = None):
        if not command:
            raise ValueError("MCP command cannot be empty")
        self.command = command
        self.allowed_tools = allowed_tools or set()
        self.cwd = cwd
        self.proc: subprocess.Popen[str] | None = None
        self._next_id = 0
        self._lock = threading.Lock()

    def start(self) -> None:
        if self.proc and self.proc.poll() is None:
            return
        self.proc = subprocess.Popen(self.command, cwd=self.cwd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)

    def stop(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
        self.proc = None

    def request(self, method: str, params: dict[str, Any] | None = None, timeout: float = 15) -> dict[str, Any]:
        self.start()
        assert self.proc and self.proc.stdin and self.proc.stdout
        with self._lock:
            self._next_id += 1
            rid = self._next_id
            payload = {"jsonrpc": "2.0", "id": rid, "method": method, "params": params or {}}
            self.proc.stdin.write(json.dumps(payload) + "\n")
            self.proc.stdin.flush()
            # stdio MCP implementations commonly emit one JSON response per line.
            import time
            deadline = time.time() + timeout
            while time.time() < deadline:
                line = self.proc.stdout.readline()
                if not line:
                    break
                msg = json.loads(line)
                if msg.get("id") == rid:
                    if "error" in msg:
                        raise MCPError(str(msg["error"]))
                    return msg.get("result", {})
            raise MCPError("MCP request timed out or ended without a response")

    def initialize(self, client_name: str = "NexCode AI", version: str = "8.0") -> dict[str, Any]:
        return self.request("initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": client_name, "version": version}})

    def list_tools(self) -> list[MCPTool]:
        data = self.request("tools/list")
        return [MCPTool(x.get("name", ""), x.get("description", ""), x.get("inputSchema")) for x in data.get("tools", [])]

    def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> dict[str, Any]:
        if self.allowed_tools and name not in self.allowed_tools:
            raise MCPError(f"Tool '{name}' is not allowed by NexCode policy")
        return self.request("tools/call", {"name": name, "arguments": arguments or {}})
