from __future__ import annotations
import shutil
from pathlib import Path
from app.core.config import settings


def health() -> dict:
    docker = shutil.which('docker')
    mode = settings.execution_mode
    return {
        'configured_mode': mode,
        'docker_available': bool(docker),
        'docker_binary': docker or '',
        'safe_static_available': True,
        'network_policy': settings.sandbox_network if settings.sandbox_network in {'none','bridge'} else 'none',
        'read_only_root': True,
        'capabilities_dropped': 'ALL',
        'no_new_privileges': True,
        'memory_limit': settings.sandbox_memory,
        'cpu_limit': settings.sandbox_cpus,
        'pids_limit': 128,
        'timeout_seconds': settings.sandbox_timeout_seconds,
        'status': 'ready' if mode == 'safe_static' or docker else 'blocked',
        'reason': '' if mode == 'safe_static' or docker else 'Docker mode selected but Docker is unavailable on this host.',
    }


def validate_policy() -> dict:
    h = health()
    return {
        'ok': bool(h['safe_static_available'] and h['network_policy'] in {'none','bridge'} and h['read_only_root'] and h['capabilities_dropped']=='ALL' and h['no_new_privileges'] and h['pids_limit'] <= 128),
        'checks': [
            {'name':'safe_static_fallback','ok':h['safe_static_available']},
            {'name':'network_policy','ok':h['network_policy']=='none'},
            {'name':'read_only_root','ok':h['read_only_root']},
            {'name':'cap_drop_all','ok':h['capabilities_dropped']=='ALL'},
            {'name':'no_new_privileges','ok':h['no_new_privileges']},
            {'name':'pids_limit','ok':h['pids_limit'] <= 128},
        ],
    }
