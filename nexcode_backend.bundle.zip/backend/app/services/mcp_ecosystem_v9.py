from __future__ import annotations
from dataclasses import dataclass,asdict
from typing import Any
import json
from urllib.request import Request,urlopen
@dataclass
class MCPServer: name:str; transport:str; endpoint:str; enabled:bool=True; allowed_tools:tuple[str,...]=()
class MCPEcosystem:
    def __init__(self): self.servers={}; self.tool_catalog={}
    def register(self,s:MCPServer):
        if s.transport not in {'stdio','http','streamable_http'}: raise ValueError('Unsupported MCP transport')
        self.servers[s.name]=s
    def disable(self,name:str): self.servers[name].enabled=False
    def allow(self,server:str,tool:str)->bool:
        s=self.servers.get(server); return bool(s and s.enabled and (not s.allowed_tools or tool in s.allowed_tools))
    def register_tools(self,server:str,tools:list[dict[str,Any]]):
        if server not in self.servers: raise KeyError(server)
        s=self.servers[server]
        for t in tools:
            n=str(t.get('name',''))
            if n and (not s.allowed_tools or n in s.allowed_tools): self.tool_catalog[f'{server}:{n}']=dict(t)
    def catalog(self): return {'servers':[asdict(s) for s in self.servers.values()],'tools':self.tool_catalog}
    def call_http(self,server:str,tool:str,args:dict[str,Any]):
        s=self.servers.get(server)
        if not s or s.transport not in {'http','streamable_http'}: raise ValueError('HTTP MCP server not configured')
        if not self.allow(server,tool): raise PermissionError('MCP tool denied by policy')
        body=json.dumps({'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':tool,'arguments':args}}).encode(); req=Request(s.endpoint,data=body,headers={'Content-Type':'application/json'},method='POST')
        with urlopen(req,timeout=30) as r: return json.loads(r.read().decode())
