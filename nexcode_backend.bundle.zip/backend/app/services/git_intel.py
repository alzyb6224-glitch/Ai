from __future__ import annotations
import shutil, subprocess
from pathlib import Path, PurePosixPath
from typing import Iterable
from app.core.config import settings
from app.db.models import ProjectFile

def _safe_path(path: str) -> bool:
    p=PurePosixPath(path); return not p.is_absolute() and ".." not in p.parts and len(path)<=1000 and not str(path).startswith('.env')

def _repo(project_id:int)->Path:
    root=Path(settings.git_root).resolve(); root.mkdir(parents=True,exist_ok=True); return root/f"project-{project_id}"

def _git(repo:Path,args:list[str],timeout:int=30)->str:
    r=subprocess.run(["git","-C",str(repo),*args],capture_output=True,text=True,timeout=timeout)
    return (r.stdout+"\n"+r.stderr).strip()[-20000:]

def sync_project(project_id:int,files:Iterable[ProjectFile],message:str="NexCode update",branch:str|None=None)->dict:
    if not settings.git_enabled or shutil.which('git') is None: return {'enabled':False,'message':'Git is unavailable or disabled.'}
    repo=_repo(project_id); repo.mkdir(parents=True,exist_ok=True)
    if not (repo/'.git').exists():
        _git(repo,['init','-q']); _git(repo,['config','user.email','nexcode@local']); _git(repo,['config','user.name','NexCode AI'])
    clean=''.join(ch if ch.isalnum() or ch in '-_/' else '-' for ch in (branch or 'nexcode/task'))[:80] or 'nexcode/task'
    has_head=bool(_git(repo,['rev-parse','--verify','HEAD']).strip())
    if has_head:
        existing=_git(repo,['branch','--list',clean]).strip()
        if existing: _git(repo,['switch','-q',clean])
        else: _git(repo,['switch','-q','-c',clean])
    for p in list(repo.iterdir()):
        if p.name=='.git': continue
        shutil.rmtree(p) if p.is_dir() else p.unlink()
    for f in files:
        if not _safe_path(f.path): continue
        dst=repo.joinpath(*PurePosixPath(f.path).parts); dst.parent.mkdir(parents=True,exist_ok=True); dst.write_text(f.content,encoding='utf-8')
    _git(repo,['add','-A']); changed=_git(repo,['status','--porcelain'])
    if changed: _git(repo,['commit','-m',message[:120],'--allow-empty'])
    commit=_git(repo,['rev-parse','--short','HEAD']).strip() if has_head or changed else ''
    return {'enabled':True,'repo':str(repo),'branch':clean,'changed':bool(changed),'status':changed,'commit':commit}

def diff(project_id:int)->str:
    repo=_repo(project_id)
    if not (repo/'.git').exists(): return 'Git history is not initialized yet.'
    raw=_git(repo,['diff','HEAD~1..HEAD','--'])
    return raw or _git(repo,['show','--stat','--oneline','HEAD'])

def history(project_id:int,limit:int=20)->list[str]:
    repo=_repo(project_id)
    if not (repo/'.git').exists(): return []
    raw=_git(repo,['log',f'-n{max(1,min(limit,50))}','--pretty=format:%h|%ad|%s','--date=iso'])
    return [x for x in raw.splitlines() if x]
