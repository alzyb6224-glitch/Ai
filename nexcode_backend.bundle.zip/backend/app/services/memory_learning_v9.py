from __future__ import annotations
from dataclasses import dataclass
import time
@dataclass
class MemoryEvent: key:str; value:str; feedback:str=''; confidence:float=.5; ts:float=0
class MemoryLearningLoop:
    def __init__(self): self.events=[]
    def observe(self,key,value,feedback='',confidence=.5): self.events.append(MemoryEvent(key,value,feedback,max(0,min(confidence,1)),time.time()))
    def learn(self):
        grouped={}
        for e in self.events:
            bonus=.2 if e.feedback.lower() in {'positive','accepted','correct'} else (-.2 if e.feedback.lower() in {'negative','rejected','wrong'} else 0)
            grouped[e.key]={'value':e.value,'confidence':max(0,min(1,e.confidence+bonus)),'evidence':grouped.get(e.key,{}).get('evidence',0)+1}
        return grouped
    def recall(self,key): return self.learn().get(key)
