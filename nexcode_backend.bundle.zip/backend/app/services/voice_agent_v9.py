class VoiceAgentV9:
    def status(self):
        try: import speech_recognition; stt=True
        except Exception: stt=False
        return {'stt_available':stt,'tts_provider':'adapter','streaming':False,'provider_neutral':True}
    def intent(self,transcript):
        t=transcript.lower().strip()
        if not t: return {'intent':'empty'}
        if any(x in t for x in ('deploy','publish','نشر')): return {'intent':'deploy','text':transcript}
        if any(x in t for x in ('test','اختبر')): return {'intent':'test','text':transcript}
        return {'intent':'developer_command','text':transcript}
