from __future__ import annotations
from dataclasses import dataclass,asdict
import time
@dataclass
class Presence: user_id:int; name:str; online:bool=True; last_seen:float=0
class RealtimeRoom:
    def __init__(self,room_id): self.room_id=room_id; self.presence={}; self.events=[]
    def join(self,user_id,name): self.presence[user_id]=Presence(user_id,name,True,time.time()); self.events.append({'type':'join','user_id':user_id,'ts':time.time()}); return self.snapshot()
    def leave(self,user_id):
        if user_id in self.presence: self.presence[user_id].online=False; self.events.append({'type':'leave','user_id':user_id,'ts':time.time()})
    def op(self,user_id,operation): self.events.append({'type':'operation','user_id':user_id,'operation':operation,'ts':time.time()}); return len(self.events)
    def snapshot(self): return {'room_id':self.room_id,'presence':[asdict(p) for p in self.presence.values()],'events':len(self.events)}
