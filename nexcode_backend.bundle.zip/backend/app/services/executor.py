from __future__ import annotations
import json, os, shutil, subprocess, tempfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any
from app.core.config import settings
from app.db.models import ProjectFile

@dataclass
class CheckResult:
    name: str
    ok: bool
    output: str = ""
    duration_ms: int = 0
    mode: str = "static"

@dataclass
class ExecutionResult:
    ok: bool
    checks: list[CheckResult] = field(default_factory=list)
    summary: str = ""
    mode: str = "safe_static"


def _write_tree(root: Path, files: list[ProjectFile]) -> None:
    for f in files:
        rel = PurePosixPath(f.path)
        if rel.is_absolute() or ".." in rel.parts: continue
        p = root.joinpath(*rel.parts)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(f.content, encoding="utf-8")


def _run_local(cmd: list[str], cwd: Path, timeout: int = 20, mode: str = "static") -> CheckResult:
    import time
    started = time.monotonic()
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        out = (r.stdout + "\n" + r.stderr).strip()[-16000:]
        return CheckResult(" ".join(cmd), r.returncode == 0, out, int((time.monotonic()-started)*1000), mode)
    except FileNotFoundError:
        return CheckResult(" ".join(cmd), False, "Tool is not installed in the execution environment.", int((time.monotonic()-started)*1000), mode)
    except subprocess.TimeoutExpired:
        return CheckResult(" ".join(cmd), False, "Timed out.", int((time.monotonic()-started)*1000), mode)
    except Exception as exc:
        return CheckResult(" ".join(cmd), False, str(exc), int((time.monotonic()-started)*1000), mode)


def _ecosystem_commands(root: Path, files: list[ProjectFile], *, include_build: bool, include_install: bool) -> list[list[str]]:
    paths = {f.path for f in files}
    cmds: list[list[str]] = []
    if any(p.endswith(".py") for p in paths):
        cmds.append(["python", "-m", "compileall", "-q", "."])
        if any("test" in p.lower() and p.endswith(".py") for p in paths) or "pyproject.toml" in paths or "pytest.ini" in paths:
            cmds.append(["pytest", "-q"])
    if "package.json" in paths or any(p.endswith((".js", ".ts", ".tsx", ".jsx")) for p in paths):
        for f in files:
            if f.path.endswith((".js", ".jsx")) and not f.path.endswith(".min.js"):
                cmds.append(["node", "--check", f.path])
                if len(cmds) >= 15: break
        if include_install and "package.json" in paths:
            cmds.insert(0, ["npm", "install", "--ignore-scripts"])
        if include_build and "package.json" in paths:
            cmds.append(["npm", "test", "--", "--runInBand"])
    if "pubspec.yaml" in paths or any(p.endswith(".dart") for p in paths):
        if include_install: cmds.append(["flutter", "pub", "get"])
        cmds.append(["flutter", "test", "--no-pub"])
        if include_build: cmds.append(["flutter", "build", "apk", "--debug"])
    if "go.mod" in paths:
        cmds.append(["go", "test", "./..."])
        if include_build: cmds.append(["go", "build", "./..."])
    if "Cargo.toml" in paths:
        cmds.append(["cargo", "test", "--offline"])
        if include_build: cmds.append(["cargo", "build", "--offline"])
    return cmds


def _sandbox_image(cmd: list[str]) -> str:
    if cmd and cmd[0] == "npm": return getattr(settings, "sandbox_node_image", "node:22-bookworm-slim")
    if cmd and cmd[0] == "flutter": return getattr(settings, "sandbox_flutter_image", "ghcr.io/cirruslabs/flutter:stable")
    if cmd and cmd[0] == "go": return getattr(settings, "sandbox_go_image", "golang:1.25-bookworm")
    if cmd and cmd[0] == "cargo": return getattr(settings, "sandbox_rust_image", "rust:1.90-slim")
    return settings.sandbox_python_image

def _run_docker(root: Path, cmd: list[str]) -> CheckResult:
    if shutil.which("docker") is None:
        return CheckResult("docker " + " ".join(cmd), False, "Docker is not installed on the backend host.", mode="docker")
    network = settings.sandbox_network if settings.sandbox_network in {"none", "bridge"} else "none"
    image = _sandbox_image(cmd)
    docker_cmd = [
        "docker", "run", "--rm", "--read-only",
        "--network", network,
        "--cpus", settings.sandbox_cpus,
        "--memory", settings.sandbox_memory,
        "--pids-limit", "128",
        "--cap-drop", "ALL",
        "--security-opt", "no-new-privileges",
        "--tmpfs", "/tmp:rw,nosuid,nodev,noexec,size=128m",
        "-v", f"{root}:/workspace:rw",
        "-w", "/workspace",
        image,
        *cmd,
    ]
    return _run_local(docker_cmd, Path("/"), settings.sandbox_timeout_seconds, "docker")


def validate_project(files: list[ProjectFile], *, include_build: bool | None = None, include_install: bool | None = None) -> ExecutionResult:
    """Safe verification. Arbitrary commands supplied by users are never executed here."""
    include_build = settings.auto_run_builds if include_build is None else include_build
    include_install = settings.auto_dependency_install if include_install is None else include_install
    checks: list[CheckResult] = []
    with tempfile.TemporaryDirectory(prefix="nexcode-check-") as td:
        root = Path(td)
        _write_tree(root, files)
        cmds = _ecosystem_commands(root, files, include_build=include_build, include_install=include_install)
        for cmd in cmds[:30]:
            # Static checks stay local because they don't execute project-controlled scripts.
            unsafe = cmd[0] in {"pytest", "npm", "flutter", "go", "cargo"}
            if unsafe and settings.execution_mode == "docker":
                checks.append(_run_docker(root, cmd))
            elif unsafe:
                checks.append(CheckResult("SKIPPED: " + " ".join(cmd), True, "Project command execution is disabled in safe_static mode; enable Docker sandbox to run it.", mode="skipped"))
            else:
                checks.append(_run_local(cmd, root, 20, "static"))
        for f in files:
            if f.path.endswith(".json"):
                try:
                    json.loads(f.content); checks.append(CheckResult(f"json:{f.path}", True, "Valid JSON"))
                except Exception as exc:
                    checks.append(CheckResult(f"json:{f.path}", False, str(exc)))
    ok = all(c.ok for c in checks) if checks else True
    failed = [c.name for c in checks if not c.ok]
    summary = "All configured checks passed." if ok else "Failed checks: " + ", ".join(failed)
    return ExecutionResult(ok, checks, summary, settings.execution_mode)


def available_profiles(files: list[ProjectFile]) -> dict[str, Any]:
    paths = {f.path for f in files}
    return {
        "python": any(p.endswith('.py') for p in paths),
        "node": 'package.json' in paths or any(p.endswith(('.js','.ts','.tsx','.jsx')) for p in paths),
        "flutter": 'pubspec.yaml' in paths or any(p.endswith('.dart') for p in paths),
        "go": 'go.mod' in paths,
        "rust": 'Cargo.toml' in paths,
        "build_enabled": settings.auto_run_builds,
        "dependency_install_enabled": settings.auto_dependency_install,
        "execution_mode": settings.execution_mode,
    }
