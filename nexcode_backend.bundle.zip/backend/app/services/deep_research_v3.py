from __future__ import annotations
import asyncio
from dataclasses import dataclass,asdict
from typing import Any,Callable,Awaitable
@dataclass
class ResearchAgentResult: agent:str; query:str; findings:str; urls:list[str]
@dataclass
class ResearchV3: question:str; agents:list[ResearchAgentResult]; synthesis:str; gaps:list[str]
async def multi_agent_research(question:str,searcher:Callable[[str],Awaitable[dict[str,Any]]]|None=None,questions:list[str]|None=None)->ResearchV3:
    qs=questions or [f'official documentation and facts about {question}',f'independent evidence and pitfalls for {question}',f'current alternatives and trade-offs for {question}']
    async def one(i,q):
        if not searcher: return ResearchAgentResult(f'agent-{i+1}',q,'searcher_not_configured',[])
        r=await searcher(q); return ResearchAgentResult(f'agent-{i+1}',q,str(r.get('text','')),list(r.get('urls',[])))
    agents=list(await asyncio.gather(*(one(i,q) for i,q in enumerate(qs))))
    synthesis='\n\n'.join(f'[{a.agent}] {a.query}\n{a.findings[:8000]}' for a in agents)
    gaps=['External source search is unavailable.'] if all(not a.urls for a in agents) else []
    return ResearchV3(question,agents,synthesis,gaps)
