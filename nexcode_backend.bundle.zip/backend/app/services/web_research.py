from __future__ import annotations
import asyncio, json, re
from dataclasses import dataclass
from typing import Any
from app.services.ai import client
from app.core.config import settings

@dataclass
class WebSource:
    query: str
    text: str
    urls: list[str]

@dataclass
class ResearchResult:
    enabled: bool
    depth: str
    queries: list[str]
    sources: list[WebSource]
    synthesis: str
    gaps: list[str] | None = None


def should_search(message: str, explicit: str = "auto") -> bool:
    if explicit in {"fast", "deep"}: return True
    if explicit == "off": return False
    triggers = ["search","web","internet","browse","latest","today","documentation","docs","source","ابحث","بحث","الانترنت","الويب","المصادر","آخر","احدث","أحدث","توثيق","مراجع","معلومات حديثة"]
    m = message.lower()
    return any(t in m for t in triggers)


def _parse_queries(text: str, fallback: str, depth: str) -> list[str]:
    try:
        arr = json.loads(text)
        if isinstance(arr, list):
            out=[str(x).strip() for x in arr if str(x).strip()]
            if out: return out[: (10 if depth == 'deep' else 4)]
    except Exception: pass
    match=re.search(r"\[[\s\S]*?\]", text)
    if match:
        try:
            arr=json.loads(match.group(0)); out=[str(x).strip() for x in arr if str(x).strip()]
            if out: return out[: (10 if depth == 'deep' else 4)]
        except Exception: pass
    return [fallback]


async def _make_queries(message: str, depth: str) -> list[str]:
    count = 9 if depth == "deep" else 4
    prompt=f"Create {count} focused web-search queries for the user's request. Cover primary/official docs, current facts, implementation details, alternatives, pitfalls and verification where relevant. Return only JSON array.\nREQUEST: {message}"
    r=await client().responses.create(model=settings.openai_text_model,input=prompt,instructions="You are a research query planner. Return valid JSON only.")
    return _parse_queries(getattr(r,'output_text','') or '', message, depth)


async def _search_one(query: str) -> WebSource:
    try:
        r=await client().responses.create(model=settings.openai_text_model,input=query,tools=[{"type":"web_search"}],instructions="Search current web sources. Prefer primary/official sources. Summarize useful evidence and preserve source names and URLs if exposed. Never invent a URL.")
        text=getattr(r,'output_text','') or ''
        urls=sorted(set(re.findall(r'https?://[^\s)\]]+', text)))[:20]
        return WebSource(query,text,urls)
    except Exception as exc:
        return WebSource(query,f"Web search unavailable: {exc}",[])


async def _synthesize(message: str, sources: list[WebSource], depth: str) -> str:
    bundle='\n\n'.join(f"QUERY: {s.query}\nURLS: {s.urls}\nRESULT:\n{s.text[:16000]}" for s in sources)
    prompt=f"""You are NexCode Research Lead. Build a trustworthy research brief for this request: {message}\n\nResearch depth: {depth}\n\n{bundle}\n\nRequirements:\n- Separate verified facts, strong evidence, and uncertainty.\n- Prefer primary sources and mention conflicts.\n- Preserve useful URLs exactly as supplied.\n- State what still needs verification.\n- End with a compact Sources section mapping important claims to URLs/source names."""
    r=await client().responses.create(model=settings.openai_text_model,input=prompt,instructions="Do not invent citations, URLs, dates or claims.")
    return getattr(r,'output_text','') or bundle[:30000]


async def research(message: str, explicit: str = "auto") -> ResearchResult:
    enabled=should_search(message,explicit)
    if not enabled: return ResearchResult(False,"off",[],[],"",[])
    m=message.lower()
    depth='deep' if explicit=='deep' or any(x in m for x in ['deep research','بحث عميق','بحث معمق','بحث معمّق','تحقيق شامل']) else 'fast'
    queries=await _make_queries(message,depth)
    sources=await asyncio.gather(*(_search_one(q) for q in queries))
    synthesis=await _synthesize(message,list(sources),depth)
    gaps=[]
    if 'needs verification' in synthesis.lower() or 'uncertain' in synthesis.lower(): gaps.append('Some claims need additional verification.')
    return ResearchResult(True,depth,queries,list(sources),synthesis,gaps)
