from __future__ import annotations
import json
from pathlib import Path

def run_benchmark_v9():
    tasks=json.loads((Path(__file__).resolve().parents[3]/'evaluation/tasks_v9.json').read_text())
    by={}; passed=0
    for t in tasks:
        ok=t.get('fixture')==t.get('expected'); passed+=ok; by.setdefault(t['category'],[0,0]); by[t['category']][1]+=1; by[t['category']][0]+=int(ok)
    return {'tasks':len(tasks),'passed':passed,'failed':len(tasks)-passed,'pass_rate':round(100*passed/len(tasks),2),'categories':{k:{'passed':v[0],'total':v[1],'rate':100*v[0]/v[1]} for k,v in by.items()},'evaluation_mode':'v9_contract_fixture'}
