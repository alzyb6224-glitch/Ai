from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any
import math, re

@dataclass
class MemoryItem:
    key: str
    value: str
    scope: str = "project"
    confidence: float = 0.7
    source: str = "agent"
    updated_at: str = ""
    hits: int = 0

class MemoryV2:
    def __init__(self, items: list[dict[str, Any]] | None = None):
        self.items = [MemoryItem(**{**x, "updated_at": x.get("updated_at") or self._now()}) for x in (items or [])]
    def _now(self): return datetime.now(timezone.utc).isoformat()
    def upsert(self, key: str, value: str, scope: str = "project", confidence: float = 0.7, source: str = "agent"):
        confidence = max(0.0, min(1.0, float(confidence)))
        for i in self.items:
            if i.key == key and i.scope == scope:
                i.value, i.confidence, i.source, i.updated_at = value, confidence, source, self._now(); return
        self.items.append(MemoryItem(key, value, scope, confidence, source, self._now(), 0))
    def search(self, query: str, limit: int = 8) -> list[dict[str, Any]]:
        q = set(re.findall(r"\w+", query.lower()))
        scored=[]
        for item in self.items:
            words=set(re.findall(r"\w+", (item.key+" "+item.value).lower()))
            overlap=len(q & words)
            recency=1/(1+max(0, (datetime.now(timezone.utc)-datetime.fromisoformat(item.updated_at)).days))
            score=overlap*2 + item.confidence + recency + math.log1p(item.hits)*0.1
            if overlap: scored.append((score,item))
        scored.sort(key=lambda x:x[0], reverse=True)
        out=[]
        for score,item in scored[:limit]:
            item.hits += 1
            d=asdict(item); d["score"]=round(score,3); out.append(d)
        return out
    def to_dict(self): return {"version":2,"items":[asdict(i) for i in self.items]}
