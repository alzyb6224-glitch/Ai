from __future__ import annotations
import asyncio, uuid, time
from dataclasses import dataclass, asdict
from typing import Any, Awaitable, Callable

@dataclass
class Job:
    id: str
    name: str
    status: str = "queued"
    created_at: float = 0.0
    result: Any = None
    error: str = ""

class JobManagerV2:
    def __init__(self): self.jobs: dict[str,Job]={}; self._tasks: dict[str,asyncio.Task]={}
    def submit(self,name:str,fn:Callable[[], Awaitable[Any]])->Job:
        jid=uuid.uuid4().hex[:12]; job=Job(jid,name,created_at=time.time()); self.jobs[jid]=job
        async def runner():
            job.status="running"
            try:
                job.result=await fn(); job.status="done"
            except asyncio.CancelledError:
                job.status="cancelled"
                raise
            except Exception as e:
                job.error=str(e); job.status="failed"
        self._tasks[jid]=asyncio.create_task(runner()); return job
    def get(self,jid:str)->dict[str,Any]:
        job=self.jobs.get(jid)
        if not job: raise KeyError(jid)
        return asdict(job)
    def cancel(self,jid:str)->dict[str,Any]:
        job=self.jobs.get(jid)
        if not job: raise KeyError(jid)
        task=self._tasks.get(jid)
        if task is None or task.done():
            return asdict(job)
        task.cancel()
        job.status="cancelled"
        return asdict(job)

jobs_v2=JobManagerV2()
