from __future__ import annotations
import shutil, os
from typing import Any

def status() -> dict[str,Any]:
    return {
        'git': bool(shutil.which('git')),
        'docker': bool(shutil.which('docker')),
        'playwright_python': _has('playwright'),
        'openai_key': bool(os.getenv('OPENAI_API_KEY')),
        'github_token': bool(os.getenv('GITHUB_TOKEN')),
        'anthropic_key': bool(os.getenv('ANTHROPIC_API_KEY')),
        'mode': 'live-ready' if (shutil.which('docker') and os.getenv('OPENAI_API_KEY')) else 'local-verified',
    }
def _has(name:str)->bool:
    try: __import__(name); return True
    except Exception: return False
