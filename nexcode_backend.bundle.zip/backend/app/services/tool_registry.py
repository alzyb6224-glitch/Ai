from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable

@dataclass
class ToolSpec:
    name: str
    description: str
    category: str
    enabled: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)

class ToolRegistry:
    def __init__(self): self._tools: dict[str, ToolSpec] = {}
    def register(self, spec: ToolSpec): self._tools[spec.name]=spec
    def list(self): return [t.__dict__ for t in self._tools.values() if t.enabled]
    def get(self, name: str): return self._tools.get(name)

registry=ToolRegistry()
for spec in [
    ToolSpec('project_search','Search repository files by relevance','project'),
    ToolSpec('code_intelligence','Build import/symbol/dependency relationships','project'),
    ToolSpec('web_search','Search current web sources','research'),
    ToolSpec('deep_research','Plan, search, compare and synthesize multiple web queries','research'),
    ToolSpec('terminal','Run approved commands in an isolated sandbox','execution'),
    ToolSpec('tests','Run ecosystem verification profiles','execution'),
    ToolSpec('git','Diff, branch, commit and rollback','version_control'),
    ToolSpec('github','Import repositories and prepare GitHub changes','integration'),
    ToolSpec('visual_debug','Analyze UI/error screenshots','vision'),
    ToolSpec('memory','Read and update project memory','context'),
]: registry.register(spec)
