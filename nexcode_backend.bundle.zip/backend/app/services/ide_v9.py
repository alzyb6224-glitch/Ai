from __future__ import annotations
from dataclasses import dataclass,asdict
import difflib
@dataclass
class EditorFile: path:str; content:str; cursor:int=0
class IDEV9:
    def __init__(self): self.files={}; self.active=''
    def open(self,path,content): self.files[path]=EditorFile(path,content); self.active=path; return asdict(self.files[path])
    def edit(self,path,new_content):
        old=self.files.get(path,EditorFile(path,'')).content; diff=''.join(difflib.unified_diff(old.splitlines(True),new_content.splitlines(True),fromfile=path,tofile=path)); self.files[path]=EditorFile(path,new_content); return {'path':path,'diff':diff,'lines':len(new_content.splitlines())}
    def tree(self): return sorted(self.files)
    def snapshot(self): return {'active':self.active,'files':[asdict(f) for f in self.files.values()]}
