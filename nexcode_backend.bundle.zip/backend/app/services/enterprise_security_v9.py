from __future__ import annotations
import hashlib,hmac,re,time
from dataclasses import dataclass,asdict
SECRET_RE=re.compile(r'(sk-[A-Za-z0-9_-]{10,}|gh[pousr]_[A-Za-z0-9_]{10,}|Bearer\s+[A-Za-z0-9._-]{12,})')
ROLES={'owner':{'read','write','review','deploy','admin'},'admin':{'read','write','review','deploy','admin'},'developer':{'read','write','review'},'reviewer':{'read','review'},'viewer':{'read'}}
@dataclass
class AuditEvent: ts:float; actor:int; action:str; resource:str; outcome:str
class SecurityEngine:
    def __init__(self,project_secret='nexcode-v9'): self.events=[]; self.members={}; self.project_secret=project_secret.encode()
    def grant(self,user_id:int,project_id:int,role:str):
        if role not in ROLES: raise ValueError('invalid role')
        self.members[(user_id,project_id)]=role
    def allowed(self,user_id:int,project_id:int,action:str)->bool: return action in ROLES[self.members.get((user_id,project_id),'viewer')]
    def audit(self,actor:int,action:str,resource:str,outcome:str): self.events.append(asdict(AuditEvent(time.time(),actor,action,resource,outcome)))
    def redact(self,text:str)->str: return SECRET_RE.sub('[REDACTED]',text)
    def sign(self,payload:str)->str: return hmac.new(self.project_secret,payload.encode(),hashlib.sha256).hexdigest()
    def verify(self,payload:str,signature:str)->bool: return hmac.compare_digest(self.sign(payload),signature)
    def policy_report(self): return {'rbac':True,'audit_log':len(self.events),'secret_redaction':True,'signed_events':True,'roles':sorted(ROLES)}
