from __future__ import annotations
from collections import Counter
from typing import Any

class Trace:
    def __init__(self, trace_id:str): self.trace_id=trace_id; self.events=[]
    def add(self,stage:str,status:str,**meta:Any): self.events.append({"stage":stage,"status":status,**meta})
    def finish(self):
        return {"trace_id":self.trace_id,"events":self.events,"stage_count":len(self.events),"failed":sum(1 for e in self.events if e["status"]=="failed"),"stages":dict(Counter(e["stage"] for e in self.events))}
