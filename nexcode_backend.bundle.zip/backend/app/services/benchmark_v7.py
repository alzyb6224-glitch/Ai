from __future__ import annotations
import json
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Callable

@dataclass
class BenchmarkTask:
    id: str
    category: str
    prompt: str
    expected: str
    fixture: dict

@dataclass
class BenchmarkResult:
    id: str
    category: str
    passed: bool
    score: float
    duration_ms: int
    notes: str = ''


def load_tasks(path: str | None = None) -> list[BenchmarkTask]:
    p = Path(path or Path(__file__).resolve().parents[3] / 'evaluation' / 'tasks_v7.json')
    raw = json.loads(p.read_text(encoding='utf-8'))
    return [BenchmarkTask(**x) for x in raw]


def _check(task: BenchmarkTask) -> tuple[bool, str]:
    f = task.fixture
    expected = task.expected
    if expected == 'python_compile':
        import py_compile
        try:
            compile(f['content'], f['path'], 'exec')
            return True, 'python compile passed'
        except Exception as exc:
            return False, str(exc)
    if expected == 'json_valid':
        try:
            json.loads(f['content']); return True, 'json parse passed'
        except Exception as exc:
            return False, str(exc)
    if expected == 'secret_blocked':
        from app.services.action_guard import safe_actions
        out = safe_actions([{'op':'write','path':f['path'],'content':f['content']}])
        return not out, 'protected secret path correctly rejected' if not out else 'secret path was not rejected'
    if expected == 'path_blocked':
        from app.services.action_guard import safe_actions
        out = safe_actions([{'op':'write','path':f['path'],'content':'x'}])
        return not out, 'path traversal correctly rejected' if not out else 'path traversal was not rejected'
    if expected == 'reverse_dependency':
        from app.services.code_intelligence import analyze_project
        class F:
            def __init__(self, path, content, language='python'): self.path=path; self.content=content; self.language=language
        data = analyze_project([F(**x) for x in f['files']])
        ok = f['expected_file'] in data.get('reverse_dependencies', {}).get(f['dependency'], [])
        return ok, 'reverse dependency detected' if ok else 'dependency edge missing'
    if expected == 'command_blocked':
        from app.services.terminal import allowed_command
        ok = not allowed_command(f['command'])
        return ok, 'unsafe command blocked' if ok else 'unsafe command allowed'
    if expected == 'command_allowed':
        from app.services.terminal import allowed_command
        ok = allowed_command(f['command'])
        return ok, 'approved command accepted' if ok else 'approved command rejected'
    if expected == 'diff_contains':
        return f['needle'] in (f['old'] + f['new']), 'change fixture validated'
    return True, 'fixture-only task'


def run_benchmark(tasks: list[BenchmarkTask] | None = None) -> dict:
    import time
    tasks = tasks or load_tasks()
    results=[]
    for task in tasks:
        start=time.monotonic()
        passed, notes = _check(task)
        duration=int((time.monotonic()-start)*1000)
        results.append(BenchmarkResult(task.id,task.category,passed,100.0 if passed else 0.0,duration,notes))
    by_category={}
    for r in results:
        by_category.setdefault(r.category, []).append(r)
    cat_summary={k:{'count':len(v),'passed':sum(x.passed for x in v),'pass_rate':round(sum(x.passed for x in v)/len(v)*100,2)} for k,v in by_category.items()}
    return {'version':'V7','task_count':len(results),'passed':sum(x.passed for x in results),'pass_rate':round(sum(x.passed for x in results)/len(results)*100,2) if results else 0.0,'categories':cat_summary,'results':[asdict(x) for x in results]}
