from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import secrets, time

@dataclass
class ShareLink:
    token:str
    project_id:int
    role:str
    expires_at:float

class CollaborationV2:
    def __init__(self): self.links:dict[str,ShareLink]={}
    def create_link(self,project_id:int,role:str="viewer",ttl_seconds:int=86400)->dict[str,Any]:
        if role not in {"viewer","editor"}: raise ValueError("role must be viewer or editor")
        link=ShareLink(secrets.token_urlsafe(18),project_id,role,time.time()+max(60,min(ttl_seconds,30*86400)))
        self.links[link.token]=link; return asdict(link)
    def resolve(self,token:str)->dict[str,Any]:
        link=self.links.get(token)
        if not link or link.expires_at<time.time(): raise KeyError("share link expired or missing")
        return asdict(link)

collaboration_v2=CollaborationV2()
