from __future__ import annotations
from typing import Any
import shutil
from app.services.production_readiness_v9 import status as production_status
from app.services.quality import generate_quality_report
from app.services.package_dependency_agent_v9 import PackageDependencyAgentV9
from app.services.agent_core_v11 import scrub_secrets


def project_preflight(files: list[Any]) -> dict[str, Any]:
    quality = generate_quality_report(files, run_build=False, install=False)
    try:
        file_map = {getattr(f, "path", ""): getattr(f, "content", "") for f in files}
        deps = PackageDependencyAgentV9().analyze(file_map)
    except Exception as exc:
        deps = {"error": scrub_secrets(str(exc))}
    paths = {getattr(f, "path", "") for f in files}
    platform = {
        "flutter": "pubspec.yaml" in paths or any(p.endswith(".dart") for p in paths),
        "python": "requirements.txt" in paths or "pyproject.toml" in paths,
        "node": "package.json" in paths,
        "android_project": any(p.startswith("android/") for p in paths),
    }
    readiness = production_status()
    readiness["flutter_cli"] = bool(shutil.which("flutter"))
    readiness["android_sdk"] = bool(shutil.which("adb") or shutil.which("sdkmanager"))
    blockers: list[str] = []
    if quality.score < 70:
        blockers.append("quality_below_70")
    if quality.security < 70:
        blockers.append("security_below_70")
    if not readiness["flutter_cli"] and platform["flutter"]:
        blockers.append("local_flutter_runtime_unavailable")
    return {
        "ok": not blockers,
        "blockers": blockers,
        "quality": {"score": quality.score, "tests": quality.tests, "security": quality.security, "dependencies": quality.dependencies},
        "dependencies": deps,
        "platform_detected": platform,
        "runtime": readiness,
        "recommended_next_step": "run_agent_task" if not blockers else "resolve_blockers",
    }
