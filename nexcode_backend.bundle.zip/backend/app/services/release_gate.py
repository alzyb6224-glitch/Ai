from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any

@dataclass
class GateResult:
    ready: bool
    score: float
    blockers: list[str]
    warnings: list[str]
    checks: dict[str, bool]


def evaluate(*, tests_ok: bool, quality_score: float | None = None, security_ok: bool = True,
             unresolved_repairs: int = 0, git_ready: bool = True, external_credentials_ok: bool = True) -> dict[str, Any]:
    blockers=[]; warnings=[]
    checks={
      'tests': bool(tests_ok), 'security': bool(security_ok), 'git': bool(git_ready),
      'credentials': bool(external_credentials_ok), 'repairs_bounded': unresolved_repairs <= 0,
    }
    if not tests_ok: blockers.append('Tests are not green.')
    if not security_ok: blockers.append('Security gate failed.')
    if not git_ready: blockers.append('Git delivery is not ready.')
    if not external_credentials_ok: warnings.append('External provider credentials are not configured.')
    if unresolved_repairs > 0: blockers.append(f'{unresolved_repairs} unresolved repair item(s).')
    if quality_score is None: warnings.append('Quality score is unavailable.')
    elif quality_score < 80: blockers.append(f'Quality score {quality_score:.1f}% is below the 80% release floor.')
    score=100.0
    score -= 35 if not tests_ok else 0
    score -= 25 if not security_ok else 0
    score -= 15 if not git_ready else 0
    score -= min(15, unresolved_repairs*5)
    if quality_score is not None: score -= max(0, 80-quality_score)*0.5
    return asdict(GateResult(not blockers, round(max(0,score),2), blockers, warnings, checks))
