from __future__ import annotations
from typing import Any
from urllib.request import Request, urlopen
from urllib.parse import urlparse

class ComputerUseV9:
    def __init__(self, allowed_domains: set[str] | None = None, timeout: int = 15):
        self.allowed_domains = allowed_domains or set(); self.timeout = timeout

    def _check(self, url: str) -> None:
        p = urlparse(url)
        if p.scheme not in {'http','https'} or not p.hostname: raise ValueError('Invalid URL')
        if self.allowed_domains and p.hostname not in self.allowed_domains and not any(p.hostname.endswith('.'+d) for d in self.allowed_domains):
            raise PermissionError('Domain blocked by policy')

    def open_url(self, url: str) -> dict[str, Any]:
        self._check(url)
        req = Request(url, headers={'User-Agent':'NexCodeAI/9.0'})
        with urlopen(req, timeout=self.timeout) as r:
            body = r.read(200_000)
            return {'ok': True, 'url': r.geturl(), 'status': getattr(r,'status',200), 'content_type': r.headers.get('content-type',''), 'bytes': len(body), 'text_preview': body.decode('utf-8','replace')[:4000]}

    def execute(self, action: dict[str, Any]) -> dict[str, Any]:
        kind=action.get('kind')
        if kind == 'open_url': return self.open_url(str(action.get('target','')))
        if kind in {'click','type','press','screenshot','scroll','wait'}:
            return {'ok': False, 'status':'driver_required', 'action':kind, 'detail':'Install/configure Playwright for live UI actions.'}
        return {'ok':False,'status':'unsupported_action'}
