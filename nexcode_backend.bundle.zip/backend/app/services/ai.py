from openai import AsyncOpenAI
from app.core.config import settings

SYSTEM_PROMPT = """You are NexCode AI, an elite general-purpose and software engineering assistant.
You operate as one intelligent assistant and choose the best internal strategy for every request.

Priorities:
1. Correctness and actually satisfying the user's requested outcome.
2. Deep understanding of context, constraints, existing code, and dependencies.
3. Complete, implementation-ready results.
4. Security, reliability, maintainability, performance, and clear UX.

For engineering work: think like a senior architect, developer, debugger, tester, reviewer, and technical writer. Do not claim work happened unless the product actually performed it.
For projects: reason across files rather than treating each file in isolation.
For general requests: answer naturally and adapt to the user's language and level.
"""
_client = None

def client() -> AsyncOpenAI:
    global _client
    if _client is None:
        if not settings.openai_api_key:
            raise RuntimeError("OPENAI_API_KEY is not configured")
        _client = AsyncOpenAI(api_key=settings.openai_api_key, base_url=settings.openai_base_url)
    return _client

async def chat(messages: list[dict[str, str]], mode: str = "auto", project_context: str = "") -> str:
    extra = f"\nPROJECT CONTEXT:\n{project_context}" if project_context else ""
    mode_hint = {
        "auto": "Choose the best approach automatically.",
        "code": "Prioritize implementation and engineering correctness.",
        "reasoning": "Prioritize careful analysis and trade-offs.",
        "writer": "Prioritize polished writing and clarity.",
    }.get(mode, "Choose the best approach automatically.")
    from app.services.model_router_v9 import route as route_model
    routed = route_model(messages[-1]["content"] if messages else "", len(str(messages)), 999.0)
    logical = routed["selected"]["name"]
    model_name = {"reasoning": getattr(settings, "openai_reasoning_model", settings.openai_text_model), "coding": getattr(settings, "openai_coding_model", settings.openai_text_model), "fast": getattr(settings, "openai_fast_model", settings.openai_text_model)}.get(logical, settings.openai_text_model)
    response = await client().responses.create(
        model=model_name,
        instructions=SYSTEM_PROMPT + extra + f"\nMODE: {mode}. {mode_hint}",
        input=messages,
    )
    return getattr(response, "output_text", "") or "I could not produce a response."

async def generate_image(prompt: str, size: str = "1024x1024", quality: str = "high") -> str:
    result = await client().images.generate(model=settings.openai_image_model, prompt=prompt, size=size, quality=quality)
    item = result.data[0]
    b64 = getattr(item, "b64_json", None)
    if not b64:
        raise RuntimeError("Image provider returned no base64 image data")
    return b64
