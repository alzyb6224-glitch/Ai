from __future__ import annotations
import subprocess,tempfile,shutil
from pathlib import Path
from dataclasses import dataclass
@dataclass
class SWETask: id:str; repo:str; issue:str; base_commit:str=''
@dataclass
class SWEResult: task_id:str; status:str; tests_ok:bool; output:str=''; mode:str='real_harness'
class SWEBenchHarness:
    def __init__(self,timeout:int=180): self.timeout=timeout
    def validate_task(self,t:dict):
        req={'id','repo','issue'}; return {'ok':req.issubset(t),'missing':sorted(req-set(t))}
    def run_command(self,cmd:list[str],cwd:str):
        r=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True,timeout=self.timeout); return {'ok':r.returncode==0,'stdout':r.stdout[-10000:],'stderr':r.stderr[-10000:],'returncode':r.returncode}
    def prepare_repo(self,repo_url:str)->str:
        if not repo_url.startswith('https://github.com/'): raise ValueError('Only GitHub HTTPS repos are allowed.')
        td=tempfile.mkdtemp(prefix='nexcode-swe-'); dst=str(Path(td)/'repo'); r=subprocess.run(['git','clone','--depth','1',repo_url,dst],capture_output=True,text=True,timeout=self.timeout)
        if r.returncode!=0: shutil.rmtree(td,ignore_errors=True); raise RuntimeError((r.stdout+r.stderr).strip()[-4000:])
        return dst
def score(results:list[SWEResult]):
    return {'tasks':len(results),'resolved':sum(x.tests_ok for x in results),'pass_rate':round(100*sum(x.tests_ok for x in results)/len(results),2) if results else 0,'mode':'real_harness'}
