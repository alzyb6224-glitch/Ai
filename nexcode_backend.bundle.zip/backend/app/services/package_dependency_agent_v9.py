from __future__ import annotations
import json,re
class PackageDependencyAgentV9:
    def analyze(self,files):
        deps={}
        for path,content in files.items():
            if path.endswith('requirements.txt'):
                deps[path]=[x.split('==')[0].strip() for x in re.findall(r'^([A-Za-z0-9_.-]+(?:==[^\n]+)?)',content,re.M)]
            elif path.endswith('package.json'):
                try: deps[path]=sorted(json.loads(content).get('dependencies',{}))
                except Exception: deps[path]=[]
            elif path.endswith('pubspec.yaml'):
                deps[path]=re.findall(r'^  ([A-Za-z0-9_]+):',content,re.M)
        return {'manifests':deps,'total':sum(len(v) for v in deps.values())}
    def update_plan(self,current:str,latest:str): return {'from':current,'to':latest,'requires_tests':True,'breaking_change_check':True}
