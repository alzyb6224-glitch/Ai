from __future__ import annotations
from pathlib import Path
from typing import Iterable
from app.services.executor import _run_docker, _run_local, _write_tree
from app.core.config import settings
from app.db.models import ProjectFile
import tempfile


def allowed_command(cmd: list[str]) -> bool:
    if not cmd or any(len(str(x)) > 300 for x in cmd):
        return False
    exe=cmd[0]
    if exe=='python':
        return cmd[1:5] in [ ['-m','compileall','-q','.'], ['-m','pytest','-q'] ]
    if exe=='pytest':
        return cmd[1:] in ([], ['-q'])
    if exe=='node':
        return len(cmd)==3 and cmd[1]=='--check' and not cmd[2].startswith(('/', '..'))
    if exe=='npm':
        safe={('test',),('run','build'),('ci',)}
        return tuple(cmd[1:]) in safe or (cmd[1:2]==['install'] and settings.auto_dependency_install)
    if exe=='flutter':
        safe={('analyze',),('test','--no-pub'),('pub','get'),('build','apk','--debug')}
        return tuple(cmd[1:]) in safe and (cmd[1:2]!=['pub'] or settings.auto_dependency_install)
    if exe=='go': return cmd[1:] in (['test','./...'],['build','./...'])
    if exe=='cargo': return cmd[1:] in (['test','--offline'],['build','--offline'])
    if exe=='git': return cmd[1:2] in (['status'],['log'],['diff']) and all(x not in {'-c','--upload-pack'} for x in cmd)
    if exe in {'ls','find'}: return True
    return False


def run_command(files: Iterable[ProjectFile], cmd: list[str]):
    if not allowed_command(cmd): raise ValueError('Command is not allowed by NexCode sandbox policy')
    with tempfile.TemporaryDirectory(prefix='nexcode-terminal-') as td:
        root=Path(td); _write_tree(root,list(files))
        if settings.execution_mode!='docker':
            from app.services.executor import CheckResult
            return CheckResult(' '.join(cmd), True, 'Command not executed because safe_static mode forbids project code execution. Enable Docker sandbox on the server.', 0, 'skipped')
        return _run_docker(root,cmd)
