from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import os

@dataclass(frozen=True)
class ModelProfile:
    name: str; provider: str; strengths: tuple[str,...]; cost_per_million: float; latency_ms: int; context: int; enabled: bool=True

DEFAULT_MODELS=(
    ModelProfile('reasoning','openai',('reasoning','architecture','debugging','research'),10.0,1800,256000),
    ModelProfile('coding','openai',('code','implementation','refactor','tests'),7.0,1200,256000),
    ModelProfile('fast','openai',('chat','simple','routing','summarize'),2.0,500,128000),
    ModelProfile('local','local',('private','offline','simple'),0.0,200,32768,False),
)
KEYWORDS={'reasoning':('architect','architecture','debug','root cause','trade-off','reason','design','حل','تصميم','تحليل'),'code':('code','implement','fix','refactor','test','build','backend','frontend','flutter','python','typescript','dart','برمج','كود','اصلح'),'research':('research','latest','docs','compare','source','بحث','توثيق','مصادر'),'simple':('hello','hi','summarize','translate','مرحبا','ترجم','لخص')}

def _score(p:ModelProfile,task:str,size:int,budget:float)->float:
    text=task.lower(); score=0.0
    for s in p.strengths:
        score += 1.8*sum(k in text for k in KEYWORDS.get(s,()))
    score += 1.5 if size<=p.context else -50
    score += .5 if budget>=p.cost_per_million else -2
    score += max(0,1-p.latency_ms/3000)
    return score

def route(task:str,input_tokens:int=0,budget_usd:float=999.0,models=DEFAULT_MODELS)->dict[str,Any]:
    ranked=sorted([m for m in models if m.enabled],key=lambda m:_score(m,task,input_tokens,budget_usd),reverse=True)
    if not ranked or _score(ranked[0],task,input_tokens,budget_usd)<=-10: raise RuntimeError('No model can satisfy request/context/budget.')
    return {'selected':asdict(ranked[0]),'candidates':[{'name':m.name,'score':round(_score(m,task,input_tokens,budget_usd),3)} for m in ranked],'strategy':'capability+context+budget+latency'}

def provider_ready(provider:str)->bool:
    return bool({'openai':os.getenv('OPENAI_API_KEY',''),'anthropic':os.getenv('ANTHROPIC_API_KEY',''),'local':'1'}.get(provider,''))

def status()->dict[str,Any]: return {'version':'V9','router':'operational','providers':{p:provider_ready(p) for p in ('openai','anthropic','local')},'models':[asdict(m) for m in DEFAULT_MODELS]}
