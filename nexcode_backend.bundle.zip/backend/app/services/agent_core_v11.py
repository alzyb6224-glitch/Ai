from __future__ import annotations
import json, re, time, uuid
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Any, Callable

from app.core.config import settings
from app.db.models import ProjectFile
from app.services.model_router_v9 import route as route_model
from app.services.project import context_pack, search_files, build_tree, summarize
from app.services.code_intelligence import analyze_project
from app.services.quality import review_code


AGENTS = (
    ("lead", "Lead Agent", "orchestration, delegation, completion"),
    ("architect", "Architect", "architecture and technical design"),
    ("coder", "Coder", "implementation and edits"),
    ("debugger", "Debugger", "root-cause analysis and repair"),
    ("researcher", "Researcher", "documentation and evidence"),
    ("reviewer", "Reviewer", "code quality and regressions"),
    ("security", "Security", "security and secret detection"),
    ("tester", "Tester", "tests and verification"),
    ("dependency", "Dependency", "dependencies and package hygiene"),
    ("mobile", "Mobile", "Android/iOS/Flutter"),
    ("devops", "DevOps", "build, release and deployment"),
)

RISKY_TOOLS = {"shell", "deploy", "publish", "network_write", "secret_access", "delete_project"}


@dataclass
class AgentEvent:
    id: str
    task_id: str
    agent: str
    kind: str
    status: str
    message: str
    started_at: float
    finished_at: float | None = None
    duration_ms: int = 0
    metadata: dict[str, Any] | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AgentPlan:
    intent: str
    objective: str
    route: dict[str, Any]
    selected_agents: list[str]
    steps: list[str]
    risks: list[str]
    approvals_required: list[str]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AgentCoreResult:
    task_id: str
    status: str
    answer: str
    plan: AgentPlan
    events: list[dict[str, Any]]
    context: dict[str, Any]
    quality: dict[str, Any]
    actions: list[dict[str, Any]]
    execution: dict[str, Any] | None
    checkpoints: list[dict[str, Any]]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class AgentEventLog:
    def __init__(self, task_id: str):
        self.task_id = task_id
        self.events: list[AgentEvent] = []

    def emit(self, agent: str, kind: str, status: str, message: str, metadata: dict[str, Any] | None = None, started_at: float | None = None) -> AgentEvent:
        started = time.time() if started_at is None else started_at
        event = AgentEvent(uuid.uuid4().hex[:12], self.task_id, agent, kind, status, message, started, metadata=metadata)
        self.events.append(event)
        return event

    def done(self, event: AgentEvent, status: str = "done", message: str | None = None) -> AgentEvent:
        event.status = status
        if message is not None:
            event.message = message
        event.finished_at = time.time()
        event.duration_ms = int((event.finished_at - event.started_at) * 1000)
        return event

    def snapshot(self) -> list[dict[str, Any]]:
        return [e.as_dict() for e in self.events]


def _classify(task: str) -> str:
    t = task.lower()
    if any(x in t for x in ("deploy", "release", "publish", "نشر", "اطلق")):
        return "release"
    if any(x in t for x in ("flutter", "android", "ios", "apk", "mobile")):
        return "mobile"
    if any(x in t for x in ("bug", "error", "exception", "fix", "debug", "خطأ", "اصلح")):
        return "debug"
    if any(x in t for x in ("test", "pytest", "unit", "integration", "اختبار")):
        return "test"
    if any(x in t for x in ("research", "docs", "latest", "compare", "بحث", "توثيق")):
        return "research"
    if any(x in t for x in ("database", "supabase", "sql", "mongodb")):
        return "backend"
    if any(x in t for x in ("architecture", "design", "system", "معمارية", "تصميم")):
        return "architecture"
    if any(x in t for x in ("code", "implement", "build", "create", "refactor", "كود", "برمج", "انشئ", "تعديل")):
        return "coding"
    return "general"


def _agents_for(intent: str, has_project: bool) -> list[str]:
    base = ["lead", "architect", "coder", "reviewer", "tester"] if has_project else ["lead", "researcher"]
    extras = {
        "debug": ["debugger", "security"],
        "test": ["tester", "debugger"],
        "research": ["researcher", "reviewer"],
        "release": ["devops", "security", "tester"],
        "mobile": ["mobile", "dependency", "tester"],
        "backend": ["dependency", "security", "tester"],
        "architecture": ["architect", "security", "devops"],
        "coding": ["dependency", "security"],
        "general": ["researcher"],
    }.get(intent, [])
    out = []
    for x in base + extras:
        if x not in out:
            out.append(x)
    return out[:9]


def _risk_flags(task: str, actions: list[dict[str, Any]] | None = None) -> list[str]:
    t = task.lower()
    risks = []
    if any(x in t for x in ("deploy", "publish", "delete", "remove all", "نشر", "حذف كامل")):
        risks.append("state-changing external action")
    if any(x in t for x in ("secret", "password", "token", "api key", "مفتاح", "كلمة مرور")):
        risks.append("secret material")
    if actions and any(a.get("op") == "delete" for a in actions):
        risks.append("file deletion")
    return risks


def _approvals(risks: list[str]) -> list[str]:
    return ["human_approval"] if risks else []


def _selected_context(files: list[ProjectFile], task: str, max_files: int = 80) -> dict[str, Any]:
    hits = search_files(files, task, limit=min(max_files, 40)) if files else []
    paths = [h["path"] for h in hits]
    # Always include common manifests and entrypoints for reliable planning.
    for common in ("README.md", "pyproject.toml", "requirements.txt", "package.json", "pubspec.yaml", "main.py", "app/lib/main.dart"):
        if any(f.path == common for f in files) and common not in paths:
            paths.append(common)
    pathset = set(paths)
    chosen = [f for f in files if f.path in pathset]
    if len(chosen) < min(12, len(files)):
        chosen = files[: min(12, len(files))]
    return {
        "files_total": len(files),
        "files_selected": len(chosen),
        "paths": [f.path for f in chosen[:max_files]],
        "summary": summarize(chosen),
        "tree": build_tree(chosen)[:24000],
        "context_chars": len(context_pack(chosen, max_chars=120000)),
        "search_hits": hits[:20],
    }


class NexCodeAgentCoreV11:
    """Central manager that coordinates intent, context, agent roles, tools and verification."""

    def plan(self, task: str, files: list[ProjectFile] | None = None, budget_usd: float = 999.0) -> AgentPlan:
        files = files or []
        intent = _classify(task)
        route = route_model(task, 0, budget_usd)
        selected = _agents_for(intent, bool(files))
        steps = [
            "understand_intent",
            "retrieve_minimal_context",
            "delegate_specialists",
            "implement_or_answer",
            "review_and_security",
            "verify",
            "repair_if_needed",
            "finalize_artifacts",
        ]
        risks = _risk_flags(task)
        return AgentPlan(intent, task[:1000], route, selected, steps, risks, _approvals(risks))

    def context(self, task: str, files: list[ProjectFile]) -> dict[str, Any]:
        pack = _selected_context(files, task)
        intel = analyze_project(files) if files else {"files": 0}
        return {"selection": pack, "intelligence": intel}

    def specialist_report(self, role: str, task: str, files: list[ProjectFile], ctx: dict[str, Any]) -> dict[str, Any]:
        if role == "security":
            return {"role": role, "findings": review_code(files), "focus": "secrets/risky primitives"}
        if role == "reviewer":
            findings = review_code(files)
            return {"role": role, "finding_count": len(findings), "findings": findings[:50], "focus": "quality/regression"}
        if role == "dependency":
            paths = [f.path for f in files]
            return {"role": role, "manifests": [p for p in paths if p in {"requirements.txt", "pyproject.toml", "package.json", "pubspec.yaml", "go.mod", "Cargo.toml"}]}
        if role == "tester":
            return {"role": role, "verification_plan": ["syntax", "manifest", "ecosystem_tests", "build_when_enabled"]}
        if role == "mobile":
            return {"role": role, "targets": ["android", "ios"], "flutter_detected": any(f.path == "pubspec.yaml" or f.path.endswith(".dart") for f in files)}
        if role == "devops":
            return {"role": role, "release_checks": ["tests", "security", "artifact_hash", "approval"]}
        if role == "debugger":
            return {"role": role, "method": "stack-trace -> root-cause -> minimal-fix -> regression"}
        if role == "researcher":
            return {"role": role, "method": "multi-source research with evidence before implementation"}
        return {"role": role, "method": "structured planning and task delegation"}

    def summarize_answer(self, task: str, plan: AgentPlan, quality: dict[str, Any], execution: dict[str, Any] | None, changed: int) -> str:
        if plan.intent in {"coding", "debug", "mobile", "backend", "architecture"}:
            state = "completed" if not execution or execution.get("ok", True) else "completed_with_failures"
            return f"NexCode {state}: coordinated {len(plan.selected_agents)} agents, changed {changed} file(s), and ran the configured verification stage."
        return f"NexCode analyzed the request using the {plan.route['selected']['name']} route and {len(plan.selected_agents)} specialist role(s)."


def scrub_secrets(text: str) -> str:
    patterns = [
        (r"(?i)(api[_-]?key|secret|password|token)\s*[:=]\s*(['\"]).*?\2", r"\1=***REDACTED***"),
        (r"(?i)bearer\s+[A-Za-z0-9._-]{12,}", "Bearer ***REDACTED***"),
    ]
    out = text
    for p, repl in patterns:
        out = re.sub(p, repl, out)
    return out
