from __future__ import annotations
import json, re
from dataclasses import dataclass
from typing import Any
from app.services.ai import client
from app.core.config import settings

@dataclass
class AgentResult:
    answer: str
    plan: list[dict[str, Any]]
    actions: list[dict[str, Any]]
    route: str

ROUTING = {
    "build": "software architect + senior engineer",
    "debug": "debugger + root-cause analyst",
    "review": "senior code reviewer + security reviewer",
    "analyze": "software architect + repository analyst",
    "write": "expert technical writer",
    "image": "creative director",
    "general": "expert general assistant",
}


def _route(message: str, mode: str) -> str:
    if mode != "auto":
        return {"code":"build","reasoning":"analyze","writer":"write"}.get(mode, "general")
    m = message.lower()
    if any(x in m for x in ["debug", "error", "exception", "traceback", "خطأ", "مشكلة"]): return "debug"
    if any(x in m for x in ["review", "راجع", "security", "أمان"]): return "review"
    if any(x in m for x in ["build", "create", "make", "develop", "ابني", "اصنع", "سوي", "انشئ"]): return "build"
    if any(x in m for x in ["analyze", "architecture", "حلل", "حلّل", "تحليل"]): return "analyze"
    if any(x in m for x in ["write", "rewrite", "اكتب", "صياغة"]): return "write"
    return "general"


def _extract_json(text: str) -> dict[str, Any]:
    # Accept plain JSON or a fenced JSON object; fall back safely.
    blocks = re.findall(r"```json\s*(\{.*?\})\s*```", text, flags=re.S|re.I)
    candidates = blocks or re.findall(r"(\{\s*\"plan\".*\})", text, flags=re.S)
    for raw in candidates:
        try:
            data = json.loads(raw)
            if isinstance(data, dict): return data
        except Exception:
            pass
    return {"plan": [], "actions": []}

async def execute_request(messages: list[dict[str, str]], mode: str, project_context: str = "", project_tree: str = "") -> AgentResult:
    route = _route(messages[-1]["content"] if messages else "", mode)
    role = ROUTING[route]
    instructions = f"""
You are NexCode AI, a single elite software/product assistant. Act like a real senior engineer who owns the result end-to-end.
Current route: {route} ({role}).

Core behavior:
- Understand the user's full goal, constraints, existing code, and expected outcome before acting.
- For software tasks, prefer production-oriented architecture, complete implementation, clear file paths, and integration details.
- When a repository is provided, reason across files, dependencies, entry points, configuration, data flow, and likely failure points.
- Do not pretend to have executed code, tests, network requests, or deployments. State what was actually performed by the application.
- When a request is underspecified but can be safely completed with sensible defaults, make those defaults and state them.
- When critical information is genuinely missing, ask one focused question rather than many.
- Consider security, reliability, maintainability, performance, accessibility, and cost.
- For code, never silently omit critical files or integration steps.

Return two layers:
1) A polished human-readable answer with the actual solution.
2) At the END, emit a machine block exactly like this when file changes are useful:
```json
{{"plan":[{{"step":"...","reason":"..."}}],"actions":[{{"op":"write","path":"path/to/file","content":"..."}}]}}
```
Actions are proposals only; they must be reviewed/applied by the product. Use `op` values: write, delete. Keep actions minimal and complete. If no file changes are useful, use empty arrays.

PROJECT TREE:
{project_tree or '(none)'}
PROJECT CONTEXT:
{project_context or '(none)'}
"""
    response = await client().responses.create(
        model=settings.openai_text_model,
        instructions=instructions,
        input=messages,
    )
    text = getattr(response, "output_text", "") or "I could not produce a response."
    meta = _extract_json(text)
    # Remove machine block from user-facing answer.
    clean = re.sub(r"\n```json\s*\{\"plan\".*?\}\s*```\s*$", "", text, flags=re.S|re.I).strip()
    return AgentResult(answer=clean, plan=meta.get("plan", []), actions=meta.get("actions", []), route=route)
