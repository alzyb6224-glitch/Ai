from __future__ import annotations
import hashlib,re
from dataclasses import dataclass,asdict
@dataclass
class Artifact: id:str; kind:str; title:str; content:str; sha256:str
class ArtifactEngine:
    def __init__(self): self.items={}
    def create(self,title,kind,content):
        aid=hashlib.sha256((title+kind+content).encode()).hexdigest()[:16]; a=Artifact(aid,kind,title,content,hashlib.sha256(content.encode()).hexdigest()); self.items[aid]=a; return a
    def interactive_html(self,content): return '<!doctype html><html><body>'+re.sub(r'<script[^>]*>.*?</script>','',content,flags=re.I|re.S)+'</body></html>'
    def list(self): return [asdict(a) for a in self.items.values()]
