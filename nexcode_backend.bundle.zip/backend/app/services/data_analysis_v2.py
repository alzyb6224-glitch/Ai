from __future__ import annotations
import csv, io, json, math, statistics
from typing import Any

def analyze_text(data: str, fmt: str = "csv") -> dict[str, Any]:
    if fmt == "json":
        obj=json.loads(data)
        rows=obj if isinstance(obj,list) else [obj]
    else:
        rows=list(csv.DictReader(io.StringIO(data)))
    if not rows: return {"rows":0,"columns":[],"numeric":{}}
    cols=list(rows[0].keys())
    numeric={}
    for c in cols:
        vals=[]
        for r in rows:
            try: vals.append(float(r[c]))
            except (ValueError,TypeError,KeyError): pass
        if vals:
            numeric[c]={"count":len(vals),"min":min(vals),"max":max(vals),"mean":statistics.fmean(vals),"median":statistics.median(vals)}
    return {"rows":len(rows),"columns":cols,"numeric":numeric,"sample":rows[:5]}

def chart_spec(analysis: dict[str,Any], x: str, y: str) -> dict[str,Any]:
    return {"type":"line","x":x,"y":y,"title":f"{y} by {x}","source":"NexCode Data Analysis V2"}
