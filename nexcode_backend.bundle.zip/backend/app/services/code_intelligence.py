from __future__ import annotations
import re
from collections import defaultdict
from dataclasses import dataclass
from typing import Iterable
from app.db.models import ProjectFile

IMPORT_PATTERNS = [
    re.compile(r'^\s*import\s+([\w.]+)', re.M),
    re.compile(r'^\s*from\s+([\w.]+)\s+import', re.M),
    re.compile(r'''require\(["'](.+?)["']\)'''),
    re.compile(r'''from\s+["'](.+?)["']'''),
    re.compile(r'''import\s+["'](.+?)["']'''),
]
SYMBOL_PATTERNS = {
    'python': re.compile(r'^\s*(?:async\s+def|def|class)\s+(\w+)', re.M),
    'javascript': re.compile(r'^\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)|^\s*(?:export\s+)?class\s+(\w+)|^\s*(?:export\s+)?const\s+(\w+)\s*=\s*\(', re.M),
    'typescript': re.compile(r'^\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)|^\s*(?:export\s+)?class\s+(\w+)|^\s*(?:export\s+)?(?:const|let)\s+(\w+)\s*=\s*\(', re.M),
    'dart': re.compile(r'^\s*(?:class|mixin|enum)\s+(\w+)|^\s*(?:Future<[^>]+>|[\w<>?]+)\s+(\w+)\s*\(', re.M),
}

@dataclass
class Symbol:
    name: str
    path: str
    kind: str


def _module_name(path: str) -> str:
    p = path.replace('\\', '/').rsplit('.', 1)[0]
    return p.replace('/', '.')


def extract_imports(file: ProjectFile) -> list[str]:
    found: list[str] = []
    for pat in IMPORT_PATTERNS:
        for m in pat.finditer(file.content):
            value = next((g for g in m.groups() if g), '').strip()
            if value and value not in found:
                found.append(value)
    return found[:200]


def extract_symbols(file: ProjectFile) -> list[Symbol]:
    pat = SYMBOL_PATTERNS.get(file.language)
    if not pat:
        return []
    out = []
    for m in pat.finditer(file.content):
        name = next((g for g in m.groups() if g), None)
        if name:
            kind = 'symbol'
            if file.language == 'python':
                line = file.content[m.start():m.end()].strip()
                kind = 'class' if line.startswith('class ') else 'function'
            out.append(Symbol(name, file.path, kind))
    return out[:500]


def analyze_project(files: Iterable[ProjectFile]) -> dict:
    files = list(files)
    module_to_path = {_module_name(f.path): f.path for f in files}
    imports: dict[str, list[str]] = {}
    symbols: list[dict] = []
    reverse: defaultdict[str, list[str]] = defaultdict(list)
    unresolved: list[dict] = []
    for f in files:
        imps = extract_imports(f)
        imports[f.path] = imps
        for s in extract_symbols(f):
            symbols.append({'name': s.name, 'path': s.path, 'kind': s.kind})
        for imp in imps:
            candidate = module_to_path.get(imp) or module_to_path.get(imp.replace('src.', '', 1))
            if candidate and candidate != f.path:
                reverse[candidate].append(f.path)
            elif imp.startswith(('.', 'src', 'app')):
                unresolved.append({'from': f.path, 'import': imp})
    duplicate: dict[str, list[str]] = defaultdict(list)
    dead: list[dict] = []
    for s in symbols:
        duplicate[s['name']].append(s['path'])
    duplicates = [{'symbol': k, 'files': sorted(set(v))} for k, v in duplicate.items() if len(set(v)) > 1][:100]
    content_tokens = {}
    for f in files:
        tokens = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]{2,}\b', f.content))
        content_tokens[f.path] = tokens
    for s in symbols:
        users = [p for p, toks in content_tokens.items() if p != s['path'] and s['name'] in toks]
        if not users and len(s['name']) > 3:
            dead.append(s)
    graph = {p: sorted(set(reverse.get(p, []))) for p in module_to_path.values()}
    return {
        'files': len(files),
        'symbols': symbols[:500],
        'imports': imports,
        'reverse_dependencies': graph,
        'unresolved_imports': unresolved[:200],
        'potential_duplicates': duplicates,
        'potential_dead_symbols': dead[:200],
    }


def impact_analysis(files: Iterable[ProjectFile], changed_paths: list[str]) -> dict:
    data = analyze_project(files)
    rev = data['reverse_dependencies']
    impacted = set(changed_paths)
    frontier = list(changed_paths)
    while frontier:
        path = frontier.pop()
        for consumer in rev.get(path, []):
            if consumer not in impacted:
                impacted.add(consumer); frontier.append(consumer)
    return {
        'changed': changed_paths,
        'impacted': sorted(impacted),
        'newly_impacted_count': max(0, len(impacted) - len(set(changed_paths))),
        'graph': data,
    }
