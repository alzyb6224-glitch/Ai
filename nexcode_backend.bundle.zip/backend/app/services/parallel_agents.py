from __future__ import annotations
import asyncio
import json
from app.services.ai import client
from app.core.config import settings

async def run_parallel_analysts(request: str, project_context: str, research_context: str='') -> dict:
    prompts = {
        'architect': 'Analyze architecture, affected components, risks and dependencies. Return concise JSON.',
        'security': 'Review the requested change for security risks, secrets, injection, auth and data exposure. Return concise JSON.',
        'tester': 'Design the smallest high-value verification plan and regression tests for the requested change. Return concise JSON.',
    }
    async def one(name, instruction):
        r=await client().responses.create(model=settings.openai_text_model, input=f"REQUEST:\n{request}\nPROJECT:\n{project_context[:50000]}\nRESEARCH:\n{research_context[:8000]}", instructions=instruction+" Return only JSON with keys findings and recommendations.")
        text=getattr(r,'output_text','') or '{}'
        try: return name, json.loads(text)
        except Exception: return name, {'findings':[text[:5000]],'recommendations':[]}
    results=await asyncio.gather(*(one(n,p) for n,p in prompts.items()), return_exceptions=False)
    return {name:data for name,data in results}
