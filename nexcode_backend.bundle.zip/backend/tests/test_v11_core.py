from types import SimpleNamespace
from app.services.agent_core_v11 import NexCodeAgentCoreV11, scrub_secrets
from app.services.sandbox_policy_v11 import tool_policy, validate_path
from app.services.benchmark_v11 import run_contracts
from app.services.preflight_v11 import project_preflight


def f(path, content):
    return SimpleNamespace(path=path, content=content, language='text')


def test_central_plan_and_context():
    files=[f('pubspec.yaml','name: demo'), f('lib/main.dart','void main() {}'), f('README.md','demo')]
    core=NexCodeAgentCoreV11()
    plan=core.plan('build a Flutter app and add tests',files)
    assert plan.intent == 'mobile'
    assert 'lead' in plan.selected_agents
    assert 'tester' in plan.selected_agents
    ctx=core.context('build a Flutter app',files)
    assert ctx['selection']['files_total']==3
    assert 'pubspec.yaml' in ctx['selection']['paths']


def test_specialist_team_and_security():
    files=[f('main.py','password = "super-secret-value"'), f('requirements.txt','fastapi')]
    core=NexCodeAgentCoreV11(); ctx=core.context('fix bug',files)
    security=core.specialist_report('security','fix bug',files,ctx)
    assert security['findings']
    assert any(x['severity']=='high' for x in security['findings'])


def test_secret_redaction_and_policy():
    text='api_key="ABCDEFGHIJKLMNOP" and Authorization: Bearer ABCDEFGHIJKLMNO'
    red=scrub_secrets(text)
    assert 'ABCDEFGHIJKLMNOP' not in red
    assert 'ABCDEFGHIJKLMNO' not in red
    assert tool_policy('deploy', approved=False)['status']=='approval_required'
    assert tool_policy('deploy', approved=True)['allowed'] is True
    assert not validate_path('/etc/passwd')
    assert validate_path('/workspace/project')


def test_benchmark_contract():
    plan=NexCodeAgentCoreV11().plan('hello',[]).as_dict()
    r=run_contracts({'plan':plan,'context':{'selection':{}},'events':[{'status':'done'}],'checkpoints':[{'name':'planned'}],'quality':{},'status':'completed'})
    assert r['score']==100.0


def test_preflight_detects_flutter_and_blockers():
    files=[f('pubspec.yaml','name: demo'), f('lib/main.dart','void main() {}')]
    report=project_preflight(files)
    assert report['platform_detected']['flutter'] is True
    assert 'local_flutter_runtime_unavailable' in report['blockers'] or report['runtime'] is not None

