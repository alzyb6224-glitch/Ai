from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def test_v7_benchmark_has_120_tasks_and_all_fixture_checks_pass():
    from app.services.benchmark_v7 import load_tasks, run_benchmark
    tasks = load_tasks()
    assert 100 <= len(tasks) <= 500
    report = run_benchmark(tasks)
    assert report['task_count'] == len(tasks)
    assert report['passed'] == len(tasks)
    assert report['pass_rate'] == 100.0


def test_self_healing_has_bounded_stop_and_replan():
    from app.services.self_healing import decide_repair
    assert decide_repair(failed=False, changed_files=1, cycles=0, max_cycles=2).action == 'stop'
    assert decide_repair(failed=True, changed_files=1, cycles=2, max_cycles=2).action == 'stop'
    assert decide_repair(failed=True, changed_files=1, cycles=1, max_cycles=2, repeated_failure=True).action == 'replan'
    assert decide_repair(failed=True, changed_files=1, cycles=0, max_cycles=2).action == 'repair'


def test_intelligence_v2_finds_entrypoints_hotspots_and_reverse_dependencies():
    from app.services.intelligence_v2 import analyze_project_v2
    class F:
        def __init__(self,path,content,language='python'): self.path=path; self.content=content; self.language=language
    files=[F('main.py','from service import Thing\n' + '\n'.join(['# TODO']*25)),F('service.py','class Thing:\n    pass'),F('test_main.py','def test_x(): assert True')]
    data=analyze_project_v2(files)
    assert 'main.py' in data['entrypoints']
    assert 'test_main.py' in data['tests']
    assert 'main.py' in data['reverse_dependencies']['service.py']
    assert data['hotspots']


def test_sandbox_policy_is_hardened():
    from app.services.sandbox_v7 import validate_policy
    report = validate_policy()
    assert report['ok']
    assert all(x['ok'] for x in report['checks'])
