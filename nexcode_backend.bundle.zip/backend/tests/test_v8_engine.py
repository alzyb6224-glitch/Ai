import json, os, stat, sys, tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

def test_benchmark_v8():
    from app.services.benchmark_v8 import run_benchmark_v8
    r=run_benchmark_v8()
    assert r['tasks']==200 and r['passed']==200 and r['pass_rate']==100.0
    assert len(r['categories'])==10

def test_computer_policy():
    from app.services.computer_agent import validate_action, dry_run
    assert validate_action({'kind':'open_url','target':'https://example.com'})['ok']
    x=validate_action({'kind':'delete','target':'workspace'}); assert x['reason']=='approval_required'
    assert dry_run('https://example.com')['planned'][0]['kind']=='open_url'

def test_memory_v2_recall():
    from app.services.memory_v2 import MemoryV2
    m=MemoryV2(); m.upsert('stack','Flutter FastAPI production workspace','project',0.95,'user'); m.upsert('other','random note','project')
    r=m.search('FastAPI Flutter',3); assert r and r[0]['key']=='stack' and r[0]['score']>0

def test_workspace_diff_and_hash():
    from app.services.workspace_v2 import WorkspaceV2
    w=WorkspaceV2(); a=w.upsert('lib/main.py','print(1)','code'); d=w.diff('lib/main.py','print(2)'); b=w.upsert('lib/main.py','print(2)','code')
    assert a['version']==1 and b['version']==2 and 'print(2)' in d and len(b['sha256'])==64

def test_data_analysis():
    from app.services.data_analysis_v2 import analyze_text, chart_spec
    r=analyze_text('name,score\na,10\nb,20\n','csv')
    assert r['rows']==2 and r['numeric']['score']['mean']==15.0
    assert chart_spec(r,'name','score')['type']=='line'

def test_voice_intent():
    from app.services.voice_v2 import command_intent
    assert command_intent('build the app')['intent']=='developer_command'
    assert command_intent('')['intent']=='empty'

def test_jobs_complete():
    import asyncio
    from app.services.jobs_v2 import JobManagerV2
    async def go():
        jm=JobManagerV2()
        async def work(): return 42
        j=jm.submit('x',work); await asyncio.sleep(0.02); assert jm.get(j.id)['status']=='done'; assert jm.get(j.id)['result']==42
    asyncio.run(go())

def test_collaboration_expiry_and_roles():
    from app.services.collaboration_v2 import CollaborationV2
    c=CollaborationV2(); link=c.create_link(7,'editor',60); assert c.resolve(link['token'])['role']=='editor'
    try: c.create_link(7,'admin')
    except ValueError: pass
    else: assert False

def test_multimodal_inspection():
    from app.services.multimodal_v2 import inspect_assets
    r=inspect_assets([{'path':'a.png'},{'path':'README.md'},{'path':'main.py'}])
    assert r['images']==1 and r['docs']==1 and r['asset_count']==3

def test_mcp_client_real_stdio_roundtrip():
    from app.services.mcp_client import MCPStdioClient
    with tempfile.TemporaryDirectory() as td:
        script=Path(td)/'server.py'
        script.write_text('import sys,json\nfor line in sys.stdin:\n r=json.loads(line); m=r.get("method"); out={"jsonrpc":"2.0","id":r.get("id"),"result":{}}\n if m=="initialize": out["result"]={"protocolVersion":"test","serverInfo":{"name":"fake","version":"1"}}\n elif m=="tools/list": out["result"]={"tools":[{"name":"hello","description":"hi","inputSchema":{"type":"object"}}]}\n elif m=="tools/call": out["result"]={"content":[{"type":"text","text":"ok"}]}\n print(json.dumps(out),flush=True)')
        c=MCPStdioClient([sys.executable,str(script)],{'hello'})
        assert c.initialize()['serverInfo']['name']=='fake'
        assert c.list_tools()[0].name=='hello'
        assert c.call_tool('hello')['content'][0]['text']=='ok'
        c.stop()

def test_observability_trace():
    from app.services.observability_v2 import Trace
    t=Trace('abc'); t.add('request','done'); t.add('execution','failed'); r=t.finish(); assert r['trace_id']=='abc' and r['failed']==1


def test_release_gate_blocks_bad_release():
    from app.services.release_gate import evaluate
    r=evaluate(tests_ok=False,quality_score=75,security_ok=True,unresolved_repairs=0,git_ready=True)
    assert not r['ready'] and 'Tests are not green.' in r['blockers']

def test_cost_guard():
    from app.services.cost_guard import decide
    assert decide(100_000,50_000,2,10,0).allowed
    assert not decide(500_000,500_000,2,10,0).allowed
