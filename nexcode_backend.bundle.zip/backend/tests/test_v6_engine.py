from dataclasses import dataclass
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.services.code_intelligence import analyze_project, impact_analysis
from app.services.executor import _ecosystem_commands
from app.services.action_guard import safe_actions
PIPELINE=[("understand", ""),("plan", ""),("project_search", ""),("web_research", ""),("impact", ""),("implement", ""),("review", ""),("test", ""),("repair", ""),("retest", ""),("deliver", "")]
from app.services.terminal import allowed_command

@dataclass
class F:
    path: str
    content: str
    language: str


def test_safe_actions_blocks_escape_and_secrets():
    out=safe_actions([
        {'op':'write','path':'../x.py','content':'x'},
        {'op':'write','path':'.env','content':'SECRET="bad"'},
        {'op':'write','path':'ok.py','content':'print(1)'},
    ])
    assert [x['path'] for x in out]==['ok.py']


def test_code_intelligence_reverse_dependency():
    files=[F('a.py','from b import Thing\nprint(Thing)','python'),F('b.py','class Thing:\n    pass','python')]
    data=analyze_project(files)
    assert 'a.py' in data['reverse_dependencies']['b.py']
    impact=impact_analysis(files,['b.py'])
    assert 'a.py' in impact['impacted']


def test_command_allowlist():
    assert allowed_command(['python','-m','compileall','-q','.'])
    assert not allowed_command(['bash','-c','echo unsafe'])
    assert not allowed_command(['python','-c','import os; os.system("x")'])


def test_profiles_contain_real_checks():
    files=[F('main.py','print(1)','python'),F('test_main.py','def test_x(): assert 1','python')]
    cmds=_ecosystem_commands(Path('/tmp'),files,include_build=False,include_install=False)
    assert ['python','-m','compileall','-q','.'] in cmds
    assert ['pytest','-q'] in cmds
    assert len(PIPELINE)>=11


def test_quality_engine_detects_secret():
    from app.services.quality import generate_quality_report
    files=[F('config.py','API_KEY = "123456789-secret-value"\n','python')]
    report=generate_quality_report(files)
    assert any(x['severity']=='high' for x in report.findings)
    assert 0 <= report.score <= 100


def test_git_snapshot_and_diff(tmp_path, monkeypatch):
    from app.core.config import settings
    from app.services.git_intel import sync_project, diff, history
    monkeypatch.setattr(settings,'git_root',str(tmp_path))
    files=[F('main.py','print("one")','python')]
    first=sync_project(77,files,'initial',branch='nexcode/test')
    assert first['enabled'] is True
    assert first['changed'] is True
    files[0].content='print("two")'
    second=sync_project(77,files,'update',branch='nexcode/test')
    assert second['changed'] is True
    assert 'two' in diff(77)
    assert len(history(77)) >= 2
