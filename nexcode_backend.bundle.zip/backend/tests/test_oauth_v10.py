import sys
sys.path.insert(0, 'backend')
from app.services.oauth_v10 import enabled_providers, state_token, verify_state, providers


def test_provider_registry_has_socials():
    assert {'google','apple','github','microsoft','discord'} <= set(providers())


def test_state_is_signed_and_round_trips():
    token = state_token('google', 'https://example.test/callback')
    claims = verify_state(token)
    assert claims['provider'] == 'google'
    assert claims['redirect_uri'].startswith('https://')
    assert claims['exp'] > 0


def test_unconfigured_providers_do_not_advertise_as_enabled():
    assert isinstance(enabled_providers(), list)

import pytest

def test_state_tamper_is_rejected():
    token = state_token('apple', 'nexcode://oauth/callback')
    bad = token[:-1] + ('0' if token[-1] != '0' else '1')
    with pytest.raises(ValueError):
        verify_state(bad)
