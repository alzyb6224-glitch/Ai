import asyncio, sys, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

class F:
    def __init__(self,path,content): self.path=path; self.content=content

def test_model_router_capability():
    from app.services.model_router_v9 import route
    assert route('Implement API and write tests')['selected']['name']=='coding'
    assert route('Analyze architecture and root cause')['selected']['name']=='reasoning'

def test_browser_policy():
    from app.services.browser_agent_v9 import plan,validate_url
    assert validate_url('https://example.com',{'example.com'})
    assert not validate_url('https://evil.example',{'example.com'})
    r=plan('fill form',['https://example.com'],{'example.com'}); assert r['ready']

def test_mcp_registry_policy():
    from app.services.mcp_ecosystem_v9 import MCPEcosystem,MCPServer
    m=MCPEcosystem(); m.register(MCPServer('x','http','https://example.com/mcp',True,('read',))); m.register_tools('x',[{'name':'read'},{'name':'delete'}])
    assert m.allow('x','read') and not m.allow('x','delete'); assert 'x:read' in m.catalog()['tools']

def test_multi_agent_research():
    from app.services.deep_research_v3 import multi_agent_research
    async def search(q): return {'text':'evidence','urls':['https://example.com']}
    r=asyncio.run(multi_agent_research('x',search)); assert len(r.agents)==3 and all(a.urls for a in r.agents)

def test_code_graph_impact():
    from app.services.code_graph_v3 import build_graph,impact
    g=build_graph([F('a.py',''),F('b.py','from a import x'),F('c.py','from b import y')])
    i=impact(g,['a.py']); assert 'b.py' in i['impacted'] or i['blast_radius']>=2

def test_autonomous_loop_repairs():
    from app.services.autonomous_loop_v9 import AutonomousLoopV9
    tries={'n':0}
    def plan(): return {}
    def exe(s): tries['n']+=1; return {'n':tries['n']}
    def verify(o): return o['n']>=3
    def repair(o): return o
    r=AutonomousLoopV9(5).run(plan,exe,verify,repair); assert r['status']=='verified' and r['iterations']==3

def test_swe_harness_command():
    from app.services.swe_bench_v9 import SWEBenchHarness,score,SWEResult
    with tempfile.TemporaryDirectory() as td:
        r=SWEBenchHarness().run_command([sys.executable,'-c','print(42)'],td); assert r['ok'] and '42' in r['stdout']
    assert score([SWEResult('1','verified',True),SWEResult('2','failed',False)])['pass_rate']==50.0

def test_enterprise_security():
    from app.services.enterprise_security_v9 import SecurityEngine
    s=SecurityEngine('secret'); s.grant(1,2,'developer'); assert s.allowed(1,2,'write') and not s.allowed(1,2,'deploy')
    sig=s.sign('abc'); assert s.verify('abc',sig) and not s.verify('bad',sig)
    assert '[REDACTED]' in s.redact('sk-abcdefghijklmnopqrstuvwxyz')

def test_ide_and_artifact():
    from app.services.ide_v9 import IDEV9
    from app.services.artifacts_v9 import ArtifactEngine
    i=IDEV9(); i.open('main.py','a'); assert 'main.py' in i.tree(); assert 'b' in i.edit('main.py','b')['diff']
    a=ArtifactEngine().create('demo','html','<script>alert(1)</script><p>x</p>'); assert len(a.sha256)==64

def test_realtime_collab():
    from app.services.collaboration_v9 import RealtimeRoom
    r=RealtimeRoom('x'); snap=r.join(1,'A'); assert snap['presence'][0]['online']; assert r.op(1,{'x':1})==2; r.leave(1); assert not r.presence[1].online

def test_memory_learning():
    from app.services.memory_learning_v9 import MemoryLearningLoop
    m=MemoryLearningLoop(); m.observe('style','dark','positive',.5); assert m.recall('style')['confidence']==.7

def test_voice_mobile_and_agents():
    from app.services.voice_agent_v9 import VoiceAgentV9
    from app.services.dev_agents_v9 import CodeReviewAgent,SecurityAuditorAgent,DeployAgent,MobileAgent
    assert VoiceAgentV9().intent('deploy app')['intent']=='deploy'
    f=F('x.py','eval("x")\nhttp://bad')
    assert CodeReviewAgent().review([f])[0]['severity']=='critical'
    assert SecurityAuditorAgent().audit([f])
    assert DeployAgent().plan('docker',1)['approval_required']
    assert 'deploy' in MobileAgent().quick_actions()

def test_dependency_agent():
    from app.services.package_dependency_agent_v9 import PackageDependencyAgentV9
    r=PackageDependencyAgentV9().analyze({'requirements.txt':'fastapi==1\nhttpx==2\n','package.json':'{"dependencies":{"react":"1"}}'})
    assert r['total']==3


def test_computer_use_local_http_roundtrip():
    from app.services.computer_use_v9 import ComputerUseV9
    import threading, http.server, socketserver
    handler=http.server.SimpleHTTPRequestHandler
    httpd=socketserver.TCPServer(('127.0.0.1',0),handler)
    port=httpd.server_address[1]; thread=threading.Thread(target=httpd.serve_forever,daemon=True); thread.start()
    try:
        r=ComputerUseV9({f'127.0.0.1'},5).open_url(f'http://127.0.0.1:{port}')
        assert r['ok'] and r['status']==200
    finally: httpd.shutdown(); httpd.server_close()

def test_deployment_guard_and_execution():
    from app.services.deployment_v9 import DeploymentEngineV9
    import sys, tempfile
    d=DeploymentEngineV9(); assert d.plan('docker',1)['approval_required']
    with tempfile.TemporaryDirectory() as td:
        assert d.run_local([sys.executable,'-c','print(7)'],td,False)['status']=='approval_required'
        r=d.run_local([sys.executable,'-c','print(7)'],td,True); assert r['ok'] and '7' in r['stdout']
